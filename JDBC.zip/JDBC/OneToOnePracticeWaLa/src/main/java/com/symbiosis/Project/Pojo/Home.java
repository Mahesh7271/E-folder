package com.symbiosis.Project.Pojo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Home {
	@Id
	/*@GeneratedValue(strategy = GenerationType.AUTO)
	*/private int ID;
	private String Home_Name;
	@OneToOne
	private Address address;

	@Override
	public String toString() {
		return "Home [ID=" + ID + ", Home_Name=" + Home_Name + ", address=" + address + "]";
	}

	public Home(int iD, String home_Name, Address address) {
		super();
		ID = iD;
		Home_Name = home_Name;
		this.address = address;
	}

	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}

	public String getHome_Name() {
		return Home_Name;
	}

	public void setHome_Name(String home_Name) {
		Home_Name = home_Name;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

}
