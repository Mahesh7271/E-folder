package com.symbiosis.Project.PojoInfo;

public class info {

}
