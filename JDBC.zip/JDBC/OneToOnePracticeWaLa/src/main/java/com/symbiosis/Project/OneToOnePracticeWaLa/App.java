package com.symbiosis.Project.OneToOnePracticeWaLa;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.symbiosis.Project.Pojo.Address;
import com.symbiosis.Project.Pojo.Family;
import com.symbiosis.Project.Pojo.Home;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("OTMWO");
    	EntityManager manager = entityManagerFactory.createEntityManager();
    	List<Home> list = new ArrayList<Home>();
    	
    	Address address = new Address(101, "Mumbai", "Maharashtra", 411041);
    	Home home = new Home(101, "Antilia", address);
    	Home home1 = new Home(101, "Antilia", address);
    	list.add(0, home);
    	Family family = new Family(101, "Ambani Family", list);
    	
    	manager.getTransaction().begin();
    	
    	manager.persist(address);
    	manager.persist(home);
    	manager.persist(family);
 
    	System.out.println("ok");
    	manager.getTransaction().commit();
    	
    }
}
