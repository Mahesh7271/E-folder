package com.symbiosis.Project.Pojo;

import java.util.List;


import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
@Entity
public class Family {
	@Id
	/*@GeneratedValue(strategy=GenerationType.AUTO)
	 * for some issue are hold this today's  try to solve 
	*/
	private int id;
	private String Familyname;
	@OneToMany
	private List<Home> home;

	public Family(int id, String familyname, List<Home> home) {
		super();
		this.id = id;
		Familyname = familyname;
		this.home = home;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFamilyname() {
		return Familyname;
	}

	public void setFamilyname(String familyname) {
		Familyname = familyname;
	}

	public List<Home> getHome() {
		return home;
	}

	public void setHome(List<Home> home) {
		this.home = home;
	}

	@Override
	public String toString() {
		return "Family [ id=" + id + ", Familyname=" + Familyname + ", home=" + home + "]";
	}
	

}
