package com.symbiosis.Project.Pojo;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Address {
	@Id
/*	@GeneratedValue (strategy=GenerationType.AUTO)
*/	private int Address_Id;
	private String City;
	private String State;
	private int Pincode;

	public Address(int address_Id, String city, String state, int pincode) {
		super();
		Address_Id = address_Id;
		City = city;
		State = state;
		Pincode = pincode;
	}

	public int getAddress_Id() {
		return Address_Id;
	}

	public void setAddress_Id(int address_Id) {
		Address_Id = address_Id;
	}

	public String getCity() {
		return City;
	}

	public void setCity(String city) {
		City = city;
	}

	public String getState() {
		return State;
	}

	public void setState(String state) {
		State = state;
	}

	public int getPincode() {
		return Pincode;
	}

	public void setPincode(int pincode) {
		Pincode = pincode;
	}

	@Override
	public String toString() {
		return "Address [Address_Id=" + Address_Id + ", City=" + City + ", State=" + State + ", Pincode=" + Pincode
				+ "]";
	}

}
