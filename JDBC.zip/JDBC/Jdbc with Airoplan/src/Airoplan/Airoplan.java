package Airoplan;

import java.sql.Date;

public class Airoplan {
	private int Air_Id;
	private String Air_Name;
	private Date Air_Time;
	private int Air_totalSett;
	public Airoplan(int air_Id, String air_Name, Date air_Time, int air_totalSett) {
		super();
		Air_Id = air_Id;
		Air_Name = air_Name;
		Air_Time = air_Time;
		Air_totalSett = air_totalSett;
	}
	public int getAir_Id() {
		return Air_Id;
	}
	public void setAir_Id(int air_Id) {
		Air_Id = air_Id;
	}
	public String getAir_Name() {
		return Air_Name;
	}
	public void setAir_Name(String air_Name) {
		Air_Name = air_Name;
	}
	public Date getAir_Time() {
		return Air_Time;
	}
	public void setAir_Time(Date air_Time) {
		Air_Time = air_Time;
	}
	public int getAir_totalSett() {
		return Air_totalSett;
	}
	public void setAir_totalSett(int air_totalSett) {
		Air_totalSett = air_totalSett;
	}
	@Override
	public String toString() {
		return "Airoplan [Air_Id=" + Air_Id + ", Air_Name=" + Air_Name + ", Air_Time=" + Air_Time + ", Air_totalSett="
				+ Air_totalSett + "]";
	}

}
