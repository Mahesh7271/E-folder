package Airoplan;

public class AiroplanInfo {

}
