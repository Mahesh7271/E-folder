package Interface;

public class CustmerInterface {

}
