package Interface;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Scanner;

import Airoplan.Airoplan;

public class AdminInterface 
{
	Airoplan  airoplan = null;
	Scanner scanner = new Scanner(System.in);
	public void AdminInterface () throws ParseException 
	{
		System.out.println("1 - Add New Flight"
					   + "\n2 - Display Flight"
					   + "\n3 - ");
		System.out.println("Enter Your Choice ....");
		int choice = scanner.nextInt();
		switch (choice) {
		case 1:
			airoplan=CreateFlight();
			break;
		case 2:
			DisplayFight(airoplan);
			break;
		
		case 3:
		default:
			break;
		}
	}
	private Airoplan CreateFlight() throws ParseException 
	{
		Airoplan airoplan = null;
		String string = "30/10/2000";
		Date date = (Date) new SimpleDateFormat("dd/mm/yyyy").parse(string);
		airoplan= new Airoplan(10, "Mahesh",date, 250);
		
		return  airoplan;
	}

	private void DisplayFight(Airoplan airoplan)
	{
		System.out.println(airoplan);
	}
}

