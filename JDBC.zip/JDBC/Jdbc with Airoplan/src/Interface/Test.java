package Interface;

import java.text.ParseException;
import java.util.Scanner;

public class Test 
{
	
	public static void main(String[] args) throws ParseException 
	{
		AdminInterface adminInterface = new AdminInterface();
		CustmerInterface custmerInterface = new CustmerInterface();
		RegularInterface regularInterface = new RegularInterface();
		Scanner scanner = new Scanner(System.in);
		System.out.println(" Who do you want too---"
					   + "\n 1 - Admin"
					   + "\n 2 - Regular user "
					   + "\n 3 - Custmer "
					   + "\n 4 - Exit");
		System.out.println("Enter your choice........");
		int choice =scanner.nextInt();
		switch (choice) {
		case 1:
			adminInterface.AdminInterface();
			break;

		default:
			break;
		}
	}

}
