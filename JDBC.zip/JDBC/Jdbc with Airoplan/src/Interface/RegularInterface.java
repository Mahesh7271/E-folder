package Interface;

public class RegularInterface {

}
