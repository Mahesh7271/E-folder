package com.symbiosis.exam.mvc;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Answer {
	@Id
	private int Aid;
	private String ans;
	
	public int getAid() {
		return Aid;
	}

	public void setAid(int aid) {
		Aid = aid;
	}

	public String getAns() {
		return ans;
	}

	public void setAns(String ans) {
		this.ans = ans;
	}

	public Answer(int aid, String ans) {
		super();
		Aid = aid;
		this.ans = ans;
	}

	public Answer() {
		super();
	}

	@Override
	public String toString() {
		return "Answer [Aid=" + Aid + ", ans=" + ans + "]";
	}

}
