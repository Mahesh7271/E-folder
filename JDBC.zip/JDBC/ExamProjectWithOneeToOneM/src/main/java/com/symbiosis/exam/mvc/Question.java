package com.symbiosis.exam.mvc;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Question {
@Id
	public int Qid;
	public String QName;
	@OneToOne
	public Answer  answer;
	public int getQid() {
		return Qid;
	}
	public void setQid(int qid) {
		Qid = qid;
	}
	public String getQName() {
		return QName;
	}
	public void setQName(String qName) {
		QName = qName;
	}
	public Answer getAnswer() {
		return answer;
	}
	public void setAnswer(Answer answer) {
		this.answer = answer;
	}
	@Override
	public String toString() {
		return "Question [Qid=" + Qid + ", QName=" + QName + ", answer=" + answer + "]";
	}
	public Question(int qid, String qName, Answer answer) {
		super();
		Qid = qid;
		QName = qName;
		this.answer = answer;
	}
	public Question() {
		super();
	}
	
}
