package com.symbiosis.exam.ExamProjectWithOneeToOneM;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.symbiosis.exam.mvc.Answer;
import com.symbiosis.exam.mvc.Question;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	EntityManagerFactory emf=Persistence.createEntityManagerFactory("TP");
    	EntityManager em=emf.createEntityManager();
    	
    	Answer and=new Answer(1,"java is a programming language");
    	
    	Question q=new Question(101,"java",and);
    	
		
    	em.getTransaction().begin();
    	em.persist(and);
    	em.persist(q);
    	em.getTransaction().commit();
    	
    	
    }
}
