package Dao;

import java.sql.Connection;

import Mvc.Account;

public class AccountDao {
	Connection  connection = myConnection.GetConnection();
	public void InsertData(Account account) {
		
	}
}
