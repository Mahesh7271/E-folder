package Info;

import java.awt.List;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Scanner;

import Mvc.Account;
import Mvc.Address;
import Mvc.Custmore;

public class AccountInfo {
	Scanner scanner = new Scanner(System.in);

	public ArrayList<Account>   Create() {
		ArrayList<Account>  list = new ArrayList<>();
		
		System.out.println("Enter Your ID\tName\tlastName\tMobile  ");
		Custmore custmore = new Custmore(scanner.nextInt(),scanner.next(),scanner.next(),scanner.next());
		System.out.println("Enter  City\tState\tPincode ");
		Address address = new Address(scanner.nextInt(), scanner.next(), scanner.next(), scanner.nextInt());
		System.out.println("Enter Your Account ID\tAccount PassWord");
		Account account = new Account(scanner.nextInt(), scanner.nextInt(), custmore, address);
		
		/*this are some understanding aggrigation methods ; custmore or address ; 
		
		 * 	Custmore custmore = new Custmore(101, "mahesh", "bhonde", "9623897271");
			Address address= new Address(101, "Pune", "mh", 413702);
			Account account= new Account(1001, 1001, custmore, address);
		*/
		
		list.add(account);
		
		System.out.println(list);
		return list;
	}
	
	public void Display(ArrayList<Account>  list) {
		for (Account account : list) {
			System.out.println(account);
		}
	}
}
