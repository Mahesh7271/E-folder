package Info;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Scanner;

import Mvc.Account;

public class test {

	public static void main(String[] args) {
		AccountInfo accountInfo = new AccountInfo();
		ArrayList<Account>   list = null;

		Scanner scanner = new Scanner(System.in);
		do{
		System.out.println("Enter Your Choice");
		System.out.println("1  - Create Account " + "\n2  - Display Account");
		int choice = scanner.nextInt();
		switch (choice) {
		case 1:
			list = accountInfo.Create();

			break;
		case 2:
			if(list==null)
			  System.out.println("List is null . . ");
			else
				accountInfo.Display(list);
			break;
		default:
			System.out.println("Invalied Choice . . .");
			break;
		}
		System.out.println("Do You Want Continue press 1 :");
		}while(scanner.nextInt()==1);
		
	}
}
