package Mvc;

public class Account {
	private int Account_N0;
	private int Account_pass;
	Custmore custmore;
	Address address;

	
	
	@Override
	public String toString() {
		return "------------ Account Details ------------ \nAccount Number : " + Account_N0 + "\nAccount Password : " + Account_pass  + custmore
				+  address ;
	}
	public Account(int account_N0, int account_pass, Custmore custmore, Address address) {
		this.Account_N0 = account_N0;
		this.Account_pass = account_pass;
		this.custmore = custmore;
		this.address = address;
	}
	public int getAccount_N0() {
		return Account_N0;
	}
	public void setAccount_N0(int account_N0) {
		Account_N0 = account_N0;
	}
	public int getAccount_pass() {
		return Account_pass;
	}
	public void setAccount_pass(int account_pass) {
		Account_pass = account_pass;
	}
	public Custmore getCustmore() {
		return custmore;
	}
	public void setCustmore(Custmore custmore) {
		this.custmore = custmore;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}

}
