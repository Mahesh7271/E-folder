package Mvc;

public class Custmore {
	public int cust_id;
	public String cust_Name;
	public String Cust_lastName;
	public String Mobile;
	public int getCust_id() {
		return cust_id;
	}
	public void setCust_id(int cust_id) {
		this.cust_id = cust_id;
	}
	public String getCust_Name() {
		return cust_Name;
	}
	public void setCust_Name(String cust_Name) {
		this.cust_Name = cust_Name;
	}
	public String getCust_lastName() {
		return Cust_lastName;
	}
	public void setCust_lastName(String cust_lastName) {
		Cust_lastName = cust_lastName;
	}
	public String getMobile() {
		return Mobile;
	}
	public void setMobile(String mobile) {
		Mobile = mobile;
	}
	public Custmore(int cust_id, String cust_Name, String cust_lastName, String mobile) {
		super();
		this.cust_id = cust_id;
		this.cust_Name = cust_Name;
		Cust_lastName = cust_lastName;
		Mobile = mobile;
	}
	public Custmore() {
	}
	@Override
	public String toString() {
		return "\n------------ Custmore Details ------------\nCustmore id :" + cust_id + "\nCustmore Name :" + cust_Name + " " + Cust_lastName
				+ "\nCustmore Mobile : " + Mobile  ;
	}

}
