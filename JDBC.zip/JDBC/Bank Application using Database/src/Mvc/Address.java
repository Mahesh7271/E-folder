package Mvc;

public class Address {
	private int Add_id;
	private String City;
	private String State;
	private int pincode;
	public Address(int add_id, String city, String state, int pincode) {
		Add_id = add_id;
		City = city;
		State = state;
		this.pincode = pincode;
	}
	public Address() {
	}
	@Override
	public String toString() {
		return "\n------------ Address Details ------------ \n"+"City : " + City + "\n State  : " + State + "\nPincode : " + pincode ;
	}
	public int getAdd_id() {
		return Add_id;
	}
	public void setAdd_id(int add_id) {
		Add_id = add_id;
	}
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		City = city;
	}
	public String getState() {
		return State;
	}
	public void setState(String state) {
		State = state;
	}
	public int getPincode() {
		return pincode;
	}
	public void setPincode(int pincode) {
		this.pincode = pincode;
	}
	
}
