package project;

public class addtion {
	public int sum(int a, int b) {
		return a + b;
	}
}
