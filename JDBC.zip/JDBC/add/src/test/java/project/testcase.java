package project;
import project.*;
import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Test;

public class testcase {

	@Test
	public void test() {
		addtion addtion = new addtion();
		int actual = addtion.sum(10, 20);
		int expected = 30;
		assertEquals(expected, actual);

	}

}
