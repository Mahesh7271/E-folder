package com.J17Student.BookInfo;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.J17Student.MVC.Book;

public class bookinfo {
	EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("TP");
	EntityManager manager = entityManagerFactory.createEntityManager();
	Scanner scanner = new Scanner(System.in);

	public void commit() {
		manager.getTransaction().commit();
	}

	public void begin() {
		manager.getTransaction().begin();
	}

	public Book FindBook(int id) {
		begin();
		return manager.find(Book.class, id);
	}

	public Book FindBookWithout(int id) {

		return manager.find(Book.class, id);
	}

	public void createBook() {
		System.out.println("Enter Your Book ID Name  Cost ");
		Book book = new Book(scanner.nextInt(), scanner.next(), scanner.nextInt());

		begin();
		manager.persist(book);
		System.out.println("(1) Rows Record Inserted . . . ");
		commit();
	}

	public void Display() {
		System.out.println("Enter Your Book ID To Display");
		int Bookid = scanner.nextInt();
		Book book = FindBook(Bookid);
		System.out.println(book);
		commit();
	}

	public void chageBookName() {
		System.out.println("Enter Your Book ID To Change A Name : ");
		int Bookid = scanner.nextInt();
		Book book = FindBook(Bookid);

		System.out.println("Enter new name for book");
		book.setBookName(scanner.next());
		System.out.println("(1) Rows Record Upadated. . . ");
		commit();
	}

	public void RemoveBook() {
		begin();
		System.out.println("Enter Your Book Id to Remove");
		int id = scanner.nextInt();
		manager.remove(FindBook(id));
		System.out.println("(1) Rows Record Removed. . . ");
		commit();
	}

	public void Displayall() {
		begin();
		System.out.println("Book Table . ");
		System.out.println("--------------------------------");
		System.out.println("ID\tName\t\tCost");
		System.out.println("--------------------------------");
		for (int i = 0; i < 10; i++) {
			Book book = FindBookWithout(i + 100);
			/*System.out.println(book);*/
			if (book != null) {
				System.out.println(book.getBookId() + "\t" + book.getBookName() + "\t\t" + book.getBookCost());
			}
		}
		
		System.out.println("--------------------------------");
		commit();
	}

}
