package com.J17Student.StudentApplication;

import java.util.Scanner;

import com.J17Student.BookInfo.bookinfo;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	bookinfo bookinfo = new bookinfo(); 
    	Scanner scanner = new Scanner(System.in);
    	do
    	{
    	System.out.println("Enter Your Choice");
    	System.out.println("1 - Insert a  Book");
    	System.out.println("2 - Display a  Book");
    	System.out.println("3 - Change Book Name");
    	System.out.println("4 - Remove Book ");
    	System.out.println("--------------------------------");
    	int choice = scanner.nextInt();
    	
    	switch (choice) {
		case 1:
			bookinfo.createBook();
			break;
		case 2:
			bookinfo.Display();
			break;
		case  3:
			bookinfo.chageBookName();
			break;
		case 4:
			bookinfo.RemoveBook();
			break;
		case 5:
			bookinfo.Displayall();
			break;
		default:
		System.out.println("Invalied Choice .. . .");
			break;
		}
    	System.out.println("Do You Want Tob Continue Presss 1 :");
    	}while(scanner.nextInt()==1);
    }
}
