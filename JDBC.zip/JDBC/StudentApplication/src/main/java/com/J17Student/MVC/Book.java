package com.J17Student.MVC;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Book {
	@Id
	int BookId;
	String BookName;
	int BookCost;
	public Book(int bookId, String bookName, int bookCost) {
		super();
		BookId = bookId;
		BookName = bookName;
		BookCost = bookCost;
	}
	public Book() {
		super();
	}
	public int getBookId() {
		return BookId;
	}
	public void setBookId(int bookId) {
		BookId = bookId;
	}
	public String getBookName() {
		return BookName;
	}
	public void setBookName(String bookName) {
		BookName = bookName;
	}
	public int getBookCost() {
		return BookCost;
	}
	public void setBookCost(int bookCost) {
		BookCost = bookCost;
	}
	@Override
	public String toString() {
		return "----------------------------------\n\tBook Details\n----------------------------------\nId :" + BookId + "\nName :" + BookName + "\nCost :" + BookCost+"\n----------------------------------\n\n";
	}

}
