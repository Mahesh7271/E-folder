package com.modeltest;

import com.model.Address;
import com.model.Employee;

public class testaggregation {
	public static void main(String[] args) {
		Address address = new Address("pune", "Maharashtra", 413702);
		
		Employee employee =  new Employee(101 ,"Pankaj", 85000, address);
		employee.toString();
		
	}
}
