package com.symbiosis.Student.mvc;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Student {
	@Id
	 private int S_id;
	 private String S_Name;
	 @OneToMany
	 private List<Book> list;

	public int getS_id() {
		return S_id;
	}

	public void setS_id(int s_id) {
		S_id = s_id;
	}

	public String getS_Name() {
		return S_Name;
	}

	public void setS_Name(String s_Name) {
		S_Name = s_Name;
	}

	public List<Book> getList() {
		return list;
	}

	public void setList(List<Book> list) {
		this.list = list;
	}

	@Override
	public String toString() {
		return "Student [S_id=" + S_id + ", S_Name=" + S_Name + ", list=" + list + "]";
	}

	public Student(int s_id, String s_Name, List<Book> list) {
		super();
		S_id = s_id;
		S_Name = s_Name;
		this.list = list;
	}

	public Student() {
		super();
	}


}
