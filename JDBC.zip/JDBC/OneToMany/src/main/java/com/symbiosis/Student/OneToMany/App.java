package com.symbiosis.Student.OneToMany;

import java.util.List;
import java.util.ListIterator;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.symbiosis.Student.mvc.Book;
import com.symbiosis.Student.mvc.Student;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("TP");
        EntityManager manager =entityManagerFactory.createEntityManager();
        
        Book book = new Book(101, "JAVA ");
        Book book2 = new Book(102, "hibernate");
        List<Book> list = null;
        
        
        list.add(book);
        list.add(book2);
        
        Student student = new Student(01, "Sanket", list);

        manager.getTransaction().begin();
        
        manager.persist(book);
        manager.persist(book2);
        manager.persist(student);
        
        manager.getTransaction().commit();
        
    	
    	
    }
}
