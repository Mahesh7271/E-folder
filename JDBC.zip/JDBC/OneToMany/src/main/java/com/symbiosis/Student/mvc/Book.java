package com.symbiosis.Student.mvc;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Book{
	@Id 
	private int B_id;
	private String  Book_Name;
	public int getB_id() {
		return B_id;
	}
	public Book(int b_id, String book_Name) {
		super();
		B_id = b_id;
		Book_Name = book_Name;
	}
	@Override
	public String toString() {
		return "Book [B_id=" + B_id + ", Book_Name=" + Book_Name + "]";
	}
	public void setB_id(int b_id) {
		B_id = b_id;
	}
	public String getBook_Name() {
		return Book_Name;
	}
	public void setBook_Name(String book_Name) {
		Book_Name = book_Name;
	}
	public Book() {
		super();
	}
		
}
