package Basicclass;
public class Address 
{
	private int A_id;
	private String city ;
	private String state ;
	private String pincode ;
	
	public Address(int a_id, String city, String state, String pincode) {
		A_id = a_id;
		this.city = city;
		this.state = state;
		this.pincode = pincode;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	public int getA_id() {
		return A_id;
	}
	public void setA_id(int a_id) {
		A_id = a_id;
	}
	@Override
	public String toString() {
		return "Address [A_id=" + A_id + ", city=" + city + ", state=" + state + ", pincode=" + pincode + "]";
	}
	//mahesh
	/**
	 * mahesh
	 *1 2
	 *2 5
	 **/
	
}
