package AccountInfo;
import java.util.ArrayList;

import java.util.List;
import java.util.Scanner;

import Basicclass.Address;
import Basicclass.Custmer;
import Basicclass.Methodes;
import Dao.AccountDao;


public class AccountInfo 
{
	Methodes methodes = new Methodes();
	AccountDao  dao= new AccountDao();
	Scanner scanner = new Scanner(System.in);
	
	public String getMobileNO() 
	{
		System.out.println("Enter your Mobile number || Do not add +91/0");
		Scanner scanner = new Scanner(System.in);
		String string = scanner.next();
		String str = null;
		if(checkNumber(string))
		 str=string;
		else
			getMobileNO();
		return string;			
	}
	public String getPincodenumber() 
	{
		System.out.println("Enter your Valied Pincode number ");
		Scanner scanner = new Scanner(System.in);
		String string = scanner.nextLine();
		String str = null;
		if(checkPincode(string))
		 str=string;
		else
			getPincodenumber();
		return string;			
	}
	public  Boolean checkNumber(String string)
	{
		boolean b = false ;
		if (methodes.isVarification(string))
		{

			System.out.println("Valid Mobile Number");
		b=true;	
		}
		else
			System.out.println("not valid");
		return  b;
	}
	public  Boolean checkPincode(String string)
	{
		boolean b = false;
		if (methodes.IsValiedPincode(string))
		{

			System.out.println("Valid Mobile Number");
		b=true;	
		}
		else
			System.out.println("not valid");
		return  b;
	}
	public List<Account> CreateAccount() 
	{
		int Account_ID=methodes.RandomNumber();
		
		System.out.println("Enter Custmer F-Name\tL_name\tMobile_NO");
		Custmer custmer = new Custmer(0, scanner.next(),scanner.next(),getMobileNO());

		System.out.println("Enter your state in this format 'mh','ga',etc ");
		String state = scanner.next();
		char[] arr = methodes.getstate(state);
		String str = String.valueOf(arr);
		System.out.println(str);

		System.out.println("Enter Custmer City");
		String city = scanner.next();
		
		Address address = new Address(0,city,str,getPincodenumber());

		System.out.println("Enter your Bank type  in 'cr'-cureent |or|'sa' -saving");
		String string = scanner.next();
		char[] arr1 = methodes.getAccount(string);
		String str1 = String.valueOf(arr1);
		System.out.println(str1);

		System.out.println("\tEnter Account Balance");
		Account account = new Account(0,Account_ID,str1, scanner.nextFloat());
		List<Account> AcconutList = new ArrayList<Account>();
		AcconutList.add(account);
		dao.InsertAccount(AcconutList);
		dao.InsertAddress(address);
		dao.InsertCustmer(custmer);
		return  AcconutList;
	}
	public Account  GetAccount(int A_ID)
	{
		Account account = null;	
		account = dao.RetriveAccount(A_ID);
		return  account;
	}
	public Custmer  GetCustmer(int A_ID)
	{
		Custmer custmer =null;	
		custmer = dao.RetriveCustmer(A_ID);
		return  custmer;
	}
	public Address  GetAddress(int A_ID)
	{
		
		Address address = null;	
		address = dao.RetriveAddress(A_ID);
		return  address;
	}
	public void withFullimformation(int A_ID)
	{
		Account  account = GetAccount(A_ID);
	    Custmer  custmer = GetCustmer(A_ID);
	    Address  address = GetAddress(A_ID);
	    System.out.println("---------------------------------------------------------------------------------");
	    DisplayCustmer(custmer);
	    DisplayAccount(account);
	    DisplayAddress(address);
	}
	public void  DisplayAccount(Account account) 
	{
		System.out.println("\nAccount No\tPassword\tType\t\tBalance");
		System.out.println(+account.getA_no()+"\t\t"+account.getA_Pass()+"\t\t"+account.getA_Type()+"\t\t"+account.getA_Balance());
		}
	public void  DisplayAddress(Address account) 
	{
		System.out.println("\nCity\t\tState\tPincode");
		System.out.println(account.getCity()+"\t\t"+account.getState()+"\t"+account.getPincode());
	}
	public void  DisplayCustmer(Custmer account) 
	{
		System.out.println("first name\tLast Name\tMobile Number");
		System.out.println(account.getF_Name()+"\t\t"+account.getL_Name()+"\t\t"+account.getMobile_No());
	}
	public void  SearchAccount(int A_ID) 
	{
		Account account= GetAccount(A_ID);
	}
	public void  DeleteAccount(int A_ID) 
	{
		Account account= GetAccount(A_ID);
		DisplayAccount(account);
		dao.DeleteAccount(account);
	}
	public void modifyPassword(int passs ,int A_ID) 
	{
		Account account= GetAccount(A_ID);
	dao.UpdatePassword(account, passs);
	}

	public void withdrowAmount(Account account ,float amount) 
	{
		dao.wihtdrow(account, amount);
	}
	public void DepositAmount(Account account,float amount) 
	{
		dao.wihtdrow(account, amount);
			
	}
}
