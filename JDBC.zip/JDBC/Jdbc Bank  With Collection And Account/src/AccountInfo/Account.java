package AccountInfo;
public class Account 
{
	private int A_no;
	private int A_Pass;
	private String A_Type;
	private float A_Balance;
	public Account(int a_no, int a_Pass, String a_Type, float a_Balance) 
	{
		A_no = a_no;
		A_Pass = a_Pass;
		A_Type = a_Type;
		A_Balance = a_Balance;
	}
	public int getA_no() {
		return A_no;
	}
	public void setA_no(int a_no) {
		A_no = a_no;
	}
	public int getA_Pass() {
		return A_Pass;
	}
	public void setA_Pass(int a_Pass) {
		A_Pass = a_Pass;
	}
	public String getA_Type() {
		return A_Type;
	}
	public void setA_Type(String a_Type) {
		A_Type = a_Type;
	}
	public float getA_Balance() {
		return A_Balance;
	}
	public void setA_Balance(float a_Balance) {
		A_Balance = a_Balance;
	}
	@Override
	public String toString() {
		return "Account [A_no=" + A_no + ", A_Pass=" + A_Pass + ", A_Type=" + A_Type + ", A_Balance=" + A_Balance + "]";
	}
	
}
