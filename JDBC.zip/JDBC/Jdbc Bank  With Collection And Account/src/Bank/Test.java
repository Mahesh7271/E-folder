package Bank;

import java.util.Scanner;

public class Test 
{
	public static void main(String[] args) 
	{
		Scanner scanner = new Scanner(System.in);
		UserInterface userInterface = new UserInterface();
		AdminInterface adminInterface = new AdminInterface();
		RegularInterface regularInterface = new RegularInterface();
		do 
		{
			System.out.println("WELCOME TO LINKCODE BANK | FIRST SCREEN |");
			System.out.println("   1 - User "
						   + "\n   2 - Admin "
						   + "\n   3 - Regular"
						   + "\n   . - ...");
		System.out.println("Enter your choice......");
		int choice = scanner.nextInt();
		switch (choice) {
		case 1:
			userInterface.UserInterface();
			break;
		case 2:
			adminInterface.checkId();
			break;
		case 3:
			regularInterface.checkId();
			break;

		}
		System.out.println("Thanks For Visiting.........");
			System.out.println("---------------------------------------------------------------------------");
			System.out.println("Do you want to continue press 1 | FIRST SCREEN |");

		} while (scanner.nextInt()==1);
		}
}
// Update balance 