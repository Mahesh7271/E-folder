package com.sysmboisis.ProjectJPAFirst;


import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;


public class App 
{
    public static void main( String[] args )
    {
       EntityManagerFactory emf=Persistence.createEntityManagerFactory("TP");
    		   
       EntityManager em=emf.createEntityManager();
     
       //Finding an entity or display
       Actor a=em.find(Actor.class,1);
       System.out.println(a);
    
       //Insert Entity
       
      /* em.getTransaction().begin();  
       
       Actor a1=new Actor();
       a1.setId(5);
       a1.setName("Kajol");
       a1.setFilm("Koi mil gya");
       em.persist(a1);
       em.getTransaction().commit();
       System.out.println("Saved data");
       */
       a=em.find(Actor.class, 4);
       System.out.println(a);
       //Before updating entity
       System.out.println(a.getId()+" "+a.getName()+" "+a.getFilm());
       //Updating an entity
       em.getTransaction().begin(); 
       a.setName("Navlika");
       em.getTransaction().commit();
       System.out.println(a.getId()+" "+a.getName()+" "+a.getFilm());
    	
    }
}
