package com.symboisis.ProjectJPAPractice;

import javax.persistence.*;

@Entity
public class Customer {
	@Id
	private int id;
	private String Name;
	private int Payment;

	public Customer(int id, String name, int payment) {
		this.id = id;
		this.Name = name;
		this.Payment = payment;
	}

	public Customer() {
		super();
	}

	public int getid() {
		return id;
	}

	public void setId(int id) {
		id = id;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public int getPayment() {
		return Payment;
	}

	public void setPayment(int payment) {
		Payment = payment;
	}

	@Override
	public String toString() {
		return " ------------ Customer Details ------------ \nId=" + id + "\nName :" + Name + "\nPayment :" + Payment
				;
	}

}
