package com.symboisis.ProjectJPAPractice;

import java.security.Permissions;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.sound.midi.MidiDevice.Info;

import com.symboisis.info.customerInfo;

/**
 * Hello world!
 *
 */
public class App {
	static EntityManagerFactory emf = Persistence.createEntityManagerFactory("TP");
	static EntityManager manager = emf.createEntityManager();

	public static void main(String[] args) {
		customerInfo custinfo = new customerInfo();
		custinfo.createCustomer();
		/*
		 * for(int i = 1; i <=3; i++) { Customer customer =
		 * manager.find(Customer.class,i); System.out.println(customer); }
		 *
		 * for in display all data
		 */
			//Customer customer = new Customer(4, "Komal", 78221);
		/*
		 * manager.persist(customer);// insert data into row wise
		 * 
		 * 
		 * manager.getTransaction().commit(); System.out.println(
		 * "Data is inserted . ");
		 */

		/*
		 * for find and update customer in Name customer =
		 * manager.find(Customer.class,4); System.out.println(customer.getid()+
		 * " "+customer.getName()+""+customer.getPayment()); customer.setName(
		 * "Komal Bhadane"); manager.getTransaction().commit();
		 * System.out.println(manager.find(Customer.class,4));
		 */

/*		manager.getTransaction().begin();
		Customer customer = manager.find(Customer.class, 4);
		manager.remove(customer);
		System.out.println("Data will be remove. . .");
		manager.getTransaction().commit();
*/	}
}
