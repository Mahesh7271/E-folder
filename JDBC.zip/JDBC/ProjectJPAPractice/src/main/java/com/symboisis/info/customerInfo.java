package com.symboisis.info;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.symboisis.ProjectJPAPractice.Customer;

public class customerInfo {
	EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("TP");
	EntityManager manager = entityManagerFactory.createEntityManager();

	public void begin() {
		manager.getTransaction().begin();
	}
	public void commit() {
		manager.getTransaction().commit();
	}

	public void createCustomer() {
		begin();
		Customer customer = new Customer(6, "narayn",452000);
		
		manager.persist(customer);
		System.out.println("data insert");
		commit();
	}
}
