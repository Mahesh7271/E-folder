package com.model;

import javax.persistence.*;

@Entity
public class Cources {
	@Id
	//@GeneratedValue(strategy = GenerationType.AUTO)
	private int CourseId;
	private String CourseName;

	/**
	 * 
	 */
	public Cources() {
		super();
	}

	public Cources(int courseId, String courseName) {
		super();
		CourseId = courseId;
		CourseName = courseName;
	}

	public int getCourseId() {
		return CourseId;
	}

	public void setCourseId(int courseId) {
		CourseId = courseId;
	}

	public String getCourseName() {
		return CourseName;
	}

	public void setCourseName(String courseName) {
		CourseName = courseName;
	}

	@Override
	public String toString() {
		return "Cources [CourseId=" + CourseId + ", CourseName=" + CourseName + "]";
	}

}
