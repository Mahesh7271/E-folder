package com.model;

import java.util.List;

import javax.persistence.*;

@Entity
public class Project {
@Id

@GeneratedValue(strategy = GenerationType.AUTO)
int id;
private String name;
@ManyToMany
List<Employee> list;
/**
 * @param id
 * @param name
 * @param list
 */
public Project(int id, String  name, List<Employee> list) {
	super();
	this.id = id;
	this.name = name;
	this.list = list;
}
/**
 * @param name
 */
public Project(String name) {
	super();
	this.name = name;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public List<Employee> getList() {
	return list;
}
public void setList(List<Employee> list) {
	this.list = list;
}
@Override
public String toString() {
	return "Project [id=" + id + ", name=" + name + ", list=" + list + "]";
} 



}
