package com.Controller;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.model.Cources;
import com.model.Student;

public class StudentController {
	public static void main(String[] args) {
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("TP");
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		
		Cources c1 = new Cources(234, "Java");
		Cources c2 = new Cources(235, "HTML");
		em.persist(c1);
		em.persist(c2);
		em.getTransaction().commit();

		em.getTransaction().begin();
		Student s1 = new Student();
		Student s2 = new Student();
		s1.setName("Mahesh");
		s2.setName("Rutuja");

		
		em.persist(s1);
		em.persist(s2);

		em.getTransaction().commit();
		System.out.println("Data Saved");

	}
}
