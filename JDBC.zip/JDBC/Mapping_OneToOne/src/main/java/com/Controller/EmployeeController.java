package com.Controller;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.model.Employee;
import com.model.Project;

public class EmployeeController {
	public static void main(String[] args) {
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("TP");
		EntityManager entityManager = entityManagerFactory.createEntityManager();

		Employee employee1 = new Employee("mahesh");
		Employee employee2 = new Employee("pankaj");

		Project project1 = new Project("java WEb");
		Project project2 = new Project("Html");

		List<Project> projects = new ArrayList<Project>();
		List<Employee> employees = new ArrayList<Employee>();

		
		employee1.setProjects(projects);
		project1.setList(employees);

		employee2.setProjects(projects);
		project2.setList(employees);

		entityManager.getTransaction().begin();
		entityManager.persist(project1);
		entityManager.persist(project2);
		entityManager.persist(employee1);
		entityManager.persist(employee2);
		entityManager.getTransaction().commit();
	}
}
