package com.SwitchBank;

public class adminInterface {
	public void adminScreen() {
		
	}
}
