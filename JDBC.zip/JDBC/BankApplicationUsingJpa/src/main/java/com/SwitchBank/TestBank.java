package com.SwitchBank;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.SwitchBank.Model.Account;
import com.SwitchBank.Model.Address;
import com.SwitchBank.Model.Customer;

public class TestBank {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		NewuserInterface newuserInterface = new NewuserInterface();
		adminInterface adminInterface = new adminInterface();
		regularInterface regularInterface= new regularInterface();
		do {

			System.out.println("---------------------------------------------------------------");
			System.out.println("          Welcome To Switch Bank in Pune");
			System.out.println("---------------------------------------------------------------");
			System.out.println("1 New User Screen");
			System.out.println("2 Regular User Screen");
			System.out.println("3 Admin User Screen");
			System.out.println("---------------------------------------------------------------");
			System.out.println("Enter Your choice");
			switch (scanner.nextInt()) {
			case 1:
				newuserInterface.newUserScreen();
				break;
			case 2:
				regularInterface.regularScreen();
				break;
			case 3:
				adminInterface.adminScreen();
				break;

			default:
				System.out.println("Invalied Choice . . . ");
				break;
			}
			System.out.println("Do you want to continue press . . . [yes] or [1]");
		} while (scanner.next().equals("yes"));
	}
}
