package com.SwitchBank;

import java.util.Scanner;

import com.SwitchBank.Model.Account;
import com.SwitchBank.info.NewUserInfo;

public class NewuserInterface {
	public void newUserScreen() {
		Scanner scanner = new Scanner(System.in);
		NewUserInfo info = new NewUserInfo();
		do {

			System.out.println("---------------------------------------------------------------");
			System.out.println("          Welcome To Switch Bank in Pune");
			System.out.println("------------------------------------------New_User_Screen------");
			System.out.println("1 Create Account ");
			System.out.println("");
			System.out.println("");
			System.out.println("---------------------------------------------------------------");
			System.out.println("Enter Your choice");
			switch (scanner.nextInt()) {
			case 1:
				Account account = info.createAccount();
				info.displayAccount(account);
				break;

			default:
				System.out.println("Invalied Choice . . . ");
				break;
			}
			System.out.println("Do you want to continue press . . . [yes] or [1]");
		} while (scanner.next().equals("yes") || scanner.next().equals("1"));
	}
}
