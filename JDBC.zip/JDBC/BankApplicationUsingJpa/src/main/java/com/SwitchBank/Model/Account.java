package com.SwitchBank.Model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Account {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int account_Number;
	@OneToOne
	private Customer customer;
	private int account_Password;
	private String account_Type;
	private double account_Balance;
	@OneToOne
	private Address address;
	
	public Account(Customer customer, int account_Password, String  account_Type,
			double account_Balance, Address address) {
		super();
		this.customer = customer;
		this.account_Password = account_Password;
		this.account_Type = account_Type;
		this.account_Balance = account_Balance;
		this.address = address;
	}
	@Override
	public String toString() {
		return "Account [customer=" + customer + ", account_Number=" + account_Number + ", account_Password="
				+ account_Password + ", account_Type=" + account_Type + ", account_Balance=" + account_Balance
				+ ", address=" + address + "]";
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public int getAccount_Number() {
		return account_Number;
	}
	public void setAccount_Number(int account_Number) {
		this.account_Number = account_Number;
	}
	public int getAccount_Password() {
		return account_Password;
	}
	public void setAccount_Password(int account_Password) {
		this.account_Password = account_Password;
	}
	public String getAccount_Type() {
		return account_Type;
	}
	public void setAccount_Type(String account_Type) {
		this.account_Type = account_Type;
	}
	public double getAccount_Balance() {
		return account_Balance;
	}
	public void setAccount_Balance(double account_Balance) {
		this.account_Balance = account_Balance;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	
}
