package com.SwitchBank.info;

import com.SwitchBank.Model.Account;

public class AccountInfo {
	public void displayAccount() {

	}
}
