package com.SwitchBank.Model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


@Entity
public class Customer {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int customerId;
	private String customerF_Name;
	private String customerL_Name;
	private String customer_mobile;
	public Customer(String customerF_Name, String customerL_Name, String customer_mobile) {
		super();
		this.customerF_Name = customerF_Name;
		this.customerL_Name = customerL_Name;
		this.customer_mobile = customer_mobile;
	}
	public String getCustomerF_Name() {
		return customerF_Name;
	}
	public void setCustomerF_Name(String customerF_Name) {
		this.customerF_Name = customerF_Name;
	}
	public String getCustomerL_Name() {
		return customerL_Name;
	}
	public void setCustomerL_Name(String customerL_Name) {
		this.customerL_Name = customerL_Name;
	}
	public String getCustomer_mobile() {
		return customer_mobile;
	}
	public void setCustomer_mobile(String customer_mobile) {
		this.customer_mobile = customer_mobile;
	}
	@Override
	public String toString() {
		return "Customer [customerF_Name=" + customerF_Name + ", customerL_Name=" + customerL_Name
				+ ", customer_mobile=" + customer_mobile + "]";
	}
	
}
