package com.SwitchBank;

import java.util.Scanner;

import com.SwitchBank.info.AccountInfo;

public class regularInterface {
	public void regularScreen() {
		Scanner scanner = new Scanner(System.in);
		AccountInfo info = new AccountInfo();
		Object check;
		do {

			System.out.println("---------------------------------------------------------------");
			System.out.println("          Welcome To Switch Bank in Pune");
			System.out.println("--------------------------------------Regular_User_Screen------");
			System.out.println("1 Display Account ");
			System.out.println(" ");
			System.out.println("");
			System.out.println("---------------------------------------------------------------");
			System.out.println("Enter Your choice");
			switch (scanner.nextInt()) {
			case 1:
				
				break;

			default:
				System.out.println("Invalied Choice . . . ");
				break;
			}
			System.out.println("Do you want to continue press . . . [yes] or [1]");
		check =scanner.next(); 
		} while (check.equals("yes"));

	}
}
