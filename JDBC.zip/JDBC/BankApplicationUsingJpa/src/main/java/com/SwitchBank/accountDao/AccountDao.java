package com.SwitchBank.accountDao;

import javax.persistence.EntityManager;

import com.SwitchBank.Methodes.Methods;
import com.SwitchBank.Model.Account;

public class AccountDao {
	EntityManager manager = Methods.getEntityManager();

	public void start() {
		manager.getTransaction().begin();
	}

	public void save() {
		manager.getTransaction().commit();
	}

	public void InsertAccount(Account account) {
		start();
		manager.persist(account);
		save();
		
	}
}
