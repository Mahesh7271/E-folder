package com.SwitchBank.Model;


import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Admin {
	@OneToOne
	private Customer customer;
	@Id
	private int admin_Number;
	private int admin_Password;
	private String admin_Position;

	public Admin(Customer customer, int admin_Number, int admin_Password, String admin_Position) {
		super();
		this.customer = customer;
		this.admin_Number = admin_Number;
		this.admin_Password = admin_Password;
		this.admin_Position = admin_Position;
	}

	@Override
	public String toString() {
		return "Admin [customer=" + customer + ", admin_Number=" + admin_Number + ", admin_Password=" + admin_Password
				+ ", admin_Position=" + admin_Position + "]";
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public int getAdmin_Number() {
		return admin_Number;
	}

	public void setAdmin_Number(int admin_Number) {
		this.admin_Number = admin_Number;
	}

	public int getAdmin_Password() {
		return admin_Password;
	}

	public void setAdmin_Password(int admin_Password) {
		this.admin_Password = admin_Password;
	}

	public String getAdmin_Position() {
		return admin_Position;
	}

	public void setAdmin_Position(String admin_Position) {
		this.admin_Position = admin_Position;
	}

}
