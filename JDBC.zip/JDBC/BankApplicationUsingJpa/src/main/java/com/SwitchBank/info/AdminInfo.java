package com.SwitchBank.info;

public class AdminInfo {

}
