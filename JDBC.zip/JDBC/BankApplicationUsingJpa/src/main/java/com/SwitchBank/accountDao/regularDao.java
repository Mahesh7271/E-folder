package com.SwitchBank.accountDao;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.SwitchBank.Methodes.Methods;
import com.SwitchBank.Model.Account;

public class regularDao {
	EntityManager manager = Methods.getEntityManager();

	public void start() {
		manager.getTransaction().begin();
	}

	public void save() {
		manager.getTransaction().commit();
	}
public void FindAccont() {
}
}
