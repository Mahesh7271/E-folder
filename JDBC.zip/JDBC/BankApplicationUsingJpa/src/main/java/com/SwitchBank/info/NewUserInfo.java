package com.SwitchBank.info;

import java.util.Scanner;

import com.SwitchBank.Methodes.Methods;
import com.SwitchBank.Model.Account;
import com.SwitchBank.Model.Address;
import com.SwitchBank.Model.Customer;

public class NewUserInfo {
	Scanner scanner = new Scanner(System.in);
	Methods method = new Methods();

	public Account createAccount() {
		System.out.println("Enter Your Fisrtname\tLastname\tmobile number");
		Customer customer = new Customer(scanner.next(), scanner.next(), scanner.next());
		System.out.println("Enter Your City\tState\tPincode");
		Address address = new Address(scanner.next(), scanner.next(), scanner.nextInt());
		int account_Password = method.getPassword();
		System.out.println("Enter Your Account Type\tAccount Amount\t(Amount must be above 500)");
		String account_Type = method.getAccountType(scanner.next());
		Account account = new Account(customer, account_Password, account_Type, scanner.nextInt(), address);
		
		return account;
	}

	public void displayAccount(Account account) {
		System.out.println(account);
	}

}
