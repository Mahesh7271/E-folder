package Dao;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Connection;

public class Myconnection 
{
	public static Connection GetDataBaseConnetivity()
	{
		 Connection connection = null;
		try 
		{
			Class.forName("oracle.jdbc.OracleDriver");
		 connection =DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","system");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return  connection;
	}

}
