package Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.LinkedList;

import Model.product;

public class ProductDao 
{
	Connection  connection = Myconnection.GetDataBaseConnetivity();
	public void AddProduct(product product)
	{/*
		insert into product values(product_id.nextval,'Mahesh',2010,20,'mens','male','28/02/2000');*/
		try 
		{
			PreparedStatement preparedStatement = connection.prepareStatement("insert into product values(product_id.nextval,?,?,?,?,?,?)");
			preparedStatement .setString(1,product.getProductName());
			preparedStatement.setFloat(2,product.getProductPrice());
			preparedStatement.setInt(3,product.getProductQty());
			preparedStatement.setString(4,product.getProductType());
			preparedStatement.setString(5,product.getProductSubtype());
			preparedStatement.setString(6,product.getProductDate());
			
			preparedStatement.execute();
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
