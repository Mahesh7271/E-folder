package Dao;

public class AdminDao {

}
