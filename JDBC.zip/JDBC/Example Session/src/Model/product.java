package Model;

public class product {
	private int ProductID;
	private String ProductName;
	private float ProductPrice;
	private int ProductQty; 
	private String ProductType; 
	private String ProductSubtype;
	private String ProductDate;
	
	public int getProductID() {
		return ProductID;
	}
	public void setProductID(int productID) {
		ProductID = productID;
	}
	public String getProductName() {
		return ProductName;
	}
	public void setProductName(String productName) {
		ProductName = productName;
	}
	public float getProductPrice() {
		return ProductPrice;
	}
	public void setProductPrice(float productPrice) {
		ProductPrice = productPrice;
	}
	public int getProductQty() {
		return ProductQty;
	}
	public void setProductQty(int productQty) {
		ProductQty = productQty;
	}
	public String getProductType() {
		return ProductType;
	}
	public void setProductType(String productType) {
		ProductType = productType;
	}
	public String getProductSubtype() {
		return ProductSubtype;
	}
	public void setProductSubtype(String productSubtype) {
		ProductSubtype = productSubtype;
	}
	
	public String getProductDate() {
		return ProductDate;
	}
	public void setProductDate(String productDate) {
		ProductDate = productDate;
	}
	public product(int productID, String productName, float productPrice, int productQty, String productType,
			String productSubtype, String productDate) {
		super();
		ProductID = productID;
		ProductName = productName;
		ProductPrice = productPrice;
		ProductQty = productQty;
		ProductType = productType;
		ProductSubtype = productSubtype;
		ProductDate = productDate;
	}
	
	
	}
