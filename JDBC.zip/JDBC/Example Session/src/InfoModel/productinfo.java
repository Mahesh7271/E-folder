package InfoModel;

import java.util.LinkedList;

import Dao.ProductDao;
import Model.product;

public class productinfo 
{
	ProductDao dao = new ProductDao();
	public void Addproduct(LinkedList<product> list) 
	{
		for (product product : list) {
			dao.AddProduct(product);
		}
	}
}
