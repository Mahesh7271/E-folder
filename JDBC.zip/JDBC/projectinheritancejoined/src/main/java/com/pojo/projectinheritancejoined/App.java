package com.pojo.projectinheritancejoined;


public class App 
{
    public static void main( String[] args )
    {
       
    }
}
