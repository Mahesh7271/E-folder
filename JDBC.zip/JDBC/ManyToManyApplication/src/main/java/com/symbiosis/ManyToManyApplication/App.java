package com.symbiosis.ManyToManyApplication;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.hibernate.service.spi.Startable;

import com.symbiosis.POJO.Library;
import com.symbiosis.POJO.Student;

public class App {
/*	static EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("TP");
	static EntityManager manager = entityManagerFactory.createEntityManager();

	public static void start() {
		manager.getTransaction().begin();
	}

	public static void save() {
		manager.getTransaction().commit();
	}
*/
	public static void main(String[] args) {
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("TP");
		EntityManager manager = entityManagerFactory.createEntityManager();
		
		manager.getTransaction().begin();
		
		Student student = new Student();
		Student student1 = new Student();
		student.setS_id(01);
		student.setS_name("Mahesh");
		
		student1.setS_id(02);
		student1.setS_name("tejas");

		manager.persist(student);
		manager.persist(student1);

		ArrayList<Student> list2 = new ArrayList<Student>();
		ArrayList<Student> list1 = new ArrayList<Student>();

		list1.add(student);
		list1.add(student1);

		list2.add(student);
		list2.add(student1);

		Library library = new Library(101, "DATA Structure", list1);
		Library library1 = new Library(102, "Java ", list2);

		manager.persist(library);
		manager.persist(library1);
manager.getTransaction().commit();
		manager.close();
	}
}
