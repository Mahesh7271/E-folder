package com.symbiosis.POJO;

public class Employee {

}
