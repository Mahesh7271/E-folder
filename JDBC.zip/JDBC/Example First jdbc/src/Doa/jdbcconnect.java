package Doa;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class jdbcconnect {
	public static void main(String[] args) throws Exception {
		Connection con = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/mahesh", "root", "system");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		if (con == null) {
			System.out.println("Connection not  . . . ");
		} else {
			System.out.println("connected . . .");
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("select  * from exstudent");

			while (rs.next()) {
				int roll = rs.getInt(1);
				String name = rs.getString(2);
				String city = rs.getString(3);
				System.out.println(
"student roll name city \n\t" + rs.getString("id") + " " + rs.getString("name") + " " + rs.getString("city"));

			}
		}
	}
}
