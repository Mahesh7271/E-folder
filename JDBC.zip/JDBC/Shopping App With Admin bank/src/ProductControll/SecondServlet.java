package ProductControll;

import java.io.IOException;

import java.io.PrintWriter;
import java.util.LinkedList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import ProductInfo.product;


/**
 * Servlet implementation class SecondServlet
 */
@WebServlet("/SecondServlet")
public class SecondServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SecondServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out  = response.getWriter();
		HttpSession session = request.getSession();
		LinkedList<product> list= new LinkedList<product>();
		list = (LinkedList<product>) session.getAttribute("uname");
		int j=1;
		float price = 0;
		out.print("<Table border =2px solid green  height=12 padding:15px>");
		out.print("<tr>"
				+ "<td>\t\t Sr.No           < /td>");
		out.print("<td>\t\t Product Id      </td>");
		out.print("<td>\t\t Product Name    </td>");
		out.print("<td>\t\t Product Price   </td>");
		out.print("<td>\t\t Product Type    </td>");
		out.print("<td>\t\t Product SubType </td>");
		out.print("<td>\t\t Product Date    </td>");
		out.print("<td>\t\t Product Qty     </td>"
				+ "</tr>");
		for (product product: list) {
		
			out.print("<tr>"
					+ "<td>\t\t "+(j)+"</td>");
			out.print("<td>\t\t "+product.getProductID()+"      </td>");
			out.print("<td>\t\t "+product.getProductName()+"    </td>");
			out.print("<td>\t\t "+product.getProductPrice()+"   </td>");
			out.print("<td>\t\t "+product.getProductType()+"    </td>");
			out.print("<td>\t\t "+product.getProductSubtype()+" </td>");
			out.print("<td>\t\t "+product.getProductDate()+"    </td>");
			out.print("<td>\t\t "+product.getProductQty()+"     </td>"
					+ "</tr>");
			j++;
		}	
				out.print("<Table>");

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
