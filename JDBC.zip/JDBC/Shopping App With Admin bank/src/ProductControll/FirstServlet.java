package ProductControll;

import java.io.IOException;


import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import ProductInfo.product;
import ProductInfo.productinfo;


/**
 * Servlet implementation class FirstServlet
 */
@WebServlet("/FirstServlet")
public class FirstServlet extends HttpServlet {
	LinkedList<product>  productlist = new LinkedList<product>();
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FirstServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		productinfo info = new productinfo();
		String str = request.getParameter("name");
		String add = request.getParameter("add");
		float price = Float.parseFloat(request.getParameter("price"));
		int qty = Integer.parseInt(request.getParameter("qty"));
		String prodType = request.getParameter("type");  
		String ProdSubType = request.getParameter("subtype");
		String ProdDate = request.getParameter("date");
		String yes ="yes";
		String no = "no";
					
		product product = new product(0, str, price, qty, prodType, ProdSubType, ProdDate);
		productlist.add(product);
		
		if (add.contains(yes))
		{
			response.sendRedirect("AddProduct.html");
		}
		else
		{
			HttpSession session = request.getSession();
			session.setAttribute("uname",productlist);
			info.Addproduct(productlist);
			response.sendRedirect("SecondServlet");
				
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
