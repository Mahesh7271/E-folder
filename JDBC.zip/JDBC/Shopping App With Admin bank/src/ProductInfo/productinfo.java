package ProductInfo;

import java.util.LinkedList;

import Dao.ProductDao; 

public class productinfo 
{
	ProductDao dao = new ProductDao();
	public void Addproduct(LinkedList<product> list) 
	{
		for (product product : list) {
			dao.AddProduct(product);
		}
	}
}
