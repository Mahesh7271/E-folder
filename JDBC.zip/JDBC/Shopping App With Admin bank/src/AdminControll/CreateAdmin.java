package AdminControll;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import AdminInfo.Admin;
import Basicclass.Address;
import Basicclass.Methodes;
import Dao.AdminDao;

/**
 * Servlet implementation class CreateAdmin
 */
@WebServlet("/CreateAdmin")
public class CreateAdmin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CreateAdmin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	String fname = request.getParameter("fname");
	String lname = request.getParameter("lname");
	String state = request.getParameter("state");
	String city  = request.getParameter("city");
	String pincode  = request.getParameter("pincode");
	Basicclass.Methodes methodes = new Methodes();
	int pass=methodes.RandomNumber();
	Admin admin = new Admin(0, pass, fname, lname);
	Address address = new Address(0, city, state, pincode);
	Dao.AdminDao dao = new AdminDao();
	
	System.out.println(admin);
	int i=dao.InsertValues(admin);
	int j=dao.InsertAD_address(address);
	if (i>0) 
	{
		PrintWriter out = response.getWriter();
		out.print("<h3> Save Data</h3>");
	}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
