package Dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import AccountInfo.Account;
import AdminInfo.Admin;
import Basicclass.Address;
import Basicclass.Custmer;

public class AccountDao {
	Connection connection = Myconnection.GetDataBaseConnetivity();

	public int InsertAccount(List<Account> ListAccount) {
		int i = 0;
		Account acc = ListAccount.get(0);
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("insert into LinkcodeBank values(account_no.nextval,?,?,?) ");
			preparedStatement.setInt(1, acc.getA_Pass());
			preparedStatement.setString(2, acc.getA_Type());
			preparedStatement.setFloat(3, acc.getA_Balance());
			i = preparedStatement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;
	}

	public Account RetriveAccount(int A_ID) {
		Account account = null;
		try {

			PreparedStatement preparedStatement = connection
					.prepareStatement("  select * from linkcodebank where A_no = ?");
			preparedStatement.setInt(1, A_ID);
			ResultSet resultSet = preparedStatement.executeQuery();
			boolean i = resultSet.next();
			/*
			 * if (i) System.out.println(
			 * " 1 rows returned in 0.36 seconds	..\n"); else
			 * System.out.println("Table or view does not exist..");
			 */ account = new Account(resultSet.getInt(1), resultSet.getInt(2), resultSet.getString(3),
					resultSet.getFloat(4));
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return account;
	}

	public Address RetriveAddress(int A_ID) {
		Address address = null;
		try {

			PreparedStatement preparedStatement = connection
					.prepareStatement("select * from linkcodeaddress where A_id = ?");
			preparedStatement.setInt(1, A_ID);
			ResultSet resultSet = preparedStatement.executeQuery();
			boolean i = resultSet.next();
			// if (i)
			// System.out.println(" 1 rows returned in 0.36 seconds ..\n");
			// else
			// System.out.println("Table or view does not exist..");
			address = new Address(resultSet.getInt(1), resultSet.getString(2), resultSet.getString(3),
					resultSet.getString(4));
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return address;
	}

	public Custmer RetriveCustmer(int A_ID) {
		Custmer custmer = null;
		try {

			PreparedStatement preparedStatement = connection
					.prepareStatement("select * from linkcodecustmer where C_id = ?");
			preparedStatement.setInt(1, A_ID);
			ResultSet resultSet = preparedStatement.executeQuery();
			boolean i = resultSet.next();
			// if (i)
			// System.out.println(" 1 rows returned in 0.36 seconds ..\n");
			// else
			// System.out.println("Table or view does not exist..");
			custmer = new Custmer(resultSet.getInt(1), resultSet.getString(2), resultSet.getString(3),
					resultSet.getString(4));
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return custmer;
	}

	public int UpdatePassword(Account account, int newPass) {
		int i3 = 0;
		try {
			PreparedStatement PState1 = connection.prepareStatement("update LinkcodeBank set A_Pass=? where A_NO =?");
			PState1.setInt(2, account.getA_no());
			PState1.setInt(1, newPass);
			i3 = PState1.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		// if (i3 > 0)
		// System.out.println("1 row(s) updated ....\n");
		// else
		// System.out.println("table or view does not exist");
		return i3;
	}

	public void DeleteAccount(Account account) {
		int i3 = 0;
		try {
			PreparedStatement PState1 = connection.prepareStatement("DELETE FROM linkcodebank WHERE A_NO = ?");
			PState1.setInt(1, account.getA_no());
			i3 = PState1.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		// if (i3 > 0)
		// System.out.println("1 row(s) deleted ....\n");
		// else
		// System.out.println("table or view does not exist");
	}


	public boolean DeleteAccount(int  A_NO) {
		boolean b = false;
		try {
			PreparedStatement PState1 = connection.prepareStatement("DELETE FROM linkcodebank WHERE A_NO = ?");
			PState1.setInt(1, A_NO);
			b = PState1.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		// if (i3 > 0)
		// System.out.println("1 row(s) deleted ....\n");
		// else
		// System.out.println("table or view does not exist");
		return b;
	}
	public boolean DeleteAddress(int  A_NO) {
		boolean b = false;
		try {
			PreparedStatement PState1 = connection.prepareStatement("DELETE FROM linkcodeaddress WHERE A_id = ?");
			PState1.setInt(1, A_NO);
			b = PState1.execute();
			} catch (SQLException e) {
			e.printStackTrace();
		}
		return b;
		
		// if (i3 > 0)
		// System.out.println("1 row(s) deleted ....\n");
		// else
		// System.out.println("table or view does not exist");
	}

	public boolean DeleteCustmer(int  A_NO) {
		boolean b = false;
		try {
			PreparedStatement PState1 = connection.prepareStatement("DELETE FROM linkcodecustmer WHERE c_id = ?");
			PState1.setInt(1, A_NO);
			b = PState1.execute();
			} catch (SQLException e) {
			e.printStackTrace();
		}
		return b;
		
		// if (i3 > 0)
		// System.out.println("1 row(s) deleted ....\n");
		// else
		// System.out.println("table or view does not exist");
	}
	public LinkedList<Account> RetriveAllAccount() {
		LinkedList<Account> listaccount = new LinkedList<Account>();
		Account account = null;
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("select * from Linkcodebank order by A_no");
			ResultSet resultSet = preparedStatement.executeQuery();
			boolean i = resultSet.next();
			while (resultSet.next()) {

				account = new Account(resultSet.getInt(1), resultSet.getInt(2), resultSet.getString(3),
						resultSet.getFloat(4));
				listaccount.add(account);
			}
			// if (i)
			// System.out.println("1 rows returned in 0.08 seconds...\n");
			// else
			// System.out.println("table or view does not exist");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return listaccount;
	}

	public LinkedList<Custmer> RetriveAllCustmer() {
		LinkedList<Custmer> listaccount = new LinkedList<Custmer>();
		Custmer account = null;
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("select * from Linkcodecustmer order by C_id");
			ResultSet resultSet = preparedStatement.executeQuery();
			boolean i = resultSet.next();
			while (resultSet.next()) {

				account = new Custmer(resultSet.getInt(1), resultSet.getString(2), resultSet.getString(3),
						resultSet.getString(4));
				listaccount.add(account);
			}
			// if (i)
			// System.out.println("1 rows returned in 0.08 seconds...\n");
			// else
			// System.out.println("table or view does not exist");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return listaccount;
	}

	public LinkedList<Address> RetriveAllAddress() {
		LinkedList<Address> listaccount = new LinkedList<Address>();
		Address account = null;
		try {
			PreparedStatement preparedStatement = connection.prepareStatement("select * from linkcodeaddress order by A_id");
			ResultSet resultSet = preparedStatement.executeQuery();
			boolean i = resultSet.next();
			while (resultSet.next()) {
				account = new Address(resultSet.getInt(1), resultSet.getString(2), resultSet.getString(3),
						resultSet.getString(4));
				listaccount.add(account);
			}
			// if (i)
			// System.out.println("1 rows returned in 0.08 seconds...\n");
			// else
			// System.out.println("table or view does not exist");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return listaccount;
	}

	public int InsertAddress(Address address) {
		int i = 0;
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("insert into Linkcodeaddress values(address_no.nextval,?,?,?)");
			preparedStatement.setString(1, address.getCity());
			preparedStatement.setString(2, address.getState());
			preparedStatement.setString(3, address.getPincode());
			i = preparedStatement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;

	}

	public int InsertCustmer(Custmer custmer) {
		int i = 0;
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("insert into Linkcodecustmer values(Custmer_no.nextval,?,?,?) ");
			preparedStatement.setString(1, custmer.getF_Name());
			preparedStatement.setString(2, custmer.getL_Name());
			preparedStatement.setString(3, custmer.getMobile_No());

			i = preparedStatement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;
	}

	public void wihtdrow(Account account, float amount) {
		int i3 = 0;
		try {
			PreparedStatement PState1 = connection
					.prepareStatement("update LinkcodeBank set A_BALANCE=? where A_NO =?");
			PState1.setInt(2, account.getA_no());
			PState1.setFloat(1, amount);
			i3 = PState1.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} /*
			 * if (i3>0) System.out.println("1 row(s) updated ....\n"); else
			 * System.out.println("table or view does not exist");
			 */
	}
}
