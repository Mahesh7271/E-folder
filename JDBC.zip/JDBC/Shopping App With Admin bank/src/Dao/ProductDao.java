package Dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;

import ProductInfo.product;


public class ProductDao 
{
	Connection  connection = Myconnection.GetDataBaseConnetivity();
	public void AddProduct(product product)
	{/*
		insert into product values(product_id.nextval,'Mahesh',2010,20,'mens','male','28/02/2000');*/
		try 
		{
			PreparedStatement preparedStatement = connection.prepareStatement("insert into product values(product_id.nextval,?,?,?,?,?,?)");
			preparedStatement.setString(1,product.getProductName());
			preparedStatement.setFloat(2,product.getProductPrice());
			preparedStatement.setInt(3,product.getProductQty());
			preparedStatement.setString(4,product.getProductType());
			preparedStatement.setString(5,product.getProductSubtype());
			preparedStatement.setString(6,product.getProductDate());
			
			preparedStatement.execute();
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public LinkedList<product> SearchProducts(int pid,String sub,String subtype) 
	{
		LinkedList<product> list = null;
		/*select * from  product where pid =100 or pname = 'mahesh' or pprice= 64
		*/
		try 
		{
			PreparedStatement preparedStatement = connection.prepareStatement("select * from product where pid=? or ptype=? or psubtype=?");
			preparedStatement.setInt(1, pid);
			preparedStatement.setString(2, sub);
			preparedStatement.setString(3, subtype);
			
			ResultSet resultSet =preparedStatement.executeQuery();
		while (resultSet.next()) {
			product product = new product(resultSet.getInt(1), resultSet.getString(2),resultSet.getFloat(3),resultSet.getInt(4),resultSet.getString(5),resultSet.getString(6), resultSet.getString(7));
			list.add(product);
		}
		
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return  list;
	
	}
}
