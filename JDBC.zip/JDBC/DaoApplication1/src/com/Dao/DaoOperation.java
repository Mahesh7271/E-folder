package com.Dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;

import com.model.RegistrationModel;

import registration.model.Myconnection;
public class DaoOperation {
	
	public static void register(List<RegistrationModel> emplist){
		
		try {
			
			Connection con=Myconnection.connect();
			PreparedStatement pstat=con.prepareStatement("Insert into Registration values(?,?,?,?,?,?,?)");
			
			for(RegistrationModel s:emplist){
				
				pstat.setString(1, s.getEmpid());
				pstat.setString(2, s.getFname());
				pstat.setString(3, s.getLname());
				pstat.setString(4, s.getUname());
				pstat.setString(5, s.getPhoneno());
				pstat.setString(6, s.getEmailid());
				pstat.setString(7, s.getPassword());
				System.out.println(s.getPhoneno());
			}
			
			int i=pstat.executeUpdate();
			if(i>0){
				System.out.println("Registration Successfull");
			}
			else{
				System.out.println("Error");
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
}
	
	
	public List<RegistrationModel> retrive(String empid){
		
		Connection con=Myconnection.connect();
		List<RegistrationModel> lst=null;
		String str="select * from registration where empid=?";
		 try {
		     PreparedStatement pstat=con.prepareStatement(str);
		     pstat.setString(1, empid);
		     ResultSet rst=pstat.executeQuery();
		if(rst.next()){
			 RegistrationModel r=new RegistrationModel(rst.getString(1),rst.getString(2),rst.getString(3),rst.getString(4),rst.getString(5),rst.getString(6),rst.getString(7));
			 lst=new ArrayList<RegistrationModel>();
			 lst.add(r);
		}
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	    return lst;
	}
	
	public boolean update(String empid,String emailid){

		Boolean b=false;     
		Connection con=Myconnection.connect();
		     
		     try {
				PreparedStatement ps=con.prepareStatement("update registration set emailid=? where empid=?");
				ps.setString(1, emailid);
				ps.setString(2, empid);
                int i=ps.executeUpdate();
                if(i>0){
                	b=true;
                }
                
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return b;
		}
	
	
	public boolean delete(String empid){
		
		  Connection con=Myconnection.connect();
		  boolean b=false;
		  try {
			PreparedStatement ps=con.prepareStatement("delete from registration where empid=?");
			ps.setString(1, empid);
			int i=ps.executeUpdate();
			if(i>0){
				b=true;
				
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return b;
		
		
	}
	
	public List<RegistrationModel> display(){
		
		List<RegistrationModel> lst=new LinkedList<RegistrationModel>();
		 Connection con=Myconnection.connect();
		 String str= "select * from registration";
		 try {
			     Statement stat=con.createStatement();
			     ResultSet rst=stat.executeQuery(str);
			while(rst.next()){
				    lst.add(new RegistrationModel(rst.getString(1),rst.getString(2),rst.getString(3),rst.getString(4),rst.getString(5),rst.getString(6),rst.getString(7)));
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lst;
	}
	

}
