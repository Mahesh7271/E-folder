package com.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import registration.model.Myconnection;

public class LoginDao {

	     public Boolean login(String emailid,String password){
	    	 
	    	 Boolean b=false;
	    	 Connection con=Myconnection.connect();
	    	 
	    	 try {
				PreparedStatement pst=con.prepareStatement("select * from registration where emailid=? and password=?");
				pst.setString(1, emailid);
				pst.setString(2, password);
				
				ResultSet rst=pst.executeQuery();
				while(rst.next()){
					b=true;
				}
				
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return b;
	     }
	
	
	
}
