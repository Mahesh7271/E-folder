package com.controller;


import java.io.IOException;
import java.util.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Dao.DaoOperation;
import com.model.RegistrationModel;

/**
 * Servlet implementation class Registrationcontroller
 */
@WebServlet("/Registrationcontroller")
public class Registrationcontroller extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Registrationcontroller() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<RegistrationModel> emplist=new LinkedList<>();
		
		String empid=request.getParameter(("empid"));
		String fname=request.getParameter("fname");
		String lname=request.getParameter("lname");
		String uname=request.getParameter("uname");
		String phoneno=request.getParameter("phoneno");
		String emailid=request.getParameter("emailid");
		String password=request.getParameter("password");
		
		emplist.add(new RegistrationModel(empid, fname, lname, uname, phoneno, emailid, password));
		
		DaoOperation.register(emplist);
		
		response.sendRedirect("Welcome.html");
	
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
