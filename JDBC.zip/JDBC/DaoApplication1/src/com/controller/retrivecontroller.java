package com.controller;

import java.io.IOException;
import java.io.*;
import java.util.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Dao.DaoOperation;
import com.model.RegistrationModel;

/**
 * Servlet implementation class retrivecontroller
 */
@WebServlet("/retrivecontroller")
public class retrivecontroller extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public retrivecontroller() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String empid=request.getParameter("empid");
		PrintWriter pw=response.getWriter();
		DaoOperation robj=new DaoOperation();
		List<RegistrationModel> lst=robj.retrive(empid);
		
		if(lst!=null){
			RegistrationModel r=lst.get(0);
			pw.print("<table border='3'><tr>");
			pw.print("<td>"+r.getEmpid()+"</td><td>"+r.getFname()+"</td><td>"+r.getLname()+"</td><td>"+r.getUname()+"</td><td>"+r.getPhoneno()+"</td><td>"+r.getEmailid());
			pw.print("</tr></table>");
		}
		else{
			pw.println("<h1>Record Not Found......</h1>");
		}
		
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
