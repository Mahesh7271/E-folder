package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Dao.DaoOperation;
import com.model.RegistrationModel;

/**
 * Servlet implementation class displaycontroller
 */
@WebServlet("/displaycontroller")
public class displaycontroller extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public displaycontroller() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter pw=response.getWriter();
		
		
		DaoOperation rdao=new DaoOperation();
		List<RegistrationModel> lst=rdao.display();
		pw.print("<table border='3'>");
		for(RegistrationModel r:lst){
			pw.print("<tr>");
			pw.print("<td>"+r.getEmpid()+"</td><td>"+r.getFname()+"</td><td>"+r.getLname()+"</td><td>"+r.getUname()+"</td><td>"+r.getPhoneno()+"</td><td>"+r.getEmailid());
			pw.print("</tr>");
		}
		pw.print("</table>");
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
