package com.model;

public class RegistrationModel {
	
	private String empid;
	private String fname;
	private String lname;
	private String uname;
	private String phoneno;
	private String emailid;
	private String password;
	public RegistrationModel(String empid, String fname, String lname, String uname, String phoneno, String emailid,
			String password) {
		super();
		this.empid = empid;
		this.fname = fname;
		this.lname = lname;
		this.uname = uname;
		this.phoneno = phoneno;
		this.emailid = emailid;
		this.password = password;
	}
	public String getEmpid() {
		return empid;
	}
	public void setEmpid(String empid) {
		this.empid = empid;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getPhoneno() {
		return phoneno;
	}
	public void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
	

}
