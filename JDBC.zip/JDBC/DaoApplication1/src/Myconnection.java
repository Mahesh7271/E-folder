

import java.sql.Connection;
import java.sql.DriverManager;


public class Myconnection {
	
	
		
		static Connection con;
		       public static Connection connect(){
		    	   
		    	   try {
					Class.forName("oracle:jdbc:OracleDriver");
					   String url="jdbc:oracle:thin:@localhost:1521:XE";
					   String username="system";
					   String password="system";
					   
					   con=DriverManager.getConnection(url,username,password);
					   System.out.println("connection to database");
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		    	   return con;  
		       }
		       
		      
	}
	







