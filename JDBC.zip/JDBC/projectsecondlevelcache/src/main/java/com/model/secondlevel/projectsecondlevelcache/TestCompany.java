package com.model.secondlevel.projectsecondlevelcache;

public class TestCompany 
{
	EntityManagerFactory emf=Persistence.createEntityManagerFactory("TP");
	EntityManager em=emf.
}
