package Mvc;

public class ProductA 
{
	private int ProdId;
	private String ProdName;
	private String ProdPrice;
	private String Prodtype;
	public ProductA(int prodId, String prodName, String prodPrice,  String prodtype) {
		ProdId = prodId;
		ProdName = prodName;
		ProdPrice = prodPrice;
		Prodtype = prodtype;
	}
	
	public int getProdId() {
		return ProdId;
	}
	public void setProdId(int prodId) {
		ProdId = prodId;
	}
	public String getProdName() {
		return ProdName;
	}
	public void setProdName(String prodName) {
		ProdName = prodName;
	}
	public String getProdPrice() {
		return ProdPrice;
	}
	public void setProdPrice(String prodPrice) {
		ProdPrice = prodPrice;
	}
	public String getProdtype() {
		return Prodtype;
	}
	public void setProdtype(String prodtype) {
		Prodtype = prodtype;
	}
	
	
}
