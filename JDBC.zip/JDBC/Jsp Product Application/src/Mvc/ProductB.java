package Mvc;

public class ProductB 
{
	private int ProdId;
	private String ProdName;
	private String ProdPrice;
	private String Prodqty;
	private String Prodtype;
	public ProductB(int prodId, String prodName, String prodPrice, String prodqty, String prodtype) {
		super();
		ProdId = prodId;
		ProdName = prodName;
		ProdPrice = prodPrice;
		Prodqty = prodqty;
		Prodtype = prodtype;
	}
	
	public int getProdId() {
		return ProdId;
	}
	public void setProdId(int prodId) {
		ProdId = prodId;
	}
	public String getProdName() {
		return ProdName;
	}
	public void setProdName(String prodName) {
		ProdName = prodName;
	}
	public String getProdPrice() {
		return ProdPrice;
	}
	public void setProdPrice(String prodPrice) {
		ProdPrice = prodPrice;
	}
	public String getProdqty() {
		return Prodqty;
	}
	public void setProdqty(String prodqty) {
		Prodqty = prodqty;
	}
	public String getProdtype() {
		return Prodtype;
	}
	public void setProdtype(String prodtype) {
		Prodtype = prodtype;
	}
	
	
}
