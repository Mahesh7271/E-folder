package com.model;

import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class ExamTest {
	public static void main(String[] args) {
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("exam");
		EntityManager manager =entityManagerFactory.createEntityManager();

		Author author1 = new  Author(11, "Pankaj", 12001);
		Author author2 = new  Author(12, "Nano", 1741);
		Author author3 = new  Author(13, "Sakshi", 5201);
		Author author4 = new  Author(14, "Ak", 10128);
		Author author5 = new  Author(15, "Mohit", 01201);
		
		/*manager.getTransaction().begin();
		
		manager.persist(author1);
		manager.persist(author2);
		manager.persist(author3);
		manager.persist(author4);
		manager.persist(author5);
		manager.getTransaction().commit();
		*/
		manager.getTransaction().begin();
		Query query = manager.createQuery("select UPPER(name) from Author ");
		
		List< String> list = query.getResultList();
		for (Iterator iterator = list.iterator(); iterator.hasNext();)
		{
			String s= (String) iterator.next();
			System.out.println(s);
		}
		
		
		manager.getTransaction().commit();
		
		
	}
}
