package AdminInfo;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

import AccountInfo.Account;
import AccountInfo.AccountInfo;
import Basicclass.Address;
import Basicclass.Custmer;
import Basicclass.Methodes;
import Dao.AccountDao;
import Dao.AdminDao;
public class AdminInfo 
{
	AccountInfo accountInfo = new AccountInfo();
	Scanner scanner = new Scanner(System.in);
	AdminDao dao = new  AdminDao();
	AccountDao dao2 = new AccountDao();
	Methodes methodes =new Methodes();
	public List<Admin> CreateAdmin() 
	{
		System.out.println("Enter Admin F-Name\tL-Name");
		Admin admin = new Admin(0,methodes.RandomNumber(),scanner.next(),scanner.next());

		System.out.println("Enter your state in this format 'mh','ga',etc ");
		String state = scanner.next();
		char[] arr = methodes.getstate(state);
		String str = String.valueOf(arr);
		System.out.println(str);

		System.out.println("Enter Custmer City\tPincode");
		String city = scanner.next();
		
		Address address = new Address(0,city,str, scanner.next());
		
		List<Admin> AdminList = new ArrayList<Admin>();
		AdminList.add(admin);
		dao.InsertValues(AdminList);
		dao.InsertAD_address(address);
		return  AdminList;
	}
	
	public Admin  GetAdmin(int A_NO)
	{
		Admin admin = null;
		admin = dao.RetriveAdmin(A_NO);
		return  admin;
	}
	public Address GetAd_address(int A_NO)
	{
		Address address = null;
		address = dao.RetriveAddress(A_NO);
		return address;
	}
	public void  DisplayAdmin(Admin admin) 
	{
		System.out.println("\nAdmin Number is     \tPassword\tFirst Name\tLast Name ");
		System.out.println("\t"+admin.getA_NO()+"\t\t"+admin.getA_Pass()+"\t\t"+admin.getA_FirstName()+"\t\t"+admin.getA_LastName());
	}
	public Boolean  SearchAdmin(int A_ID) 
	{
		Boolean b=false;
		LinkedList<Admin> list = DisplayAllAdminAccount();
		for (Admin admin : list) {
			if (admin.getA_NO()==A_ID)
			{
				return true;
			}
		}
		return b;
	}
	public void modifyPassword(int A_ID,int passs ) 
	{
		Admin admin= GetAdmin(A_ID);
		DisplayAdmin(admin);
		if (admin==null) 
			System.out.println("Account Is Present IN Bank");
		else
			System.out.println("Acconut Is Not Present in Bank");
		dao.UpdatePassword(admin, passs);
	}
	public LinkedList<Admin> DisplayAllAdminAccount() {
		LinkedList<Admin> list = new LinkedList<Admin>();
		list = dao.RetriveAllAdmin();
		
		return list;
	}
	public void  DisplayAllBankAccount() {
		LinkedList<Account> list = new LinkedList<Account> ();
		list = dao2.RetriveAllAccount();

		for(int i=0;i<list.size();i++){
		    accountInfo.DisplayAccount(list.get(i));
		} 	
	}
	public void DeleteAccount()
	{
		System.out.println("Enter Account ID for delete Account");
		int A_ID = scanner.nextInt();
		accountInfo.DeleteAccount(A_ID);
	}
	public void withFullimformation()
	{
		System.out.println("Enter Account ID for Display Account");
		int A_ID = scanner.nextInt();
		
		Account  account = accountInfo.GetAccount(A_ID);
	    Custmer  custmer = accountInfo.GetCustmer(A_ID);
	    Address  address = accountInfo.GetAddress(A_ID);
	    System.out.println("---------------------------------------------------------------------------------");
	    accountInfo.DisplayCustmer(custmer);
	    accountInfo.DisplayAccount(account);
	    accountInfo.DisplayAddress(address);
	}
	public boolean  checkAdmin(Admin admin,int A_ID,int pass)
	{
		boolean b = false;
		
		if(admin.getA_NO()== A_ID && admin.getA_Pass()== pass)
			b= true;
		return  b;
	}
	public LinkedList<AdminAddress>  displayAdminwithAddress()
	{
		LinkedList<AdminAddress>  adminAddresses =new LinkedList();
		LinkedList<Admin> list = new LinkedList<Admin>();
		LinkedList<Address> listad = new LinkedList<Address>();
		
		list = (LinkedList<Admin>) dao.RetriveAllAdmin();
		listad= (LinkedList<Address>) dao.RetriveAdminAddress();
		
		for (Admin address : list) 
		{
			AdminAddress ad = new AdminAddress(address.getA_NO(), address.getA_Pass(),address.getA_FirstName(),address.getA_LastName(), null, null, null);
			adminAddresses.add(ad);
		}
		int i=0;
		for (Address address : listad) 
		{
			AdminAddress adminAddress = adminAddresses.get(i);
			adminAddress.setCity(address.getCity());
			adminAddress.setPincode(address.getPincode());
			adminAddress.setState(address.getState());
			i++;
		}
		return adminAddresses;
	}
}
