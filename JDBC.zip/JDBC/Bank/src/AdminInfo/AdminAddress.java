package AdminInfo;

public class AdminAddress {
	private int A_NO;
	private	int A_Pass;
	private String A_FirstName;
	private	String A_LastName;
	private String city ;
	private String state ;
	private String pincode ;
	public AdminAddress(int a_NO, int a_Pass, String a_FirstName, String a_LastName, String city, String state,
			String pincode) {
		super();
		A_NO = a_NO;
		A_Pass = a_Pass;
		A_FirstName = a_FirstName;
		A_LastName = a_LastName;
		this.city = city;
		this.state = state;
		this.pincode = pincode;
	}
	public int getA_NO() {
		return A_NO;
	}
	public void setA_NO(int a_NO) {
		A_NO = a_NO;
	}
	public int getA_Pass() {
		return A_Pass;
	}
	public void setA_Pass(int a_Pass) {
		A_Pass = a_Pass;
	}
	public String getA_FirstName() {
		return A_FirstName;
	}
	public void setA_FirstName(String a_FirstName) {
		A_FirstName = a_FirstName;
	}
	public String getA_LastName() {
		return A_LastName;
	}
	public void setA_LastName(String a_LastName) {
		A_LastName = a_LastName;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	
}
