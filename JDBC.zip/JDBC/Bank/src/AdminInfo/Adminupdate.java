package AdminInfo;

import java.util.Scanner;

import Dao.AdminDao;

public class Adminupdate 
{
	Scanner scanner = new Scanner(System.in);
	AdminDao dao = new  AdminDao();
	public void AdminUpdate(Admin admin) 
	{
	System.out.println("WELCOME TO LINKCODE BANK | ADMIN UPDATE SCREEN |");
	System.out.println("1 - Chnage Admin First Name "
				   + "\n2 - Chnage Admin Last  Name"
				   + "\n3 - Chnage Admin Password"
				   + "\n -...");
	System.out.println("Enter your choice......");
	int choice = scanner.nextInt();
		switch (choice) 
		{
		case 1:
				F_Name(admin);
				break;
		case 2:
				L_Name(admin);
				break;
		case 3:
				password(admin);
				break;
	
		default:
			break;
		}
	}
	
	public void F_Name(Admin admin) 
	{
		System.out.println("Enter new first name");
		String string = scanner.next();
		dao.UpdateF_Name(admin, string);
	}
	public void L_Name(Admin admin) 
	{
		System.out.println("Enter new last name ");
		String string = scanner.next();
		dao.UpdateL_Name(admin, string);
		
	}
	public void password(Admin admin) 
	{
		System.out.println("Enter new password ");
		dao.UpdatePassword(admin, scanner.nextInt());
	}
	
}
