package Basicclass;

public class Custmer 
{
	private   int   C_id  ;
	private String F_Name ;
	private String L_Name ;
	private String Mobile_No;
	public Custmer(int c_id, String f_Name, String l_Name, String mobile_No) {
		C_id = c_id;
		F_Name = f_Name;
		L_Name = l_Name;
		Mobile_No = mobile_No;
	}
	public int getC_id() {
		return C_id;
	}
	public void setC_id(int c_id) {
		C_id = c_id;
	}
	public String getF_Name() {
		return F_Name;
	}
	public void setF_Name(String f_Name) {
		F_Name = f_Name;
	}
	public String getL_Name() {
		return L_Name;
	}
	public void setL_Name(String l_Name) {
		L_Name = l_Name;
	}
	public String getMobile_No() {
		return Mobile_No;
	}
	public void setMobile_No(String mobile_No) {
		Mobile_No = mobile_No;
	}
	
}
