package Bank;

import java.util.List;
import java.util   .Scanner;
import AccountInfo .Account;
import AdminInfo   .Admin;
import AdminInfo   .AdminInfo;
import AdminInfo   .Adminupdate;
import Basicclass  .Address;
import Basicclass  .Custmer;
 
public class AdminInterface 
{
	Scanner scanner= new Scanner(System.in);
	Adminupdate adminupdate = new Adminupdate();
	AdminInfo adminInfo = new AdminInfo();
	List<Admin> adminlist = null;
	public void checkId() 
	{
		System.out.println("\tEnter your Admin Id ");
		int A_ID = scanner.nextInt();                  
		System.out.println("\tPassword ....");      
		int pass = scanner.nextInt();                  
		 Admin admin = adminInfo.GetAdmin(A_ID);
		 Address address = adminInfo.GetAd_address(A_ID);
		boolean b = adminInfo.checkAdmin(admin, A_ID, pass); 
		if (b) 
		{
			AdminInterface(admin, address);
		}
		else
		{
			System.out.println("Account Do'not present re-enter your id or password");
			checkId();
		}
	}
	public void AdminInterface(Admin admin,Address address)
	{
		do 
		{
		System.out.println(" WELCOME TO LINKCODE BANK | ADMIN SCREEN |");
		System.out.println("=================================================================================\t");
		System.out.println("Account No\tCustmer Name\tCustmer Last Name");
		System.out.println("---------------------------------------------------------------------------------\t");
		System.out.println(""+admin.getA_NO()+"\t\t"+admin.getA_FirstName()+"\t\t"+admin.getA_LastName());
		System.out.println("---------------------------------------------------------------------------------\t");
		System.out.println("\t 1 - Create  Admin Account   "
					   + "\n\t 2 - Search  Admin Account   "
					   + "\n\t 3 - Display Admin Account   "
					   + "\n\t 4 - Update  Admin Password  "
					   + "\n\t 5 - Display All Adminss     "
					   + "\n\t 6 - Display All Accounts    "
					   + "\n\t 7 - Delete  Any Account     "
					   + "\n\t 8 - Display Account full Imformation ");
		System.out.println("Enter your choice......     ");
		int choice = scanner.nextInt();
		switch (choice) {
		case 1:
			adminlist=adminInfo.CreateAdmin();
			break;
		case 2:
			System.out.println("Enter Admin Id for search");
			int A_ID = scanner.nextInt();
			adminInfo.SearchAdmin(A_ID);
			break;
		case 3:
			if (adminlist==null)
			{
				System.out.println("Enter Admin Id for search");
				adminInfo.SearchAdmin(scanner.nextInt());
				break;
			}
			else
			{
				adminInfo.DisplayAdmin(admin);
			}
		break;
		case 4:
			System.out.println(" 1 - Change  Admin Password ");
			System.out.println(" 2 - Change Any Admin Account Update ");
			int ch = scanner.nextInt();
			if(ch==1)
			{
				if (adminlist!=null) 
				{
				
					System.out.println("Enter Your New Password for "+admin.getA_NO()+" This Admin Id");
					adminInfo.modifyPassword(scanner.nextInt(),admin.getA_NO());
				}			
				else 
				{
					System.out.println("Enter your Account Number.. ");
					int  A_ID1=scanner.nextInt();
					System.out.println("Enter your Account Password..");
					int  A_Pass=scanner.nextInt();
					adminInfo.modifyPassword(A_Pass,A_ID1);
				}
			}
			else
				System.out.println("Enter Admin Id for search");
				Admin admin1 =adminInfo.GetAdmin(scanner.nextInt());
				adminupdate.AdminUpdate(admin1);
				break;
		case 5:
			adminInfo.DisplayAllAdminAccount();
			break;
		case 6:
			adminInfo.DisplayAllBankAccount();
			break;
		case 7:
			adminInfo.DeleteAccount();
			break;
		case 8:
			adminInfo.withFullimformation();
			break;
	
		default:
			break;
		}
		System.out.println("\n\t\tThanks For Visiting.........");
		System.out.println("---------------------------------------------------------------------------");
		System.out.println("Do you want to continue press 1 | ADMIN SCREEN |");
		
		} while (scanner.nextInt()==1);
	}
}
