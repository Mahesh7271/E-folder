package Bank;

import java.util.Scanner;

import AccountInfo.Account;
import AccountInfo.AccountInfo;
import Basicclass.Address;
import Basicclass.Custmer;
import regular.Regularinfo;

public class RegularInterface 
{	
	AccountInfo accountInfo = new AccountInfo();
	Scanner scanner = new Scanner(System.in);
	Regularinfo regularinfo = new Regularinfo();

	public void BalanceWord(float Amount) {
		int str  = (int) Amount;
		String string =Integer.toString(str);
		if (string.length() == 0)   
		{  
			System.out.println("The string is empty.");  
			return;  
		}  
		if (string.length()<10)
		{
			int num=Integer.parseInt(string);
			System.out.println("  Your Balance is :- "+convert(num));
		}
		else
			System.out.println("\n The given number has more than 10 digits.");  
		
	}
	public void checkId() 
	{
		System.out.println("\tEnter your Account Id ");
		int A_ID = scanner.nextInt();                  
		System.out.println("\tPassword....");          
		int pass = scanner.nextInt();                  
		Account account = regularinfo.GetAccount(A_ID);
		Address address = regularinfo.GetAddress(A_ID);
		Custmer custmer = regularinfo.GetCustmer(A_ID);
		boolean b = regularinfo.checkAccount(account, A_ID, pass);
		if (b) 
		{
			System.out.println("==============================================================================");
			Regularinterface(account, address, custmer);
		
		}
		else
		{
			System.out.println("Account Do'not present re-enter your id or password");
			checkId();
		}
			
	}
	public void Regularinterface(Account account2 ,Address address,Custmer custmer)
	{
		do 
		{
			System.out.println("WELCOME TO LINKCODE BANK | Regular SCREEN |");
			System.out.println("---------------------------------------------------------------------------------\t");
			System.out.println("Account No\tCustmer Name\tCustmer Last Name");
			System.out.println("---------------------------------------------------------------------------------\t");
			System.out.println(+account2.getA_no()+"\t\t"+custmer.getF_Name()+"\t\t"+custmer.getL_Name());
			System.out.println("\t1 -  Balance Enquiry     "
						   + "\n\t2 -  Change  password     "
						   + "\n\t3 -  Withdrow Amount     "
						   + "\n\t4 -  Deposit  Amount     "
						   + "\n\t5 -  Display Address     "
						   + "\n\t6 -       "
						   + "\n\t7 -       "
						   + "\n\t8 -       ");
			System.out.println("Enter your choice......     ");
			int choice = scanner.nextInt();
			switch (choice) {
			case 1:	
				System.out.println("=================================================================================");
				System.out.println("\tAccount Holder Name\tId\tBalance");
				System.out.println("\t"+custmer.getF_Name()+" "+custmer.getL_Name()+"\t\t"+account2.getA_no()+"\t"+account2.getA_Balance());
				System.out.println("---------------------------------------------------------------------------------");
				System.out.println("\t\t Account Balance is Word is Following");
				System.out.println("---------------------------------------------------------------------------------");
				BalanceWord(account2.getA_Balance());
				System.out.println("---------------------------------------------------------------------------------");
				break;
			case 2:
				System.out.println("Enter Your New Password for "+account2.getA_no()+"  This Account Id");
				accountInfo.modifyPassword(scanner.nextInt(), account2.getA_no());
				break;
			case 3:
				System.out.println("Enter your Amount to the withdrow ");
				float Amount = scanner.nextFloat();
				float amountwith = account2.getA_Balance()-Amount;
				accountInfo.withdrowAmount(account2, amountwith);
				break;
			case 4:
				System.out.println("Enter your Amount to the deposit ");
				float Amount1 = scanner.nextFloat();
				float amountwith1 = account2.getA_Balance()+Amount1;
				accountInfo.DepositAmount(account2, amountwith1);
				break;
			case 5:
				System.out.println("\tAcccout Holder Name\tCity\tState\t\tPincode|zipcode|");
				System.out.println("\t"+custmer.getF_Name()+" "+custmer.getL_Name()+"\t\t"+address.getCity()+"\t"+address.getState()+"\t"+address.getPincode());
				break;
			case 6:
				break;
			default:
				break;
			}
			
			
			
			System.out.println("\n\tThanks For Visiting.........");
			System.out.println("---------------------------------------------------------------------------");
			System.out.println("Do you want to continue press 1 | Regular SCREEN |");
			
		} while (scanner.nextInt()==1);
	}
	static  String convert(int num)
	{
		String str="";
		if (num<100) 
			str = fun(num);
		else if (num>=100  && num<1000)//hun
			str=fun(num/100)+" Hundread " + convert(num%100);
		else if (num>=1000  && num<100000)//t
			str=fun(num/1000)+" Thousand " + convert(num%1000);
		else if (num>=100000  && num<10000000)//l
			str=fun(num/100000)+" Lakh " + convert(num%100000);
		else if (num>=10000000  && num<1000000000)//c
			str=fun(num/10000000)+" Crore " + convert(num%10000000);
		return str;
	}
	static String fun(int num)
	{
	String str ="";
	String[] units = {" Zero ", " One " , " Two ", " Three ", " Four ", " Five ", 
			          " Six ", " Seven ", " Eight ", " Nine "," Ten ", " Eleven ",
			          " Twelve ", " Thirteen ", " Fourteen ", " Fifteen ", " Sixteen ",
			          " Seventeen ", " Eighteen ", " Nineteen "};
	String[] tens  = {" ",  " ", " Twenty ", " Thirty ", " Forty ", " Fifty ", " Sixty ", " Seventy ", " Eighty ", " Ninety "};
	
	if (num<20)
	{
		str=units[num];
		return str;
		}
	else if(num>=20 && num<100)
	{
		str=tens[num/10] + units[num%10];
	}
	return str;
	}


}
