package Bank;
import java.util.List;
import java.util.Scanner;

import AccountInfo.Account;
import AccountInfo.AccountInfo;;

public class UserInterface 
{
	public void UserInterface()
	{
		List<Account> listAccount = null;
		AccountInfo  accountInfo= new AccountInfo();
		Scanner scanner = new Scanner(System.in);
		do 
		{

			System.out.println("WELCOME TO LINKCODE BANK | USER SCREEN |");
			System.out.println("1 - Create  Account "
						   + "\n2 - Search  Account "
						   + "\n3 - Display Account "
						   + "\n4 - Update Password "
						   + "\n5 - ");
		System.out.println("Enter your choice......");
		int choice = scanner.nextInt();
		switch (choice) {
		case 1:
//			listAccount=accountInfo.CreateAccount();
			break;
		case 2:
			System.out.println("Enter your Account Number..");
			int  A_ID=scanner.nextInt();
			Account account =accountInfo.GetAccount(A_ID);
			accountInfo.DisplayAccount(account);
			break;
		case 3:
			if (listAccount==null)
			{
				System.out.println("Create A Current Account Firstly ");
				break;
			}
			else
			{
				System.out.println("Enter your Account Number..");
				int  A_ID1=scanner.nextInt();
				accountInfo.withFullimformation(A_ID1);
	
			}
			break;
		case 4:
			System.out.println(" 1 - Change Current Account Password Change");
			System.out.println(" 2 - Change Any Account Password Change");
			int ch = scanner.nextInt();
			if(ch==1)
			{
				if (listAccount==null) 
				{
					System.out.println("Create A Current Account Firstly ");
					break;
				}
				else
				{
					Account acc1  =  listAccount.get(0);
					System.out.println("Enter Your New Password for "+acc1.getA_no()+"  This Account Id");
					accountInfo.modifyPassword(scanner.nextInt(), acc1.getA_no());
				}
			}
			else 
			{
				System.out.println("Enter your Account Number.. ");
				int  A_ID1=scanner.nextInt();
				System.out.println("Enter your Account Password..");
				int  A_Pass=scanner.nextInt();
				accountInfo.modifyPassword(A_Pass, A_ID1);
			}
				break;
		}
		System.out.println("Thanks For Visiting.........");
		System.out.println("---------------------------------------------------------------------------");
 		System.out.println("Do you want to continue press 1 | USER SCREEN |");
		} while (scanner.nextInt()==1);	}
}
