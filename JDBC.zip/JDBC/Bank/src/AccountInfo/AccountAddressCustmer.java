package AccountInfo;

public class AccountAddressCustmer {
	private int A_no;
	private int A_Pass;
	private String A_Type;
	private float A_Balance;

	private String city ;
	private String state ;
	private String pincode ;


	private String F_Name ;
	private String L_Name ;
	private String Mobile_No;
	public int getA_no() {
		return A_no;
	}
	public void setA_no(int a_no) {
		A_no = a_no;
	}
	public int getA_Pass() {
		return A_Pass;
	}
	public void setA_Pass(int a_Pass) {
		A_Pass = a_Pass;
	}
	public String getA_Type() {
		return A_Type;
	}
	public void setA_Type(String a_Type) {
		A_Type = a_Type;
	}
	public float getA_Balance() {
		return A_Balance;
	}
	public void setA_Balance(float a_Balance) {
		A_Balance = a_Balance;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	public String getF_Name() {
		return F_Name;
	}
	public void setF_Name(String f_Name) {
		F_Name = f_Name;
	}
	public String getL_Name() {
		return L_Name;
	}
	public void setL_Name(String l_Name) {
		L_Name = l_Name;
	}
	public String getMobile_No() {
		return Mobile_No;
	}
	public void setMobile_No(String mobile_No) {
		Mobile_No = mobile_No;
	}
	public AccountAddressCustmer(int a_no, int a_Pass, String a_Type, float a_Balance, String city, String state,
			String pincode, String f_Name, String l_Name, String mobile_No) {
		super();
		A_no = a_no;
		A_Pass = a_Pass;
		A_Type = a_Type;
		A_Balance = a_Balance;
		this.city = city;
		this.state = state;
		this.pincode = pincode;
		F_Name = f_Name;
		L_Name = l_Name;
		Mobile_No = mobile_No;
	}
}
