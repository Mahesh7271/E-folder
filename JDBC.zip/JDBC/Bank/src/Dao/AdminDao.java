package Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import AccountInfo.Account;
import AdminInfo.Admin;
import Basicclass.Address;

public class AdminDao
{
	Connection connection = Myconnection.GetDataBaseConnetivity();
	public void InsertValues(List<Admin> AdminList) 
	{
		int i=0;
		Admin admin = AdminList.get(0);
		try 
		{
			PreparedStatement preparedStatement = connection.prepareStatement("insert into LinkcodeAdmin values(Admin_no.nextval,?,?,?) ");
			preparedStatement.setInt(1, admin.getA_Pass());
			preparedStatement.setString(2, admin.getA_FirstName());
			preparedStatement.setString(3, admin.getA_LastName());
		 i = preparedStatement.executeUpdate();
		/**
		if (i>0) 
			System.out.println("1 row(s) inserted.\n");
		else
		System.out.println("table or view does not exist");*/
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
	}
	public int InsertValues(Admin admin) 
	{
		int i =0;
		try 
		{
			PreparedStatement preparedStatement = connection.prepareStatement("insert into LinkcodeAdmin values(Admin_no.nextval,?,?,?) ");
			preparedStatement.setInt(1, admin.getA_Pass());
			preparedStatement.setString(2, admin.getA_FirstName());
			preparedStatement.setString(3, admin.getA_LastName());
		i= preparedStatement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;
	}
	public int InsertAD_address(Address address)
	{
		int i =0;
		try 
		{
			PreparedStatement preparedStatement = connection.prepareStatement("insert into LinkcodeAd_address values(AdminAd_no.nextval,?,?,?)");
			preparedStatement.setString(1,address.getCity());
			preparedStatement.setString(2,address.getState());
			preparedStatement.setString(3,address.getPincode());
			 i = preparedStatement.executeUpdate();
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		return i;
	}
	public Admin RetriveAdmin(int A_ID)
	{
		Admin admin= null;
	try {
			PreparedStatement preparedStatement = connection.prepareStatement("select * from Linkcodeadmin where A_NO = ?");
			preparedStatement.setInt(1,A_ID);
			ResultSet resultSet = preparedStatement.executeQuery();
			boolean i=resultSet.next();
			 admin = new Admin(resultSet.getInt(1),resultSet.getInt(2),resultSet.getString(3),resultSet.getString(4));
			/**if (i) 
				System.out.println("1 rows returned in 0.08 seconds..Admin.\n");
			else
			System.out.println("table or view does not exist");*/
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		} 
	return admin;
	}
	public Address RetriveAddress(int A_ID)
	{
		Address address =null;
	try {
			PreparedStatement preparedStatement = connection.prepareStatement("select * from linkcodead_address where A_id = ?");
			preparedStatement.setInt(1,A_ID-1000);
			ResultSet resultSet = preparedStatement.executeQuery();
			boolean i=resultSet.next();
			address =address = new Address(resultSet.getInt(1),resultSet.getString(2) ,resultSet.getString(3) ,resultSet.getString(4) ); 
			/**if (i) 
				System.out.println("1 rows returned in 0.08 seconds..address.\n");
			else
			System.out.println("table or view does not exist");*/
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		} 
	return address;
	}

	public Boolean DeleteAdminAddress(int A_ID)
	{
		Boolean b=false;
		try {
			PreparedStatement preparedStatement = connection.prepareStatement("DELETE FROM linkcodead_address WHERE A_ID =?");
			preparedStatement.setInt(1,A_ID-1000);
			ResultSet resultSet = preparedStatement.executeQuery();
			boolean i=resultSet.next();
			/**if (i) 
				System.out.println("1 rows returned in 0.08 seconds..address.\n");
			else
			System.out.println("table or view does not exist");*/
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		} 
	return b;
	}
	public Boolean DeleteAdmin(int A_ID)
	{
		Boolean b=false;
		try 
		{
			PreparedStatement preparedStatement = connection.prepareStatement("DELETE FROM linkcodeadmin WHERE A_NO =?");
			preparedStatement.setInt(1,A_ID);
			ResultSet resultSet = preparedStatement.executeQuery();
			boolean i=resultSet.next();
			/**if (i) 
				System.out.println("1 rows returned in 0.08 seconds..address.\n");
			else
			System.out.println("table or view does not exist");*/
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		} 
	return b;
	}
	public LinkedList<Admin> RetriveAllAdmin()
	{
		LinkedList<Admin> listadmin = new LinkedList<Admin>();
		Admin admin= null;
	try {
			PreparedStatement preparedStatement = connection.prepareStatement("select *  from linkcodeadmin order by A_no");
			ResultSet resultSet = preparedStatement.executeQuery();
			boolean i=resultSet.next();
			while (resultSet.next())
			{
				admin = new Admin(resultSet.getInt(1),resultSet.getInt(2),resultSet.getString(3),resultSet.getString(4));
				listadmin.add(admin);
			}/**
			if (i) 
				System.out.println("1 rows returned in 0.08 seconds...\n");
			else
			System.out.println("table or view does not exist");*/
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		} 
	return listadmin;
	}
	public LinkedList<Address> RetriveAdminAddress()
	{
		LinkedList<Address> listadmin = new LinkedList<Address>();
		Address admin= null;
	try {
			PreparedStatement preparedStatement = connection.prepareStatement("select *  from linkcodead_address order by A_ID  ");
			ResultSet resultSet = preparedStatement.executeQuery();
			boolean i=resultSet.next();
			while (resultSet.next())
			{
				admin = new Address(resultSet.getInt(1),resultSet.getString(2),resultSet.getString(3),resultSet.getString(4));
				listadmin.add(admin);
			}/**
			if (i) 
				System.out.println("1 rows returned in 0.08 seconds...\n");
			else
			System.out.println("table or view does not exist");*/
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		} 
	return listadmin;
	}
	public void UpdatePassword(Admin admin,int newPass)
	{
		int i3=0;
		try 
		{															
			PreparedStatement PState1 = connection.prepareStatement("update Linkcodeadmin set A_Pass=? where A_NO =?");
			PState1.setInt(1,newPass);
			PState1.setInt(2,admin.getA_NO());
			i3 = PState1.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		/**if (i3>0) 
			System.out.println("1 row(s) updated ....\n");
		 else
			System.out.println("table or view does not exist");*/
	}
	
	public void UpdateF_Name(Admin admin,String string)
	{
		int i3=0;
		try 
		{															
			PreparedStatement PState1 = connection.prepareStatement("update Linkcodeadmin set A_FNAME=? where A_NO =?");
			PState1.setString(1, string);
			PState1.setInt(2,admin.getA_NO());
			i3 = PState1.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		/*** 
		if (i3>0) 
			System.out.println("1 row(s) updated ....\n");
		 else
			System.out.println("table or view does not exist");*/
	}
	public void UpdateL_Name(Admin admin,String string)
	{
		int i3=0;
		try 
		{															
			PreparedStatement PState1 = connection.prepareStatement("update Linkcodeadmin set A_LNAME=? where A_NO =?");
			PState1.setString(1, string);
			PState1.setInt(2,admin.getA_NO());
			i3 = PState1.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		/**if (i3>0) 
			System.out.println("1 row(s) updated ....\n");
		 else
			System.out.println("table or view does not exist");
		 */
		}
		
}
