package regular;

import AccountInfo.Account;

import AccountInfo.AccountInfo;
import Basicclass.Address;
import Basicclass.Custmer;
import Dao.AccountDao;
public class Regularinfo
{
	AccountDao dao  = new AccountDao();
	AccountInfo accountInfo = new AccountInfo();
	public Account GetAccount(int A_ID) 
	{
		Account account = null;	
		account = dao.RetriveAccount(A_ID);
		return  account;
	}
	public Address  GetAddress(int A_ID) 
	{
		Address address = dao.RetriveAddress(A_ID);	
		return  address;
	}
	public Custmer GetCustmer(int A_ID) 
	{
		Custmer custmer = dao.RetriveCustmer(A_ID);
		return  custmer;
	}
	
	public boolean  checkAccount(Account account ,int A_ID,int pass)
	{
		boolean b = false;
		
		if(account.getA_no()== A_ID && account.getA_Pass()== pass)
			b= true;
		
		
		return  b;
	}
}
