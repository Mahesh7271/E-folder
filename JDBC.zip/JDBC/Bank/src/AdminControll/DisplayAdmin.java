package AdminControll;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import AdminInfo.Admin;
import Dao.AdminDao;

/**
 * Servlet implementation class DisplayAdmin
 */
@WebServlet("/DisplayAdmin")
public class DisplayAdmin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DisplayAdmin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int id =Integer.parseInt(request.getParameter("id"));

		PrintWriter out  = response.getWriter();
		Dao.AdminDao dao = new AdminDao();
		Admin admin =dao.RetriveAdmin(id);
		if (admin.getA_NO()==id) {
			
			out.print("<Table border =2px solid green  height=12 padding:15px>");
			out.print("<tr><td>\t\t Admin Account Id 	 </td>");
			out.print("<td>\t\t Admin Admin Paasword </td>");
			out.print("<td>\t\t Admin First Name </td>");
			out.print("<td>\t\t Admin Last Name </td></tr>");

			out.print("<tr><td>\t\t "+admin.getA_NO()+"</td>");
			out.print("<td>\t\t "+admin.getA_Pass()+"</td>");
			out.print("<td>\t\t "+admin.getA_FirstName()+"</td>");
			out.print("<td>\t\t "+admin.getA_LastName()+"</td></tr>");

			out.print("<Table>");
		
		}
		else 

			out.print("<h3>\t\t Admin Id is Not Present In Bank  :  "+admin.getA_NO()+" </h3>");
		}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
