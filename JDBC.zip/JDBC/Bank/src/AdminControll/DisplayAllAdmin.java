package AdminControll;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import AdminInfo.Admin;
import AdminInfo.AdminAddress;
import AdminInfo.AdminInfo;
import Basicclass.Address;
import Dao.AdminDao;

/**
 * Servlet implementation class DisplayAllAdmin
 */
@WebServlet("/DisplayAllAdmin")
public class DisplayAllAdmin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DisplayAllAdmin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out =  response.getWriter();

		AdminInfo ad = new AdminInfo();
		LinkedList< AdminAddress> laa= new LinkedList<AdminAddress>();
		laa = ad.displayAdminwithAddress();
		int j=1;
		out.print("<Table border =2px solid green  height=12 padding:15px>");
		out.print("<tr><td>\t\t Sr.No </td>");
		out.print("<td>\t\t Admin Account Id 	 </td>");
		out.print("<td>\t\t Admin Admin Paasword </td>");
		out.print("<td>\t\t Admin First Name </td>");
		out.print("<td>\t\t Admin Last Name </td>");
		out.print("<td>\t\t City</td>");
		out.print("<td>\t\t Pincode</td>");
		out.print("<td>\t\t State</td></tr>");
		for (AdminAddress admin : laa) {
		
			out.print("<tr><td>\t\t "+(j)+"</td>");
			out.print("<td>\t\t "+admin.getA_NO()+"</td>");
			out.print("<td>\t\t "+admin.getA_Pass()+"</td>");
			out.print("<td>\t\t "+admin.getA_FirstName()+"</td>");
			out.print("<td>\t\t "+admin.getA_LastName()+"</td>");
			out.print("<td>\t\t "+admin.getCity()+"</td>");
			out.print("<td>\t\t "+admin.getPincode()+"</td>");
			out.print("<td>\t\t "+admin.getState()+"</td></tr>");
			j++;
		}	
		out.print("<Table>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
