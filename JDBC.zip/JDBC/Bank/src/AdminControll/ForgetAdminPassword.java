package AdminControll;

import java.awt.List;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import AdminInfo.Admin;
import Dao.AdminDao;

/**
 * Servlet implementation class ForgetAdminPassword
 */
@WebServlet("/ForgetAdminPassword")
public class ForgetAdminPassword extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ForgetAdminPassword() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	PrintWriter out = response.getWriter();
	
	int id =Integer.parseInt(request.getParameter("id"));	
	String fname= request.getParameter("fname");
	String password1=request.getParameter("password1");
	String password2=request.getParameter("password2");
	
	int pass1= Integer.parseInt(password1);
	int pass2= Integer.parseInt(password2);
	
	Dao.AdminDao dao = new AdminDao();
	Admin admin =dao.RetriveAdmin(id);
	java.util.List<Admin> list =dao.RetriveAllAdmin();
	boolean b=false;
	
	if (pass1==pass2) 
	{
		for (Admin admin2 : list) 
		{
			if (admin2.getA_NO()==id)
			{
			b=true;	
			}
		}	
	}
	else
	{
		out.print(" <h3> Please Enter same password  </h3>");
	}
	if (b)
	{
		dao.UpdatePassword(admin, pass2);
		out.print("<h1> Password has been Change</h1>");
		response.sendRedirect("welcomeAdmin.html");
	}
	else{
		out.print(" <h3> Your Reqest is  not Granted</h3>");

	}
			
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
