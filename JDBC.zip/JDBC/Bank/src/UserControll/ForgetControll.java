package UserControll;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import AccountInfo.Account;
import Basicclass.Custmer;
import Dao.AccountDao;

/**
 * Servlet implementation class ForgetControll
 */
@WebServlet("/ForgetControll")
public class ForgetControll extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ForgetControll() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		PrintWriter out =response.getWriter();
		int i =0;
		Dao.AccountDao  dao =new AccountDao();
		int id =Integer.parseInt(request.getParameter("id"));
		String mobile =request.getParameter("mobile"); 
		int  password1 = Integer.parseInt(request.getParameter("password1"));
		int  password2 = Integer.parseInt(request.getParameter("password2"));
	
		Account account =dao.RetriveAccount(id);
		Custmer custmer=dao.RetriveCustmer(id);
		if (password1==password2) 
		{
			if (custmer.getMobile_No().endsWith(mobile))
			{
				 i=dao.UpdatePassword(account,password1 );
				 if (i>0)
				 {
					 response.sendRedirect("Forgetsucessfully.html");
								
				}
			}
			else 
			{
				out.print("<h3>Please Enter Your Valided Mobile Number in Forgetpage<h3>");
			
			}
				
		}
		else 
		{
			out.print("<h3>Please Enter Same Password in Forgetpage<h3>");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
