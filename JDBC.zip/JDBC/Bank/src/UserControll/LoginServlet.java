package UserControll;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import AccountInfo.Account;
import Basicclass.Address;
import Basicclass.Custmer;
import Dao.AccountDao;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	AccountDao dao = new AccountDao();
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String id1 =request.getParameter("id");
		int id=Integer.parseInt(id1);
		int pass=Integer.parseInt(request.getParameter("pass"));
		Account  account = dao.RetriveAccount(id);
		Address  address = dao.RetriveAddress(id);
		Custmer  custmer = dao.RetriveCustmer(id);
		
		if(account.getA_no()==id && account.getA_Pass()==pass)
		{
			 response.sendRedirect("Forgetsucessfully.html");
		}
		else
			response.sendRedirect("LoginSubPage.html");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
