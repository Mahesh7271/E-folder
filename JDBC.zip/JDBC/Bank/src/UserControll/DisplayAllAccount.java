package UserControll;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.LinkedList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import AccountInfo.Account;
import AccountInfo.AccountAddressCustmer;
import AccountInfo.AccountInfo;
import AdminInfo.AdminAddress;
import AdminInfo.AdminInfo;

/**
 * Servlet implementation class DisplayAllAccount
 */
@WebServlet("/DisplayAllAccount")
public class DisplayAllAccount extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DisplayAllAccount() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		PrintWriter out =  response.getWriter();
		AccountInfo ad = new AccountInfo();
		LinkedList< AccountAddressCustmer> laa= new LinkedList<AccountAddressCustmer>();
		laa = ad.withAccAddCust();
		int j=1;
		out.print("<Table border =2px solid green  height=12 padding:15px>");
		out.print("<tr><td>\t\t Sr.No </td>");
		out.print("<td>\t\t  Account Id 	 </td>");
		out.print("<td>\t\t  Account Paasword </td>");
		out.print("<td>\t\t  Account Type	 </td>");
		out.print("<td>\t\t  Account Balance </td>");
		out.print("<td>\t\t  First Name </td>");
		out.print("<td>\t\t  Last Name </td>");
		out.print("<td>\t\t  Contact NO </td>");
		out.print("<td>\t\t  City</td>");
		out.print("<td>\t\t  Pincode</td>");
		out.print("<td>\t\t  State</td></tr>");
		for (AccountAddressCustmer ACC : laa) {
		
			out.print("<tr><td>\t\t "+(j)+"</td>");
			out.print("<td>\t\t "+ACC.getA_no()+"</td>");
			out.print("<td>\t\t "+ACC.getA_Pass()+"</td>");
			out.print("<td>\t\t "+ACC.getA_Type()+"</td>");
			out.print("<td>\t\t "+ACC.getA_Balance()+"</td>");
			                      
			out.print("<td>\t\t "+ACC.getF_Name()+"</td>");       
			out.print("<td>\t\t "+ACC.getL_Name()+"</td>");  
			out.print("<td>\t\t "+ACC.getMobile_No()+"</td>");   
						          
			out.print("<td>\t\t "+ACC.getCity()+"</td>");
			out.print("<td>\t\t "+ACC.getPincode()+"</td>");
			out.print("<td>\t\t "+ACC.getState()+"</td></tr>");
			j++;
		}	
		out.print("<Table>");
}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
