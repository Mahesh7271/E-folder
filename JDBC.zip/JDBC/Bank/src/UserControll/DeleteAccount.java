package UserControll;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import AccountInfo.AccountInfo;
import AdminInfo.AdminInfo;
import Dao.AccountDao;
import Dao.AdminDao;

/**
 * Servlet implementation class DeleteAccount
 */
@WebServlet("/DeleteAccount")
public class DeleteAccount extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeleteAccount() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		Dao.AccountDao dao = new AccountDao();
		AccountInfo ad = new AccountInfo();
		PrintWriter out = response.getWriter();

		int id = Integer.parseInt(request.getParameter("id"));

		if (ad.SearchAdmin(id)) {
			Boolean b = dao.DeleteAccount(id);
			Boolean b1 = dao.DeleteAddress(id);
			boolean b2 = dao.DeleteCustmer(id);
			if (b == b1 && b1==b2) {
				out.print(
						"<h3> Your Request is Accepted <br>" + id + "\t:This  Custmer Account or Address Deleted </h3>");
			} else if (b) {
				out.print("<h3> Your Request is Accepted <br>" + id + "\t:This Custmer Account  Deleted Only...</h3>");
			} else if (b1) {
				out.print("<h3> Your Request is Accepted <br>" + id + "\t:This  Custmer Address  Deleted Only...</h3>");
			}
			 else if (b2) {
					out.print("<h3> Your Request is Accepted <br>" + id + "\t:This  Custmer Infromation Deleted Only...</h3>");
				}

		} else {
			out.print("<h3> Account Not Present In Bank.</h3>");

		}
	
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
