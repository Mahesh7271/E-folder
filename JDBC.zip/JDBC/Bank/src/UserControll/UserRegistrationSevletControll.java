package UserControll;

import java.io.IOException;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import AccountInfo.Account;
import Basicclass.Address;
import Basicclass.Custmer;
import Basicclass.Methodes;
import Dao.AccountDao;

/**
 * Servlet implementation class UserRegistrationSevletControll
 */
@WebServlet("/UserRegistrationSevletControll")
public class UserRegistrationSevletControll extends HttpServlet
{
	private static final long serialVersionUID = 1L;
	Methodes methodes = new Methodes();
	AccountDao  dao= new AccountDao();
	Scanner scanner = new Scanner(System.in);

	public String getMobileNO() 
	{
		System.out.println("Enter your Mobile number || Do not add +91/0");
		Scanner scanner = new Scanner(System.in);
		String string = scanner.next();
		String str = null;
		if(checkNumber(string))
		 str=string;
		else
			getMobileNO();
		return string;			
	}
	public String getPincodenumber() 
	{
		System.out.println("Enter your Valied Pincode number ");
		Scanner scanner = new Scanner(System.in);
		String string = scanner.nextLine();
		String str = null;
		if(checkPincode(string))
		 str=string;
		else
			getPincodenumber();
		return string;			
	}
	public  Boolean checkNumber(String string)
	{
		boolean b = false ;
		if (methodes.isVarification(string))
		{

			System.out.println("Valid Mobile Number");
		b=true;	
		}
		else
			System.out.println("not valid");
		return  b;
	}
	public  Boolean checkPincode(String string)
	{
		boolean b = false;
		if (methodes.IsValiedPincode(string))
		{

			System.out.println("Valid Mobile Number");
		b=true;	
		}
		else
			System.out.println("not valid");
		return  b;
	}

    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserRegistrationSevletControll() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int Account_ID=methodes.RandomNumber();
		String Fname =request.getParameter("FName");
		String Lname =request.getParameter("LName");
		String Mobile =request.getParameter("Mobile");
		Custmer custmer = new Custmer(0, Fname,Lname,Mobile);
		String state = request.getParameter("State");
		
		char[] arr = methodes.getstate(state);
		String str = String.valueOf(arr);
		String City =  request.getParameter("City");
		String Pincode =  request.getParameter("Pincode");
		
		Address address = new Address(0,City,str,Pincode);
		
		String Acctype = request.getParameter("AccType");
		String AccBal= request.getParameter("AccBal");
		String arr1 	= methodes.getAccount(Acctype);
		Account account = new Account(0,Account_ID,arr1,Float.parseFloat(AccBal) );
		List<Account> AcconutList = new ArrayList<Account>();
		AcconutList.add(account);
		int i=dao.InsertAccount(AcconutList);
		int i1=dao.InsertAddress(address);
		int i2=dao.InsertCustmer(custmer);
		
	/**
	 * System.out.println(account.toString());
	   System.out.println(address.toString());
	   System.out.println(custmer.toString());
	*/
		if (i>0 )
		{
		response.sendRedirect("xyz.html");	
		}
		else
		{
			response.sendRedirect("NewUserScreen.html");
		}
		/**return  AcconutList;
	*/
}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
				doPost(request, response);
	}		

}
