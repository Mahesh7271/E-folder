package com.model.ProjectEmbeddable;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.model.MVC.Address;
import com.model.MVC.Employee;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("TP");
		EntityManager manager = entityManagerFactory.createEntityManager();
		ArrayList<Address> address = new ArrayList<Address>();

		Address address1 = new Address("Pune", "Maharashtra", 411015);
		Address address2 = new Address("Baner", "Maharashtra", 411012);
		Address address3 = new Address("Kharadi", "Maharashtra", 411013);
		Address address4 = new Address("Gokhalenagar", "Maharashtra", 411014);

		Employee employee1 = new Employee();
		employee1.setEmployeeName("Pankaj");
		employee1.setEmployeeSalary(52401);
		employee1.getList().add(address1);
		employee1.getList().add(address2);
		
		Employee employee2 = new Employee();
		employee2.setEmployeeName("Mahesh");
		employee2.setEmployeeSalary(524010);
		employee2.getList().add(address2);

		manager.getTransaction().begin();

		manager.persist(employee1);
		manager.persist(employee2);

		manager.getTransaction().commit();

	}
}
