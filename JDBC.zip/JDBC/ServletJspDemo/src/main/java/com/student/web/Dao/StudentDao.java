package com.student.web.Dao;

import java.sql.Connection;

import com.pojo.web.model.Student;

public class StudentDao 
{
	public Student getStudent(int id) {
		
		Student student = new Student(101, "Mahesh", 98);
		
		return student;
	}
	
}
