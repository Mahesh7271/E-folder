package com.test;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.symbiosisPojo.mvc.Customer;

public class testCustomer {
	public static void main(String[] args) {
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("TP");
		EntityManager manager = entityManagerFactory.createEntityManager();

		/*
		 * Customer customer1 = new Customer(101, "Pankaj", 45000); Customer
		 * customer2 = new Customer(102, "mohit", 45000); Customer customer3 =
		 * new Customer(103, "suraj", 45000); Customer customer4 = new
		 * Customer(104, "narayan", 45000); manager.getTransaction().begin();
		 * 
		 * manager.persist(customer1); manager.persist(customer2);
		 * manager.persist(customer3); manager.persist(customer4);
		 * 
		 * manager.getTransaction().commit();
		 */

		Query query1 = manager.createQuery("select count(c) from Customer c");
		System.out.println(query1.getSingleResult());

		Query query2 = manager.createQuery("select max(c.Customer_salary) from Customer c");
		System.out.println(query2.getSingleResult());

		Query query3 = manager
				.createQuery("select c.customer_Name from Customer c where c.Customer_salary between 400 and 5000000");
		System.out.println(query3.getSingleResult());

		List<Customer> list = query3.getResultList();

		for (Customer customer : list) {
			System.out.println(customer);
		}
	}
}
