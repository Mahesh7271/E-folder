package com.test;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.symbiosisPojo.mvc.Student;

public class testStudent {
	public static void main(String[] args) {
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("TP");
		EntityManager manager = entityManagerFactory.createEntityManager();

		/*
		 * Student student = new Student(10," mahesh");
		 */
		Student student = new Student(12, "Pankaj");
		/*
		 * manager.getTransaction().begin(); manager.persist(student);
		 * manager.getTransaction().commit();
		 */
		/*
		 * query is interface 
		 * query q =
		 */
		Query q = manager.createQuery("select s from Student s");
		List<Student> listName = q.getResultList();
		for (Student name : listName)
			System.out.println(name.getS_id()+"\t"+name.getS_name());
	}
}
