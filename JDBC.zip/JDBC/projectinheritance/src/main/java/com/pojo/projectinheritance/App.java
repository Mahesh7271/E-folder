package com.pojo.projectinheritance;

import com.model.CurrentEmployee;

public class App 
{
    public static void main( String[] args )
    {
        CurrentEmployee cr=new CurrentEmployee(10134,4,1,"ajay");
        System.out.println(cr);
        
    }
}
