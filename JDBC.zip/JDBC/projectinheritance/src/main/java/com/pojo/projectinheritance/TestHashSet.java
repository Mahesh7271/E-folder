package com.pojo.projectinheritance;

import java.util.Iterator;
import java.util.TreeSet;

public class TestHashSet {
	public static void main(String[] args) {
/*		Set<String> set = new HashSet<String>();
		set.add("Pankaj");
		set.add("Sakshi");
		set.add("akansha");
		set.add("komal");
		System.out.println("--------------- this is  Hashset ---------------");

		for (String s : set)
			System.out.println(s);

		Set<String> set1 = new LinkedHashSet<String>();
		set1.add("Pankaj");
		set1.add("Sakshi");
		set1.add("akansha");
		set1.add("komal");
		System.out.println("--------------- this is linkedhashSet set ---------------");
		for (String s : set1)
			System.out.println(s);
*/
		TreeSet<Object> set2 = new TreeSet<Object>();
		set2.add(101);
		set2.add(10.1);
		
		System.out.println("--------------- this is tree set ---------------");

		Iterator<Object> iterator = set2.iterator();
		while (iterator.hasNext()) {
			Object object = (Object) iterator.next();
			System.out.println(object);
		}
		System.out.println(set2);
	}
	

}
