package com.model;

public class RetiredEmployee extends Employee
{
	private int pention;
	
	

	public RetiredEmployee() {
		super();
	}



	public RetiredEmployee(int pention) {
		super();
		this.pention = pention;
	}



	public int getPention() {
		return pention;
	}



	public void setPention(int pention) {
		this.pention = pention;
	}



	@Override
	public String toString() {
		return "RetiredEmployee [pention=" + pention + "]";
	}
	
	

}
