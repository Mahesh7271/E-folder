package com.model;

public class CurrentEmployee extends Employee {
	private int salary;
	private int experience;

	public CurrentEmployee() {
		super();
	}

	public CurrentEmployee(int salary, int experience, int id, String name) {
		super(id, name);
		this.salary = salary;
		this.experience = experience;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public int getExperience() {
		return experience;
	}

	public void setExperience(int experience) {
		this.experience = experience;
	}

	@Override
	public String toString()

	{
		display();
		return "CurrentEmployee [salary=" + salary + ", experience=" + experience + "]";
	}

}
