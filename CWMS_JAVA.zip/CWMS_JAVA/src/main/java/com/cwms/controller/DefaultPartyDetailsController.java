package com.cwms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cwms.entities.DefaultPartyDetails;
import com.cwms.repository.DefaultParyDetailsRepository;

@CrossOrigin
@RestController
@RequestMapping("/defaultparty")
public class DefaultPartyDetailsController {

	@Autowired
	public DefaultParyDetailsRepository defaultrepo;
	
	@GetMapping("/getdata/{cid}/{bid}/{uid}")
	public DefaultPartyDetails getdata(@PathVariable("cid") String cid,@PathVariable("bid") String bid,@PathVariable("uid") String uid) {
		return defaultrepo.getdatabyuser_id(cid, bid, uid);
	}
	
	
	@PostMapping(value = "/SaveRecord")
	public DefaultPartyDetails SaveRecord(@RequestBody DefaultPartyDetails entity) {
		entity.setCurrentDate();
		System.out.println(entity);
		return defaultrepo.save(entity);
//		return entity;
	}
}
