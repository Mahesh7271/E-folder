package com.cwms.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cwms.entities.Branch;
import com.cwms.entities.Company;
import com.cwms.entities.ExternalParty;
import com.cwms.entities.Import;
import com.cwms.entities.Import_History;
import com.cwms.repository.BranchRepo;
import com.cwms.repository.CompanyRepo;
import com.cwms.repository.ExternalPartyRepository;
import com.cwms.repository.ImportRepo;
import com.cwms.repository.ImportRepository;
import com.cwms.repository.PartyRepository;
import com.cwms.service.ImportService;
import com.cwms.service.ImportServiceImpl;
import com.cwms.service.Import_HistoryService;
import com.cwms.service.Importserviceforpctm;
import com.cwms.service.ProcessNextIdService;

@RestController
@CrossOrigin("*")
@RequestMapping("/import")
public class ImportController {

	@Autowired
	private ImportRepository imprepo;
	
	@Autowired
	private ImportServiceImpl importService;
	
	@Autowired
	private Import_HistoryService historyService;
	
	@Autowired
	public ImportService importServices;
	
	@Autowired
	private PartyRepository partyRepository;
	
	@Autowired
	public ProcessNextIdService proccessNextIdService;
	
	@Autowired
	private Importserviceforpctm importservicepctm;
	
	@Autowired
	private CompanyRepo companyRepo;
	
	@Autowired
	private BranchRepo branchRepo;
	
	
	@Autowired
	private ImportRepo importRepo;
	
	@Autowired
	private ExternalPartyRepository externalPartyRepository;
	
	
	@GetMapping("/all/{cid}/{bid}")
	public List<Import> getAll1(@PathVariable("cid") String cid,@PathVariable("bid") String bid) {
		return this.imprepo.findByAll(cid,bid);
	}
	
	@GetMapping("/single/{cid}/{bid}/{sir}")
	public Import getSingledata(@PathVariable("cid") String cid,@PathVariable("bid") String bid,@PathVariable("sir") String sir) {
		return this.importRepo.Singledata(cid, bid, sir);
	}

	
	@GetMapping("/tpdate")
	public List<String> getAllbytpdate(@RequestParam("date") @DateTimeFormat(pattern = "yyyy-MM-dd") Date date,@RequestParam("cid") String cid,@RequestParam("bid") String bid) {
		
		return imprepo.findByTp(date,cid,bid);
	}
	
	@GetMapping("/getalldata")
	public List<Import> getallbyTpnoandTpdate(
	    @RequestParam("cid") String cid,
	    @RequestParam("bid") String bid,
	    @RequestParam("date") @DateTimeFormat(pattern = "yyyy-MM-dd") Date date,
	    @RequestParam("tpno") String tpno
	  //  @RequestParam("status") char status
	    ) { // Change the parameter name to "status"
	    return imprepo.findByTpdateTpno(cid, bid, date, tpno); // Use "status" parameter here
	}
	
	@GetMapping("/importData")
	public List<Object[]> getImportData(@RequestParam("companyId") String companyId,
			@RequestParam("branchId") String branchId,
			@RequestParam("startDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date startDate,
			@RequestParam("endDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date endDate,

			@RequestParam("airlineName") String airlineName) {
		
//		 System.out.println("Received companyId: " + companyId);
//		    System.out.println("Received branchId: " + branchId);
//		    System.out.println("Received startDate: " + startDate);
//		    System.out.println("Received endDate: " + endDate);
//		    System.out.println("Received airlineName: " + airlineName);
		List<Object[]> imp = importService.findImportData(companyId, branchId, startDate, endDate, airlineName);

		
		for (Object[] i : imp) {
			System.out.println(i);
		}
		return imp;
	}

	// Dyanamic
	@GetMapping("/airline-names")
	public List<String> getAirlineNames(@RequestParam("companyId") String companyId,
			@RequestParam("branchId") String branchId,
			@RequestParam("startDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date startDate,
			@RequestParam("endDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date endDate) {
//		List<String> airlineNames = importService.findAirlineName(companyId, branchId, startDate, endDate);
//		 
//		Import i= new Import();
//		i.getSirDate();
//		System.out.println( "Sir Date is" +i.getSirDate());
//
//		// Print each airline name individually
//		for (String name : airlineNames) {
//			System.out.println(name);
//		}
//
//		return airlineNames;
		
		return importRepo.findAirlineNames(companyId, branchId, startDate, endDate);
	}
	
	
	
	@GetMapping("/airlineNames/{companyId}/{branchId}/{startDate}/{endDate}")
	public List<String> getallAirlineNames(@PathVariable("companyId") String companyId,
			@PathVariable("branchId") String branchId,
			@PathVariable("startDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date startDate,
			@PathVariable("endDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date endDate) {
//		List<String> airlineNames = importService.findAirlineName(companyId, branchId, startDate, endDate);
//		 
//		Import i= new Import();
//		i.getSirDate();
//		System.out.println( "Sir Date is" +i.getSirDate());
//
//		// Print each airline name individually
//		for (String name : airlineNames) {
//			System.out.println(name);
//		}
//
//		return airlineNames;
		
		return importRepo.findAirlineNames(companyId, branchId, startDate, endDate);
	}
	
	
	
	

	@GetMapping("/allimportData")
	public List<Import> getAllImportData(@RequestParam("companyId") String companyId,
			@RequestParam("branchId") String branchId,
			@RequestParam("startDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date startDate,
			@RequestParam("endDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date endDate,

			@RequestParam("airlineCode") String airlineCode) {
		
//		 System.out.println("Received companyId: " + companyId);
      return imprepo.findImportAllData(companyId, branchId, startDate, endDate, airlineCode);
	}
	
	@PostMapping("/importDataAndUpdatePCTM")
	public List<Import> getImportDataAndUpdatePCTM(
	        @RequestParam("companyId") String companyId,
	        @RequestParam("branchId") String branchId,
	        @RequestParam("startDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date startDate,
	        @RequestParam("endDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date endDate,
	        @RequestParam("airlineCode") String airlineCode) {
//	    System.out.println("Received companyId: " + companyId);

	    // Get import data with pctmNo null
	    List<Import> importDataToUpdate = importRepo.findImportAllData(
	            companyId, branchId, startDate, endDate, airlineCode);

	    String updatedCount = proccessNextIdService.generateAndIncrementPCTMNumber();
//	    String tpNo=proccessNextIdService.generateAndIncrementTPumber();
	    // Update the pctmNo for each record
	    for (Import impo : importDataToUpdate) {
	       
	        impo.setPctmNo(updatedCount);
//	        impo.setTpNo(tpNo);
	        impo.setTpDate(new Date());
	    }

	    // Save the updated records
	    importRepo.saveAll(importDataToUpdate);

	    return importDataToUpdate;
	}

	@GetMapping("/getPctmNo")
	public List<String> getPctmNo(@RequestParam("companyId") String companyId,
			@RequestParam("branchId") String branchId,
			  @RequestParam("startDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date startDate,
		        @RequestParam("endDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date endDate,
			@RequestParam("airlineCode") String airlineCode
	){
		
//		 System.out.println("Received companyId: " + companyId);
      return importRepo.findDistinctPctmNos(companyId, branchId, startDate,endDate, airlineCode);
	}
	
	// Dyanamic
		@GetMapping("/Allairline-names")
		public List<String> getAllAirlineNames(@RequestParam("companyId") String companyId,
				@RequestParam("branchId") String branchId,
				@RequestParam("startDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date startDate,
				@RequestParam("endDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date endDate) {
			
			
			
			List<String> airlineName = importService.findAllAirlineName(companyId, branchId, startDate, endDate);
//			 System.out.println(airlineName);
			return airlineName;
		}

	
		@GetMapping("/allimportPCTMData")
		public List<Import> getAllImportPCTMData(@RequestParam("companyId") String companyId,
				@RequestParam("branchId") String branchId,
				@RequestParam("startDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date startDate,
				@RequestParam("endDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date endDate,

				@RequestParam("airlineCode") String airlineCode,
		@RequestParam("pctmNo") String pctmNo){
			
//			 System.out.println("Received companyId: " + companyId);
	      return importRepo.findImportPCTMData(companyId, branchId, startDate, endDate, airlineCode,pctmNo);
		}
	
	
	
	

	
	
	
	
	
	@GetMapping("/{compid}/{branchId}/{tranId}/{MAWB}/{HAWB}/{sirNo}/getSingle")
	public Import findByMAWBANDHAWB(
	        @PathVariable("MAWB") String MAWB,
	        @PathVariable("HAWB") String HAWB,
	        @PathVariable("compid") String compid,
	        @PathVariable("branchId") String branchId,
	        @PathVariable("tranId") String transId,
	        @PathVariable("sirNo") String sirNo) {
	    
	    return importServices.getByMAWBANdHAWB(compid, branchId, transId, MAWB, HAWB, sirNo);
	}
	
	
	@GetMapping("/{cid}/{bid}/{MAWBNo}")
	public List<Import> getByMawbNo(@PathVariable("MAWBNo")String MAWBNo,@PathVariable("cid") String cid, @PathVariable("bid") String bid)
	{
		return importServices.getByMAWB(cid,bid,MAWBNo);
	}
	
	@GetMapping("/{cid}/{bid}/All")
	public List<Import> getAll(@PathVariable("cid") String cid, @PathVariable("bid") String bid)
	{
		return importServices.getAll(cid,bid);
	}
	
	
	@PostMapping("/{compid}/{branchId}/{user}/add")
	public Import addImport(@PathVariable("compid")String compid,@PathVariable("branchId")String branchId,
			@RequestBody Import import2,@PathVariable("user")String User)
	{
		import2.setCompanyId(compid);
		import2.setBranchId(branchId);
		import2.setNSDL_Status("");
		import2.setDGDC_Status("Handed over to DGDC Cargo");
		
		String autoIncrementIMPTransId = proccessNextIdService.autoIncrementIMPTransId();
		import2.setImpTransId(autoIncrementIMPTransId);
		String autoIncrementSIRId = proccessNextIdService.autoIncrementSIRId();
		import2.setSirNo(autoIncrementSIRId);
		import2.setSirDate(new Date());
		import2.setImpTransDate(new Date());
		import2.setCreatedBy(User);
		import2.setCreatedDate(new Date());
		import2.setStatus("A");
		import2.setApprovedBy(User);
		import2.setApprovedDate(new Date());
		import2.setEditedBy(User);
		import2.setEditedDate(new Date());
		
		Import_History history=new Import_History();
		history.setCompanyId(compid);
		history.setBranchId(branchId);
		history.setSirNo(autoIncrementSIRId);
		history.setMawb(import2.getMawb());
		history.setHawb(import2.getHawb());
		history.setTransport_Date(new Date());
		history.setOldStatus("Pending");
		history.setNewStatus("Handed over to DGDC Cargo");
		history.setUpdatedBy(User);
		historyService.addHistory(history);
		return importServices.addImport(import2);
	}
	
	@PutMapping("/{compid}/{branchId}/{user}/update")
	public Import updateImport(@PathVariable("compid")String compid,@PathVariable("branchId")String branchId,
			@RequestBody Import import2,@PathVariable("user")String User)
	{
//		import2.setBranchId(branchId);
		import2.setEditedBy(User);
		import2.setEditedDate(new Date());
//		
		return importServices.updateImport(import2);
	}
	
	@PutMapping("/{compid}/{branchId}/{user}/modifyupdate")
	public Import updateImportByIMpTransId(@PathVariable("compid")String compid,@PathVariable("branchId")String branchId,
			@RequestBody Import import2,@PathVariable("user")String User)
	{
//		import2.setBranchId(branchId);
		
		Import existingImport = importServices.findBytransIdAndSirNo(compid,branchId,import2.getImpTransId(),import2.getSirNo());
		
		if(existingImport != null)
		{
			
			importServices.deleteImport(existingImport);
			Import newImport=new Import();
			
		newImport.setEditedBy(User);
		newImport.setEditedDate(new Date());
		newImport.setAirlineName(import2.getAirlineName());
		newImport.setCreatedBy(import2.getCreatedBy());
		newImport.setCreatedDate(import2.getCreatedDate());
		newImport.setApprovedBy(import2.getApprovedBy());
		newImport.setApprovedDate(import2.getApprovedDate());
		newImport.setCompanyId(import2.getCompanyId());
		newImport.setBranchId(import2.getBranchId());
		newImport.setMawb(import2.getMawb());
		newImport.setHawb(import2.getHawb());
		newImport.setSirNo(import2.getSirNo());
		newImport.setNop(import2.getNop());
		newImport.setImporterId(import2.getImporterId());
		newImport.setConsoleName(import2.getConsoleName());
		newImport.setImportRemarks(import2.getImportRemarks());
		newImport.setBeDate(import2.getBeDate());	
		newImport.setSirDate(import2.getSirDate());
		newImport.setImpTransId(import2.getImpTransId());
		newImport.setImpTransDate(import2.getImpTransDate());
		newImport.setBeDate(import2.getBeDate());
		newImport.setIec(import2.getIec());
		newImport.setBeNo(import2.getBeNo());
		newImport.setBeRequestId(import2.getBeRequestId());
		newImport.setIgmNo(import2.getIgmNo());
		newImport.setIgmDate(import2.getIgmDate());
		newImport.setPctmNo(import2.getPctmNo());
		newImport.setPackageContentType(import2.getPackageContentType());
		newImport.setUomPackages(import2.getUomPackages());
		newImport.setUomWeight(import2.getUomWeight());
		newImport.setTpNo(import2.getTpNo());
		newImport.setTpDate(import2.getTpDate());
		newImport.setFlightNo(import2.getFlightNo());
		newImport.setFlightDate(import2.getFlightDate());
		newImport.setCountryOrigin(import2.getCountryOrigin());
		newImport.setPortOrigin(import2.getPortOrigin());
		newImport.setNSDL_Status(import2.getNSDL_Status());
		newImport.setDGDC_Status(import2.getDGDC_Status());
		newImport.setDescriptionOfGoods(import2.getDescriptionOfGoods());
		newImport.setImportAddress(import2.getImportAddress());
		newImport.setChaCde(import2.getChaCde());
		newImport.setAssessableValue(import2.getAssessableValue());
		newImport.setGrossWeight(import2.getGrossWeight());
		newImport.setStatus(import2.getStatus());
		
		return importServices.updateImport(newImport);
		}
		
		return null;
	}
	
	@DeleteMapping("/{compid}/{branchId}/{tranId}/{MAWB}/{HAWB}/{sirNo}/delete")
	public void deleteImport(@PathVariable("MAWB") String MAWB,
	        @PathVariable("HAWB") String HAWB,
	        @PathVariable("compid") String compid,
	        @PathVariable("branchId") String branchId,
	        @PathVariable("tranId") String transId,
	        @PathVariable("sirNo") String sirNo)
	{
		Import byMAWBANdHAWB = importServices.getByMAWBANdHAWB(compid, branchId, transId, MAWB, HAWB, sirNo);
		if(byMAWBANdHAWB != null)
		{
			byMAWBANdHAWB.setStatus("D");
			importServices.updateImport(byMAWBANdHAWB);
		}
	}
	
	@GetMapping("/importTransaction")
    public ResponseEntity<List<Import>> findByCompanyIdAndBranchIdAndSbDateAndDgdcStatus(
			@RequestParam("sirDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date sirDate,
            @RequestParam("companyId") String companyId,
            @RequestParam("branchId") String branchId,
            @RequestParam("dgdcStatus") String dgdcStatus) {

	 
	 SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String formattedDate = sdf.format(sirDate);
		
	 System.out.println(formattedDate);
	 
        List<Import> imports = importservicepctm.findByCompanyIdAndBranchIdAndSbDateAndDgdcStatus(formattedDate, companyId, branchId, dgdcStatus);
        
        System.out.println(imports);
        if (imports.isEmpty()) {
            return ResponseEntity.notFound().build();
            
        }

        return ResponseEntity.ok(imports);
    }

	@GetMapping(value = "/findCompanyname/{cid}")
	public String findCompanyname(@PathVariable("cid") String param) {
	Company company=	 companyRepo.findByCompany_Id(param);
		
		return company.getCompany_name();
	}

	@GetMapping(value = "/findBranchName/{cid}/{bid}")
	public String findBranchName(@PathVariable("cid") String cid,@PathVariable("bid") String bid) {
	Branch branch =branchRepo.findByBranchIdWithCompanyId(cid, bid);
		return branch.getBranchName();
	}
	
	

	@GetMapping(value = "/getConsole/{companyId}/{branchId}/{doDate}")
    public List<ExternalParty> getConsoleList(
            @PathVariable("companyId") String companyId,
            @PathVariable("branchId") String branchId,
            @PathVariable("doDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date doDate) {

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String formattedDate = sdf.format(doDate);

        List<String> cIds = importRepo.findByCompanyAndBranchAndDoDate(companyId, branchId, formattedDate);

        List<ExternalParty> externalParties = new ArrayList<>();
       
        for (String string : cIds) {
           
            ExternalParty external = externalPartyRepository.findBycompbranchexternal(companyId, branchId, string);
            if (external != null) {
                externalParties.add(external);
            }
        }

        return externalParties;
    }

	@GetMapping(value = "/getImportList/{companyId}/{branchId}/{doDate}/{exId}")
	public List<Import> getImportList(@PathVariable("companyId") String companyId,
			@PathVariable("branchId") String branchId,
			@PathVariable("doDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date doDate,
			@PathVariable("exId") String exId) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String formattedDate = sdf.format(doDate);
		List<Import> imports = importRepo.findByCompanyAndBranchAndDoDateAndexternalPId(companyId, branchId,
				formattedDate, exId);
		return imports;
	}

	@GetMapping(value = "/getDoNumber/{companyId}/{branchId}/{mawb}")
	public String getDoNumber(@PathVariable("companyId") String companyId, @PathVariable("branchId") String branchId,
			@PathVariable("mawb") String mawb) {
//		System.out.println(companyId + "\t" + branchId + "\t" + mawb);
//		System.out.println(importRepo.findByCompanyAndBranchAndMawb(companyId, branchId, mawb));
		return importRepo.findByCompanyAndBranchAndMawb(companyId, branchId, mawb);
	}

	@GetMapping(value = "/getDoNumberForUpdate/{companyId}/{branchId}")
	public List<Import> getDoNumberForUpdate(@PathVariable("companyId") String companyId,
			@PathVariable("branchId") String branchId) {

		return importRepo.findByCompanyAndBranchNUllDo(companyId, branchId);
	}

	@GetMapping(value = "/getUpdateDoNumber/{companyId}/{branchId}")
	public List<String> getUpdateDoNumber(@PathVariable("companyId") String companyId,
			@PathVariable("branchId") String branchId) {
		List<String> strings = new ArrayList<>();
		List<String> mawbStrings = importRepo.findMawbByCompanyAndBranch(companyId, branchId);
		System.out.println(mawbStrings);

		for (String mawb : mawbStrings) {
			List<Import> importList = importRepo.findByCompanyAndBranchAndMawbList(companyId, branchId, mawb);
			String olddo = importRepo.findByCompanyAndBranchAndMawb(companyId, branchId, mawb);
			String temp = null;

			if (olddo != null && !olddo.trim().isEmpty()) {
				temp = olddo;
			} else
				temp = proccessNextIdService.autoIncrementDoNumber();
			for (Import import1 : importList) {

				if (import1.getDoDate() != null) {
					import1.setDoNumber(temp);
				} else {
					import1.setDoNumber(temp);
					import1.setDoDate(new Date());
				}

			}
			importRepo.saveAllAndFlush(importList);

		}

		return strings;
	}

	@GetMapping(value = "/getExternalPartys/{companyId}/{branchId}")
	public List<ExternalParty> getExternalPartyUserName(@PathVariable("companyId") String companyId,
			@PathVariable("branchId") String branchId) 
	{

		return externalPartyRepository.getalldataExternalParties(companyId, branchId);
	}
	
	@GetMapping("/findImportAllData")
	public List<Import> findExportSubData(@RequestParam("companyId") String companyId,
			@RequestParam("branchId") String branchId,
			@RequestParam("startDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date startDate,
			@RequestParam("endDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date endDate,

			@RequestParam("consoleName") String consoleName) {
		return imprepo.findIMMportAllData(companyId, branchId, startDate, endDate, consoleName);
	}

	@GetMapping("/findImportData")
	public List<Import> findExportSubData(@RequestParam("companyId") String companyId,
			@RequestParam("branchId") String branchId,
			@RequestParam("startDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date startDate,
			@RequestParam("endDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date endDate

	) {
		return imprepo.findImportData(companyId, branchId, startDate, endDate);
	}
	@GetMapping("/findPartyName/{companyId}/{branchId}/{partyId}")
	public String findPartyNameByKeys(@PathVariable String companyId, @PathVariable String branchId,
			@PathVariable String partyId) {
		String partyName = partyRepository.findPartyNameByKeys(companyId, branchId, partyId);

		if (partyName != null) {
			return partyName;
		} else {
			// Handle the case where partyName is not found
			return "Party Name Not Found";
		}
	}

	@GetMapping("/findConsoleName/{companyId}/{branchId}/{externaluserId}")
	public String findConsoleName(@PathVariable String companyId, @PathVariable String branchId,
			@PathVariable String externaluserId) {
		String console_name = externalPartyRepository.findUserNameByKeys(companyId, branchId, externaluserId);

		if (console_name != null) {
			return console_name;
		} else {
			// Handle the case where partyName is not found
			return "User Name Not Found";
		}
	}
}
