package com.cwms.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import com.cwms.entities.DemuragePackagesHistory;

public interface DemuragePackagesHistoryRepositary extends JpaRepository<DemuragePackagesHistory, Long>
{
	List<DemuragePackagesHistory> findByCompanyIdAndBranchIdAndPartyIdAndInviceNo(String companyId,String branchId,String partyId,String invoiceno);	
	
}
