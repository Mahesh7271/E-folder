package com.cwms.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.repository.query.Param;

import com.cwms.entities.DefaultPartyDetails;

@EnableJpaRepositories
public interface DefaultParyDetailsRepository extends JpaRepository<DefaultPartyDetails, String> {

	@Query(value="select * from default_party_dtls where company_id=:cid and branch_id=:bid and user_Id=:uid and status='A'",nativeQuery=true)
	public DefaultPartyDetails getdatabyuser_id(@Param("cid") String cid,@Param("bid") String bid,@Param("uid") String uid);
}
