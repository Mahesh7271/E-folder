package com.cwms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cwms.entities.InvoiceMain;
import com.cwms.repository.InvoiceRepositary;

@Service
public class InvoiceServiceIMPL 
{	
	@Autowired
	private InvoiceRepositary invoiceRepositary;
	
//	@Autowired
//	private InvoiceDetailRepostary detailRepostary;
	
	
	
	public InvoiceMain addInvoice(InvoiceMain invoiceMain)
	{		
		return invoiceRepositary.save(invoiceMain);
	}
	
	public InvoiceMain getByInvoiceNo(String compId,String branchId,String partyid,String invoiceNo)
	{
		return invoiceRepositary.findByCompanyIdAndBranchIdAndPartyIdAndInvoiceNO(compId, branchId, partyid, invoiceNo);
	}
	public List<InvoiceMain> getByPartyId(String compId,String branchId,String partyid)
	{
		return invoiceRepositary.findByCompanyIdAndBranchIdAndPartyId(compId, branchId, partyid);
	}

}
