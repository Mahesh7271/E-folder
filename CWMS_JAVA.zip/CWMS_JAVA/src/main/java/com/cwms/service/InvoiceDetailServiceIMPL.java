package com.cwms.service;

import java.math.BigDecimal;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cwms.entities.CFSTariffRange;
import com.cwms.entities.CFSTariffService;
import com.cwms.entities.InvoiceDetail;
import com.cwms.entities.Services;
import com.cwms.repository.InvoiceDetailRepostary;

@Service
public class InvoiceDetailServiceIMPL {

//	@Autowired
//	private InvoiceRepositary invoiceRepositary;

	@Autowired
	private InvoiceDetailRepostary detailRepostary;

	@Autowired
	public cfsTarrifServiceService cfsTarrifServiceService;

	@Autowired
	public CFSTariffRangeService CFSTariffRangeService;

	@Autowired
	public ServicesInterface ServicesInterface;

	public InvoiceDetail addInvoiceDetail(String companyId, String branchId, String Invoiceno, String tarrifno,
			String amndno, String serviceId, String partyId, int noOfPackages, String user ,Date invoiceDate) {
		Services servicesById = ServicesInterface.getServicesById(companyId, branchId, serviceId);
		String rangeType = servicesById.getRateCalculation();
		String taxApplicable = servicesById.getTaxApplicable();
		String serviceUnit = servicesById.getServiceUnit();
		double totalPackageDecimal = (double) noOfPackages;
		double rate = 0.0;
		String currencyId = "INR";
		double TaxPercentage = 0.0;
		double billAmount = 0.0;
		double taxamount = 0.0;
		double totalAmount = 0.0;

		if (taxApplicable != null && taxApplicable.equals("Y")) {
			TaxPercentage = Double.parseDouble(servicesById.getTaxPercentage());
		}

//		If rate type is Plain

		if ("Plain".equals(rangeType)) {
			CFSTariffService cfsservice = cfsTarrifServiceService.findByTarrifNoandServiceIdPartyId(companyId, branchId,
					tarrifno, amndno, serviceId, partyId);

			currencyId = cfsservice.getCurrencyId();
			rate = cfsservice.getRate();

			if (TaxPercentage != 0.0) {
				taxamount = rate * (TaxPercentage / 100.0);
				billAmount = totalPackageDecimal * rate;
				totalAmount = billAmount + taxamount;
			} else {
				billAmount = rate * totalPackageDecimal;
				totalAmount = billAmount;
			}

		}
//		If rate type is Range or Slab 
		else {

			List<CFSTariffRange> tariffRanges = CFSTariffRangeService
					.findByCfsTariffNoAndCfsAmndNoAndServiceIdAndPartyId(companyId, branchId, tarrifno, amndno,
							serviceId, partyId);

			if (!tariffRanges.isEmpty()) {
				currencyId = tariffRanges.get(0).getCurrencyId();
			}

			 // Sort the tariffRanges by rangeFrom in ascending order
		    tariffRanges.sort(Comparator.comparingDouble(CFSTariffRange::getRangeFrom));
			for (CFSTariffRange tariffRange : tariffRanges) {
				double rangeFrom = tariffRange.getRangeFrom();
				double rangeTo = tariffRange.getRangeTo();
				double rangeRate = tariffRange.getRangeRate();
//				double ratePlain = 

//				If rate type is Range
				
				if ("Range".equals(rangeType)) {					
					

					if (totalPackageDecimal > rangeFrom && totalPackageDecimal <= rangeTo) {
						rate = rangeRate;
						
						if (TaxPercentage != 0.0) {
							taxamount = rate * (TaxPercentage / 100.0);
												
//							if("Per Kg".equals(serviceUnit))
//							{
								billAmount = rate;
//							}
//							else
//							{
//								billAmount = totalPackageDecimal * rate;
//							}

							totalAmount = billAmount + taxamount;
							
						} else {
							billAmount = rate;
							totalAmount = billAmount;
						}
						
						
						break;
					}
				

				}

//				If rate type is Slab
				if ("Slab".equals(rangeType)) {
					
//									
					if (totalPackageDecimal <= 0) {
						break; // No need to continue if we've accounted for the entire totalPackage
					}

					if (totalPackageDecimal >= (rangeTo - rangeFrom)) {
						// If remainingPackage is greater than or equal to the entire range, calculate
						// rate
						rate += (rangeTo - rangeFrom) * rangeRate;		
						totalPackageDecimal -= (int) (rangeTo - rangeFrom);
					} else {
						rate += totalPackageDecimal * rangeRate;
						totalPackageDecimal = 0.0;
					}
					
					
					if (TaxPercentage != 0.0) {
						taxamount = rate * (TaxPercentage / 100.0);
																		
						billAmount = rate;
											
						totalAmount = billAmount + taxamount;
						
					} else {
						billAmount = rate;
						totalAmount = billAmount;
					}	
					
				}

			}

		}

		InvoiceDetail detail = new InvoiceDetail(companyId, branchId, Invoiceno, partyId, serviceId,invoiceDate,
				serviceUnit, serviceUnit, serviceUnit, rate, currencyId, TaxPercentage, taxamount, billAmount,
				totalAmount, "A", user, new Date(), user, new Date(), user, new Date());

		return detailRepostary.save(detail);
	}
	
	
//	Range Service Heavy Weight
	
	
	public InvoiceDetail addInvoiceDetailHeavyWeight(String companyId, String branchId, String Invoiceno, String tarrifno,
			String amndno, String serviceId, String partyId, int noOfPackages, String user ,Date invoiceDate,List<BigDecimal> weights) {
		Services servicesById = ServicesInterface.getServicesById(companyId, branchId, serviceId);
		String rangeType = servicesById.getRateCalculation();
		String taxApplicable = servicesById.getTaxApplicable();
		String serviceUnit = servicesById.getServiceUnit();
		double totalPackageDecimal = (double) noOfPackages;
		double rate = 0.0;
		String currencyId = "INR";
		double TaxPercentage = 0.0;
		double billAmount = 0.0;
		double taxamount = 0.0;
		double totalAmount = 0.0;

		if (taxApplicable != null && taxApplicable.equals("Y")) {
			TaxPercentage = Double.parseDouble(servicesById.getTaxPercentage());
		}


//		If rate type is Range or Slab 
		

			List<CFSTariffRange> tariffRanges = CFSTariffRangeService
					.findByCfsTariffNoAndCfsAmndNoAndServiceIdAndPartyId(companyId, branchId, tarrifno, amndno,
							serviceId, partyId);

			if (!tariffRanges.isEmpty()) {
				currencyId = tariffRanges.get(0).getCurrencyId();
			}

			 // Sort the tariffRanges by rangeFrom in ascending order
		    tariffRanges.sort(Comparator.comparingDouble(CFSTariffRange::getRangeFrom));
			for (CFSTariffRange tariffRange : tariffRanges) {
				double rangeFrom = tariffRange.getRangeFrom();
				double rangeTo = tariffRange.getRangeTo();
				double rangeRate = tariffRange.getRangeRate();
				
								
				for (BigDecimal heavy : weights) {
					
					double hpWeightValue = heavy.doubleValue();
									
					
					if (hpWeightValue > rangeFrom && hpWeightValue <= rangeTo) {
						rate = rangeRate;
						
						if (TaxPercentage != 0.0) {
							taxamount = rate * (TaxPercentage / 100.0);
														
							billAmount = rate;				

							totalAmount = billAmount + taxamount;
							
						} else {
							billAmount = rate;
							totalAmount = billAmount;
						}					
						
						break;
					}				

				}	
							
				
			}

		

		InvoiceDetail detail = new InvoiceDetail(companyId, branchId, Invoiceno, partyId, serviceId,invoiceDate,
				serviceUnit, serviceUnit, serviceUnit, rate, currencyId, TaxPercentage, taxamount, billAmount,
				totalAmount, "A", user, new Date(), user, new Date(), user, new Date());

		return detailRepostary.save(detail);
	}
	
	
	
	
	
	
	
	
	
	public List<InvoiceDetail> getByInvoiceNo(String companyId,String branchId,String invoiceNo)
	{
		return detailRepostary.findByCompanyIdAndBranchIdAndInvoiceNO(companyId, branchId, invoiceNo);
	}

}
