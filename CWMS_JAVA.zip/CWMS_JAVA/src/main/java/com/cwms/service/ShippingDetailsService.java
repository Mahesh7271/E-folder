package com.cwms.service;

import com.cwms.entities.ShippingDetails;

public interface ShippingDetailsService {

	public ShippingDetails create(ShippingDetails shippingdetails);
}