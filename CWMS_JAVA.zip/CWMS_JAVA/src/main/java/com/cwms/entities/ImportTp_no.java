package com.cwms.entities;

public class ImportTp_no {

	private String tp_no;

	public ImportTp_no() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ImportTp_no(String tp_no) {
		super();
		this.tp_no = tp_no;
	}

	@Override
	public String toString() {
		return "ImportTp_no [tp_no=" + tp_no + "]";
	}

	public String getTp_no() {
		return tp_no;
	}

	public void setTp_no(String tp_no) {
		this.tp_no = tp_no;
	}
	
	
}
