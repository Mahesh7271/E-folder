public class Q1 
{
	/*	Write a Java program to demonstrate that as a high-priority thread executes,
	 *  it will delay the execution of all lower-priority threads.
	*/
	public static void main(String[] args)
	{
		userThread userThread1 = new userThread(10, 20);
		userThread userThread2 = new userThread(10, 20);
		userThread userThread3 = new userThread(10, 20);
		System.out.println(userThread1.isAlive());
		System.out.println(userThread2.isAlive());
		System.out.println(userThread3.isAlive());
		userThread1.setPriority(Thread.MAX_PRIORITY);
		userThread2.setPriority(Thread.MIN_PRIORITY);
		    userThread1.setPriority(2);
		    userThread1.setName("Mahesh");
	        userThread2.setPriority(5);
	        userThread2.setName("Prtik");
	        userThread3.setPriority(8);
	        userThread3.setName("Abhi");
	         System.out.println("Priority of Thread: " +userThread1.getPriority());
			 System.out.println("Name of Thread: " +userThread1.getName());
			 System.out.println("Priority of Thread: " +userThread2.getPriority());
			 System.out.println("Name of Thread: " +userThread2.getName());
			 System.out.println("Priority of Thread: " +userThread3.getPriority());
			 System.out.println("Name of Thread: " +userThread3.getName());
			 userThread1.start();
			 userThread2.start();
			 userThread3.start();
			 System.out.println(userThread1.isAlive());
			 System.out.println(userThread2.isAlive());
			 System.out.println(userThread3.isAlive());
		}

}
