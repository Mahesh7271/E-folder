public class userThread extends Thread
{
	int n1,n2;

	public userThread(int n1, int n2) 
	{
		this.n1 = n1;
		this.n2 = n2;
	}
		public void run() 
		{
			addtion();
		}
		public void addtion()
		{
			int result = n1+n2;
			System.out.println("result  : "+result);
		}
}
