import java.util.Scanner;

public class AbstractInfo extends Abstract 
{
	int k=0,k1=0,k2=0;
	Scanner sc =new Scanner(System.in);
	Student[] t = new Student[5]; 
	Admin[] admin =new Admin[3];
	@Override
	public void showFirstScreen() 
	{
		do
		{
			System.out.println("=============================================================================================================");
			System.out.println("                              Welcome to Student Manangement System");
			System.out.println("   Tell us who you are : \n1.        Student\n2.          Admin\n3.          Exit");
			System.out.println("=============================================================================================================");
			System.out.println("Enter your choice ( 1 or 2 ) : ");
			Scanner scanner = new Scanner(System.in);
			int op = Integer.parseInt(scanner.nextLine());
			switch(op) {
			case 1:
				showStudentScreen();
				k=1;
				break;
			case 2:
				showAdminScreen();
				k=1;
				break;
			case 3:
				System.out.println( "----------------------------Thank you && Visit Again-------------------------");
				k=0;
				break;
				}
			if(k==1)
			{
			System.out.println("\n\n------------Do you want to continue showFirstScreen press 1--------------");
			k=sc.nextInt();
			}
			} while (1==k);
	}

	@Override
	public void showStudentScreen() 
	{
		do
		{
			System.out.println("========================================================================================================================");
			System.out.println("   1 |<>| for Registration               2 |<>| for Registration any help    ");
			System.out.println("   3 |<>| for Already Registration       4 |<>| for all Courses              ");
			System.out.println("   5 |<>| for Exit / Cancel            ");
			System.out.println("=====================================================================================================================");
			System.out.println("     Enter your choice  : ");
			int choice = sc.nextInt();
			switch (choice) 
			{
			case 1:
				showStudentRegistrationScreen();
				k2=1;
				break;
			case 2:
				System.out.println("======================================================================================================================");
				System.out.println("     Application number (Integer)   ");
				System.out.println("     Name in 10th marksheet  (String)   ");
				System.out.println("     Birth date in (Integer) (e.g ddmmyy)  ");
				System.out.println("=============================================================================================================");
				k2=1;
				break;
				case 3:
				showAllStudentsScreen();
				k2=1;
				break;
			case 4 :
				showAllCoursesScreen();
				break;
			default:
				System.out.println("------------------------------------------Thank You && Visit Again----------------------------------------------");
				k2=0;
				break;
			}
			if(k2==1)
			{
			System.out.println("\n\n-------------------------Do you want to continue showStudentScreen press 1-----------------------------");
			k2=sc.nextInt();
			}
			} while (1==k2);
	}

	@Override
	public void showAdminScreen()
	{
		admin[0]=new Admin("Mahesh Bhonde", 7271);
		admin[1]=new Admin("Prtik", 5555);
		admin[2]=new Admin("Mayuri ", 3333);
		do
		{
			System.out.println("Enter your Admin  passsword");
			int aadminpass=sc.nextInt();
			for (int i = 0 ; i < admin.length ; i++)
			{
				if(admin[i].getAdpass()==aadminpass)
				{
				System.out.println("Password is match @Admin name is    : @"+admin[i].getAdname());
				System.out.println("=========================================Admin Screen===============================================");
				System.out.println("                          1 for all admins         2  for display all student");
				System.out.println("                          3 for all Course         4  for display all student");
				System.out.println("=========================================================================================================");
				System.out.println("          Enter Your choice :" );
				System.out.println("========================================================================================================");
			    int choice = sc.nextInt();
			    switch (choice) 
			    {
				case 1:
					displayAdmins();
					k1=1;
					break;
				case 2:
					showAllStudentsScreen();
					k1=1;
					break;
				case 3:
					showAllCoursesScreen();
					break;
				default:
						System.out.println("------------------------------------Thank you && Visit Again------------------------------------------");
						k1=0;
						break;
				}
			}
		}
			if(k1==1)
			{
				System.out.println("--------------------------------------------------------------------------------------------------------------");
				System.out.println("                           Do you want to continue showAdminScreen press 1");
				System.out.println("--------------------------------------------------------------------------------------------------------------");
				k1=sc.nextInt();
			}
		} while (1==k1);
			
	}
	public void displayAdmins()
		{
			System.out.println("Name: \t\t password ");
			for (int i = 0; i < admin.length; i++) 
			{
				System.out.println(admin[i].getAdname()+"\t"+admin[i].getAdpass());					
			}
		}

	@Override
	public void showAllStudentsScreen()
	{
		Student[] temp = new Student[4];
		temp[0]=new Student(1000, "Mahesh",  (double)120100) ;
		temp[1]=new Student(1001, "partik",  (double)100100) ;
		temp[2]=new Student(1002, "Mayur",   (double)050102) ;
		temp[3]=new Student(1003, "Abhishek",(double)010211) ;
		
		System.out.println("                   all student data to be recorded");
		System.out.println("===================================================================");
		System.out.println("Student Id \tStudent Name\t StudentDate of Birth");
		System.out.println("===================================================================");
		for (Student s : temp)
		{
			System.out.println(s.getId()+"\t\t"+s.getName()+"\t\t\t"+s.getDob());
		}
	}

	@Override
	public void showStudentRegistrationScreen() 
	{
		t[0]=new Student(1000, "Mahesh",(double)120100) ;
		t[1]=new Student(1000, "Mahesh",(double)120100) ;
		t[2]=new Student(1000, "Mahesh",(double)120100) ;
		t[3]=new Student(1000, "Mahesh",(double)120100) ;

		System.out.println("  Enter your Application number (Integer)   ");
		int id =sc.nextInt(); 
		System.out.println("  Enter your Name in 10th marksheet  (String)   ");
		String name = sc.next();
		System.out.println("  Enter your Birth date in (Integer) (e.g ddmmyy)  ");
		double dob = sc.nextDouble();
		t[4]= new Student(id, name, dob);
		System.out.println("=============================================================================================================");
		System.out.println("-----------------------------------Your response has been recorded-------------------------------------------");
		System.out.println("=============================================================================================================");
		System.out.println("Student Id \tStudent Name\t StudentDate of Birth");
		System.out.println(t[4].getId()+"\t\t"+t[4].getName()+"\t\t\t"+t[4].getDob());
			
	}

	@Override
	public void introduceNewCourseScreen() 
	{
		Course[] c = new Course[2];
		c[0]= new Course(1001, "Java Full Stack devlopment", "placement regarding",	15000);
		c[1]= new Course(1002, "         Paython          ", "placement regarding",	15000);
		System.out.println("--------------------------------------------------------------------------------------------------------------");
		System.out.println("                  for  New available course");
		System.out.println("--------------------------------------------------------------------------------------------------------------");
		for (int i = 0; i < c.length; i++) 
		{
			System.out.println("Course id\tcourse name\t\t\tcourse Duration \t\t course fees ");
			System.out.println(c[i].getId()+"\t\t"+c[i].getCoursename()+"\t"+c[i].getDuration()+"\t\t"+c[i].getFees());
		}

		
	}

	@Override
	public void showAllCoursesScreen() 
	{

		Course[] course = new Course[6];
		course[0]= new Course(1001, "Java Full Stack devlopment", "placement regarding",	15000);
		course[1]= new Course(1001, "Html,css,bootstrap,jsript ", "placement regarding",	15000);
		course[2]= new Course(1001, "DBMS,RDBMS,SQL,MANGO DB   ", "placement regarding",	15000);
		course[3]= new Course(1002, "Payton                    ", "placement regarding",	5000);
		course[4]= new Course(1001, "c language                ", "placement regarding",	3000);
		course[5]= new Course(1001, "c++                       ", "placement regarding",	3000);
		System.out.println("--------------------------------------------------------------------------------------------------------------");
		System.out.println("                  for   available All Courses following");
		System.out.println("--------------------------------------------------------------------------------------------------------------");
		for (int i = 0; i < course.length; i++) 
		{
			System.out.println("Course id\tcourse name\t\t\tcourse Duration \t\t course fees ");
			System.out.println(course[i].getId()+"\t\t"+course[i].getCoursename()+"\t"+course[i].getDuration()+"\t\t"+course[i].getFees());
		}

		
	}

}
