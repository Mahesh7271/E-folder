import java.util.Scanner;

public class Abstract 
{
	public void showFirstScreen()
	{
	
	}
	public void showFirstScreen1()
	{
	
	}
	public void showStudentScreen()
	{
		
	}
	public void showAdminScreen()
	{
		
	}
	public void showAllStudentsScreen()
	{
		
	}
	public void showStudentRegistrationScreen() // Execute the register method of AppEngine class
	{
		
	}
	public void introduceNewCourseScreen()
	{
		
	}
	public void showAllCoursesScreen()
	{
		
	}

}

