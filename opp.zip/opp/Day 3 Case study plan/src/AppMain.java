
public class AppMain 
{
	public static void main(String[] args) 
	{
		AbstractInfo info = new AbstractInfo();
		info.showFirstScreen();
	}
}
