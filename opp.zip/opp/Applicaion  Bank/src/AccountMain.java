import java.util.Scanner;

public class AccountMain
{

	public static void main(String[] args)
	{
		Account acc =new Account(1001,"mahesh",220000);
		Account accd =new Account(1001,"mahesh",220000);
		System.out.println(acc);		
		 acc=null;
		Account acc2=null;
		Account acc3=null;
		System.gc();
	}

	
}
