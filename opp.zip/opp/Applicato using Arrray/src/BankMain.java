import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;
public class BankMain 
{
    private static double amount;
    private static ArrayList<Account> accountList = new ArrayList<>();
    private static Account selectedAccount;
    private static boolean flag = false;
    public static void main(String[] args)
    {
        Scanner scan = new Scanner(System.in);// Menu starts 
        Scanner input = new Scanner(System.in);
        System.out.println("Enter option for the operation ");
        System.out.println("************************************************************");
        System.out.print("[ Options :                                                  ]\n"
        		        +"[ new Or 1:- New Account         del Or 3:- Delete Account   ]\n"
        		        +"[  dp Or 4:- Deposit              wi Or 5:- Withdraw         ]\n"
        		        +"[ bal Or 6:- Check balance                                   ]\n"
        		        +"[      se Or 2:- Select Account  exit Or 7:- Quit            ]\n");
        System.out.println("************************************************************");
        Account account = null;
        while (true) {
            System.out.println("> ");//for user input
            String choice = input.next();// Options
            switch (choice) 
            {
                    case "1"  :
                    case "new":
                    // Create new account
                    int accNo = 0;
                    int bal = 0;
                    System.out.println("Enter account number : ");
                    accNo = input.nextInt();
                    System.out.println("Enter initial balance: ");
                    bal = input.nextInt();
                    System.out.println("Current account: " + accNo + " "
                        + "Balance " + bal);
                    account = new Account(bal, accNo);
                    accountList.add(account);
                    break;
                case "2"  :      
                case "se":
                    // select account
                    System.out
                        .println("Enter account number for further operations : ");
                    int selectedAcc = scan.nextInt();
                    System.out.println("Selected account : " + selectedAcc);
                    for (Object object : accountList) {
                        selectedAccount = (Account) object;
                        if (selectedAccount.getAccNumber() == selectedAcc) {
                            flag = true;
                            break;
                        } else {
                            flag = false;
                        }
                    }
                    if (!flag) {
                        System.out.println("Account doesn't exists.");
                    }
                    if (accountList.size() == 0) {
                        System.out.println("Zero account exists.");
                    }
                    break;
                case "3"  :
                case "del":
                    // close account
                    System.out
                        .println("Enter account number for further operations : ");
                    int selectedAcc1 = scan.nextInt();
                    System.out.println("Selected account : " + selectedAcc1);
                    Iterator<Account> iterator = accountList.iterator();
                    while (iterator.hasNext()) {
                        selectedAccount = (Account) iterator.next();
                        if (selectedAccount.getAccNumber() == selectedAcc1) {
                            iterator.remove();
                            flag = true;
                            break;
                        }
                    }
                    if (!flag) {
                        System.out.println("Account doesn't exists.");
                    }
                    System.out.println("Account " + selectedAcc1 + " closed.");
                    break;
                case "4":
                case "dp":
                    // Deposit amount
                    System.out.println("Enter amount to deposit :  ");
                    amount = scan.nextDouble();
                    if (amount <= 0) {
                        System.out
                            .println("You must deposit an amount greater than 0.");
                    } else {
                        if (flag) {
                            selectedAccount.deposit(amount);
                            System.out.println("You have deposited " + amount
                                + ". Total balance : "
                                + (selectedAccount.getBalance()));
                        } else {
                            System.out.println("Please select account number.");
                        }
                    }
                    break;
                case "5":
                case "wi":
                    // Withdraw amount
                    System.out.println("Enter amount to be withdrawn: ");
                    amount = scan.nextDouble();
                    if (amount > account.getBalance() && amount <= 0) {
                        System.out.println("You can't withdraw that amount!");
                    } else if (amount <= selectedAccount.getBalance()) {
                        if (flag) {
                            selectedAccount.withdraw(amount);
                            System.out.println("You have withdraw : " + amount
                                + " NewBalance : "
                                + selectedAccount.getBalance());
                        } else {
                            System.out.println("Please select account number.");
                        }
                    }
                    break;
                case "6":    
                case "bal":
                    // check balance in selected account
                    if (flag) {
                        System.out.println("Your current account balance : "
                            + selectedAccount.getBalance());
                    } else {
                        System.out.println("Please select account number.");
                    }
                    break;
                case "7":
                case "exit":
                default:
                    System.out.println("Thank You. Visit Again!");
                    flag = false;
                    input.close();
                    scan.close();
                    System.exit(0);
                    break;
            }
            }
        }
    }