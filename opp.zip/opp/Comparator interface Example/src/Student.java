public class Student 
{
	int Rollnumber;
	String Name,Address;
	public Student(int rollnumber, String name, String address)
	{
		Rollnumber = rollnumber;
		Name = name;
		Address = address;
	}
	@Override
	public String toString() {
		System.out.println("---------------------------------------------------------------------");
		return "Roll Number =\t" + Rollnumber + "\tName =\t" + Name ;
	}
	
}
