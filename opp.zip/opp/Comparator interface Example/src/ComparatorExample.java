import java.util.ArrayList;

import java.util.Collections;

public class ComparatorExample {

	public static void main(String[] args) {
		ArrayList<Student> ar = new ArrayList<>();
		ar.add(new Student(100 , "Mahesh" , "Dighi pune"));
		ar.add(new Student(1   , "Swati"  , "Dighi pune"));
		ar.add(new Student(99  , "ABA"   , "Dighi pune"));
		ar.add(new Student(15  , "Adhitya", "Dighi pune"));
		System.out.println("======================================================================");
		System.out.println("Unorder List .....");

		for (int i = 0; i < ar.size(); i++) 
			System.out.println(ar.get(i));
		Collections.sort(ar,new SortbyRoll());
		System.out.println("======================================================================");
		System.out.println("order List By Roll Number .....");
		for (int i = 0; i < ar.size(); i++) 
			System.out.println(ar.get(i));
		Collections.sort(ar,new SortByName());
		System.out.println("======================================================================");
		System.out.println("order List By Name .....");
		for (int i = 0; i < ar.size(); i++)
			System.out.println(ar.get(i));
	}
}
