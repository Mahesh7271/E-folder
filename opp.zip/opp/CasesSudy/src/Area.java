import java.util.Scanner;

public class Area
{

//	public void area(float r )
	//{
		//float area = (float) (3.14*r*r);
		//System.out.println("\n area of circle is :"+area);
	//}
	public  void rectangle(float h,float b)
	{
		float area = (float) (0.5*h*b);
		System.out.println("\n area of trangle is :"+area);

	}
}
