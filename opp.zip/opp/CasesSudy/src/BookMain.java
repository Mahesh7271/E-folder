
public class BookMain 
{
public static void main(String[] args)
{
Bookinfo b = new Bookinfo();
Book[] book1 =b.create();
b.Display(book1);
}
}
