import java.util.Scanner;

public class Q5 
{
	public static void main(String[] args)
	{
		Scanner scanner =new Scanner(System.in);
		System.out.println("Enter your any two Number to Check Greterthan or lessthan ");
		int val1=scanner.nextInt();
		int val2= scanner.nextInt();
		try 
		{
			if (val1==0 || val2==0 )
				throw new valueException(val1, val2);
			else
				System.out.println("Valied value is for Arithmetic operation");
		}
		catch (valueException e)
		{
		System.out.println(e);
		if (val1==0)
		{
			System.out.println("re_enter you First value"+val1);
			val1= scanner.nextInt();
		}
		if (val2==0)
		{
			System.out.println("re_enter you second value"+val2);
			 val2= scanner.nextInt();
		}
				}
		USERTRAIL usertrail = new USERTRAIL(val1, val2);
		usertrail.greterThan();
	}
}
