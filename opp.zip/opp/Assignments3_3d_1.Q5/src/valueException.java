
public class valueException extends Exception 
{
    int i;
    int j;
	public valueException(int i, int j)
	{
		this.i = i;
		this.j = j;
	}
	@Override
	public String toString() {
		return "valueException [value a is =" + i + ", Value b is =" + j + "]";
	}
	
}
