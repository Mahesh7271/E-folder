
public class USERTRAIL
{
	/*	Create a class USERTRAIL with following specifications.
	 *	 val1, val2 type    int
	 * 		Methods
	   	
     *	boolean show () will check if val1 and val2 are greater or less than Zero
	 *  have constructor which will val1, val2 and check whether 
	 *  if it is less than 0  then raise a custom Exception (name: Illegal value exception.)
	
	*/
	int val1;
	int val2;

	public USERTRAIL(int val1, int val2) 
	{
		this.val1 = val1;
		this.val2 = val2;
	}
	public void greterThan()
	{
		if (val1>val2)
			System.out.println("value a : "+val1+" is greterthan b : "+val2);
		else 
			System.out.println("value a : "+val2+" is greterthan b : "+val1);
			
	}


}
