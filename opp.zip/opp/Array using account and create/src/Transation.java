import java.util.Scanner;

public class Transation 
{
	Scanner sc =new Scanner(System.in);
	public void Transation(Account arr[] , double amo,int ano)
	{
		System.out.println("1 : Withdrow The Balance : \n"
						  +"2 : Deposit The Balance  : ");
		int ch=sc.nextInt();
		if(ch==1)
		{
			Withdrow(arr,amo,ano);
		}
		else 
		{
			deposit(arr, amo, ano);
		}
	}
	public void Withdrow( Account arr[] , double amo,int accountno )
	{
		for (Account acc : arr) 
		{
				if (acc.getAccno()==accountno)
				{
					acc.setAccbal(acc.getAccbal()-amo);
				}
		}
	}
	public void deposit( Account arr[] , double amo,int accountno )
	{
		for (Account acc : arr) 
		{
				if (acc.getAccno()==accountno)
				{
					acc.setAccbal(acc.getAccbal()+amo);
				}
		}
	}
}
