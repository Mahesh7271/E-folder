import java.util.Scanner;
public class AccountMain 
{
	public static void main(String[] args) 
	{
		int flag=0;
		Transation tr =new Transation();
		AccountInfo ainfo = new AccountInfo();
		Account arr[] = null;
		Scanner sc = new Scanner(System.in);
		do {
  			 System.out.println("------------------------------------------------------");
	   		 System.out.println(" Press create     [Or]  1 :- Create Account          "
				           	  + "\n Press display    [Or]  2 :- Display Account       "
				           	  + "\n Press serach     [Or]  3 :- search Account        "
				           	  + "\n Press delete     [Or]  4 :- Deleted Account       "
				           	  + "\n Press tran       [Or]  5 :- Transation Amonunt    "
				           	  + "\n Press exit       [Or]  6 :- Exit to be Sub Menu   ");
			System.out.println("------------------------------------------------------");
			System.out.println("    Enter Your choice :" );
			String ch = sc.next();
			switch (ch) 
			{
		case "1":
		case "create":
				arr=ainfo.Create();
				flag=1;
				break;
		case "2":
		case "display":	
			if(flag==1)
				ainfo.Display(arr);
			else
				System.out.println("Create Account Firstly");
				break;
		case "3":
		case "sarach":
			if(flag==1)
			{
				System.out.println("Enter Account number to be search");
				int ano= sc.nextInt();
				ainfo.search(arr,ano);
			}
				else
				System.out.println("Create Account Firstly");
			
				break;
		case "4":
		case "delete":
			if(flag==1)
			{
			System.out.println("Enter Account number to be Deleted");
			int ano1= sc.nextInt();
			arr=ainfo.delete(arr,ano1);
			System.out.println("Account Are Deleted : Account Number"+ano1);
			ainfo.Display(arr);
			}
			else
			System.out.println("Create Account Firstly");
			break;
		case "5":
		case "tran":
			if(flag==1)
			{
			System.out.println("Enter Account number to be transation");
			int an = sc.nextInt();
			System.out.println("Enter Amount to be transation");
			double amount= sc.nextDouble();			
			tr.Transation(arr,amount,an);
			}
			else
				System.out.println("Create Account Firstly");
			break;
		case "6"   :
		case "exit":	
		default    :
			System.out.println("------------------Invalied Choice------------------");
				break;
			}
			System.out.println("---------------------------------------------------");
			System.out.println("          Do you want continue : 1 ");
			System.out.println("---------------------------------------------------");
		} while (1==sc.nextInt());			
	}
}
	