import java.util.Scanner;

public class AccountInfo 
{
	Scanner sc = new Scanner(System.in);
	public Account[] Create()
	{
		System.out.println("Haw many account do you want");
		int n=sc.nextInt();
		Account[] acc = new Account[n]; 
		for (int i = 0; i < acc.length; i++)
		{
			System.out.println(" Enter Account number :  "
							 +"  Account Type         :"
			           		  +" Acccount Balance     :");
			acc[i]=new Account(sc.nextInt(), sc.next(), sc.nextDouble());
		}
		return acc;
	}
	public void Display(Account[] acc)
	{
		System.out.println(":Account Number:\t:Account Type:\t:Account Balance:");
		for (Account a : acc)
		{
			System.out.println(a.getAccno()+"\t"+a.getAcctype()+"\t"+a.getAccbal());
		}
	}
	public Account[] delete(Account[] acc,int n)
	{
		int i=0;
		Account[] temp = new Account[acc.length-1];
		for (Account a : acc) 
		{
			if (n!=a.getAccno())
			{
			temp[i]=a;
			i++;
			}
		}
		return temp;
	}
	public void search(Account[] arr , int ano)
	{
		boolean b=false;
		Account temp =null;
		for (Account acc : arr) 
		{
			if (acc.getAccno()==ano)
			{
			temp=acc;
			b=true;
			}
		}
	}
}

