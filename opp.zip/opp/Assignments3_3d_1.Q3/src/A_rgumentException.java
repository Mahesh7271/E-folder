
public class A_rgumentException extends Exception
{
	@Override
	public String toString() 
	{
		return "negative balance is not allowed";
	}
	
}
