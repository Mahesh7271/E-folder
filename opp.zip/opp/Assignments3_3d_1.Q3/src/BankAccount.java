
public class BankAccount 
{
	int accNo;
	String custName;
	boolean accType;//if enter true =saving or falues = current
	float accBalance;
	public static int low_saving=1000;
	public static int low_current=5000;
	public BankAccount(int accNo, String custName, boolean accType, float accBalance) throws Lowbalanceexception ,A_rgumentException
	{
		try
		{
			if (accBalance<0)
			throw new A_rgumentException();	
		}
		catch (A_rgumentException le) 
		{
			System.out.println(le);
		}
		try 
		{
			if (accType)
			{
				if (accBalance<=low_saving)
					throw new Lowbalanceexception();
			}
			else 
			{
				if (accBalance<=low_current)
					throw new Lowbalanceexception();
			}
			
		}
		catch (Lowbalanceexception le) 
		{
			System.out.println(le);
		}
		this.accNo = accNo;
		this.custName = custName;
		this.accType = accType;
		this.accBalance = accBalance;
	}
	public int getAccNo() 
	{
		return accNo;
	}
	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public boolean isAccType() {
		return accType;
	}
	public void setAccType(boolean accType) {
		this.accType = accType;
	}
	public float getAccBalance() {
		return accBalance;
	}
	public void setAccBalance(float accBalance) {
		this.accBalance = accBalance;
	}
	
	public float Deposit(float amount) throws A_rgumentException
	{
		try 
		{
			if (amount==0 || amount < 0) 
				throw new A_rgumentException();
		} 
		catch (A_rgumentException le)
		{
		System.out.println(le);
		}
		accBalance +=amount; 
		System.out.println("your balance are incerment"+accBalance);
	return accBalance;	
	}
	
	public float Withdrow(float Amount)throws Lowbalanceexception , A_rgumentException
	{
		try
		{
			if (Amount!=0) 
				throw new A_rgumentException();
		}
		catch(A_rgumentException al)
		{
			System.out.println(al);
		}
		accBalance=accBalance-Amount;
		System.out.println("Remeaning Value");
		try 
		{
			if (accBalance<0)
				throw new Lowbalanceexception();	
			
		}
		catch (Lowbalanceexception le)
		{
		System.out.println(le);
		}
		if (accType)
		{
			try 
			{
				if (accBalance<=low_saving)
					throw new Lowbalanceexception();
			}
			catch (Lowbalanceexception le) 
			{
				System.out.println(le);
			}
		}
			else 
		{
				try 
				{
					if (accBalance<=low_current)
						throw new Lowbalanceexception();
				}
				catch (Lowbalanceexception le) 
				{
					System.out.println(le);
				}
		}
		return accBalance;
	}
	
	
}
