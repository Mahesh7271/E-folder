
public class Lowbalanceexception extends Exception
{

	@Override
	public String toString() 
	{
		return "low Balance Exception ";
	}
	
}
