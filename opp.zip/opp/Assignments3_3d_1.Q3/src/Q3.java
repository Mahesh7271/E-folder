import java.util.Scanner;

public class Q3 
{

	public static void main(String[] args) throws Lowbalanceexception, A_rgumentException 
	{
			Scanner scanner = new Scanner(System.in);
			System.out.println("Enter your Account Number");
			int accno= scanner.nextInt();
			System.out.println("Enter Your Name");
			String name = scanner.next();
			System.out.println("true for saving  : false for current");
			boolean accType = scanner.nextBoolean();
			System.out.println("Enter Account Balance");
			float accBalance = scanner.nextFloat();
			BankAccount bankAccount= new BankAccount(accno, name, accType, accBalance);
			do 
			{
			System.out.println( "1.   Withdrow Amount"
							  + "2.   Deposit  Amount"
							  + "3.   Exit");
			int choice = scanner.nextInt();
			System.out.println("Enter your Amount");
			float Amount = scanner.nextFloat();
			if(choice==1)
			{
				bankAccount.Withdrow(Amount);
			}
			if  (choice==2)
			{
				bankAccount.Deposit(Amount);
			}
			System.out.println("----------------------Your Transaction Sucessfully---------------------- ");
		} while (scanner.nextInt()==1);
			System.out.println("----------------------Thank you  &&  Visit Again---------------------- ");
	}
}