public class div extends Result
{
	@Override
	public void display(int x, int y) 
	{
		int div = x/y;
		System.out.println("Division of two number  :"+div);
	}
	
}
