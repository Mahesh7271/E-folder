public class Add extends Result
{

	@Override
	public void display(int x, int y) 
	{
	int add = x+y;
	System.out.println("Addtion of two number is  : "+add);
	}

}
 