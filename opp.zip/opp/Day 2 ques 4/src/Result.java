
public class Result 
{
	public void display(int x,int y)
	{
		
	}
}
