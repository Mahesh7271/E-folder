public class mul extends Result
{
	@Override
	public void display(int x, int y) 
	{
		int mul = x*y;
		System.out.println("Multilplication of two number is :"+mul);
	}
	
}
