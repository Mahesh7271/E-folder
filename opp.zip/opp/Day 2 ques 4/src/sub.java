public class sub extends Result
{

	@Override
	public void display(int x, int y) 
	{
		int sub = x-y;
		System.out.println("Subtraction of two number :"+sub);
	}
	
}
