import java.util.Scanner;
public class Resultmain 
{
	public static void main(String[] args) 
	{
		Result r[] = new Result[4] ;
		Scanner sc = new Scanner(System.in);
		do
		{
			System.out.println("Enter your two Numbers ");
			int x =sc.nextInt();
			int y =sc.nextInt();
			System.out.println("Enter Your Operator  Like (+,-,*,/)");
			String ch = sc.next();
			r[0] = new Add();
			r[1] = new sub();
			r[2] = new mul();
			r[3] = new div();
			switch (ch)
			{
			case "+":
				
				r[0].display(x, y);
				break;
			case "-":
				r[1].display(x, y);
				break;
			case "*":
				r[3].display(x, y);
				break;
			case "/":
				r[4].display(x, y);
				break;
			default :
				System.out.println("Please Enter '+' , '-' , '*' , '/' Operater only... ");
				break;
			}
		} while (1==1);
	}
}
