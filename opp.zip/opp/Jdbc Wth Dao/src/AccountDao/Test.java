package AccountDao;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import org.w3c.dom.stylesheets.LinkStyle;

import Admininfo.AdminInfo;
import UserDao.UserInfo;

public class Test {
	public static void main(String[] args) 
	{
		Scanner scanner = new Scanner(System.in);
		AccountInfo accountInfo= new AccountInfo();
		UserDao.UserInfo userInfo = new UserInfo();
		AdminInfo  adminInfo = new AdminInfo();
		do {
			System.out.println("Who are you");
			System.out.println("1 - Admin"
							 + "\n2 - New User"
							 + "\n3 - Regular User"
							 + "\n4 - Exit");
			int choice = scanner.nextInt();
			switch (choice) {
			case 1:
				userInfo.AdminScreen();
				break;
			case 2:
				userInfo.UserScreen();
				break;
			case 3:
				userInfo.regularScreen();
				break;
			case 4:
				break;
			}
			System.out.println("\tThanks Your Visiting ...... ");
			System.out.println("Do you want to continue press 1  System Screen");
		} while (scanner.nextInt()==1);
	}
}
