package AccountDao;

public class Account {

	private int acc_No;
	private String acc_Name;
	private double acc_Balance;
	
	public Account(int acc_No, String acc_Name, double acc_Balance) {
		super();
		this.acc_No = acc_No;
		this.acc_Name = acc_Name;
		this.acc_Balance = acc_Balance;
	}
	public int getAcc_No() {
		return acc_No;
	}
	public void setAcc_No(int acc_No) {
		this.acc_No = acc_No;
	}
	public String getAcc_Name() {
		return acc_Name;
	}
	public void setAcc_Name(String acc_Name) {
		this.acc_Name = acc_Name;
	}
	public double getAcc_Balance() {
		return acc_Balance;
	}
	public void setAcc_Balance(double acc_Balance) {
		this.acc_Balance = acc_Balance;
	}
	
}
