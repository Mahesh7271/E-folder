package AccountDao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import DatabaseDao.AccountDao;
import DatabaseDao.Myconnection;
public class AccountInfo 
{
	AccountDao AD =new AccountDao();
	Scanner  scanner = new  Scanner(System.in);
	List<Account> accountlist = new ArrayList<Account>();
	Connection  connection= Myconnection.GetDatabaseConncetion(); 
			
	public void CreateAccount() throws SQLException
	{
		System.out.println("Enter Account Number ,Name And Balance");
		Account account = new Account(scanner.nextInt(),scanner.next(), scanner.nextDouble());
		accountlist.add(account);
		AD.insertData(accountlist);
	}
	public void DisplayData(Account account) 
	{
		System.out.println("Account ID       :"+account.getAcc_No());
		System.out.println("Account Pass     :"+account.getAcc_No());
		System.out.println("Account F_Name   :"+account.getAcc_Name());
		System.out.println("Account Balance  :"+account.getAcc_Balance());
	}
	public void SearchAccount( ) 
	{
		System.out.println("Enter Your Account ID to Search Your Account");
		int A_ID=scanner.nextInt();
		Account account= AD.retriveData(accountlist, A_ID);
		DisplayData(account);
	}
	public void  DisplayAllAccount()
	{
		
	}
}
