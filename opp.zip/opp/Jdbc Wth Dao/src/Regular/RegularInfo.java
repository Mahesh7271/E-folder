package Regular;

import java.sql.Connection;
import java.util.Scanner;

import AccountDao.Account;

public class RegularInfo 
{
	RegularDoa RD = new RegularDoa();
	Scanner scanner = new Scanner(System.in);
	public void  WithdrowAmount()
	{
		Account account = null;
		System.out.println("Enter Your Account ID ");
		int A_ID = scanner.nextInt();
		account =RD.retriveAccount(A_ID);
		System.out.println("Enter Your Amount To be Withdrow");
		double Amount =  scanner.nextDouble();
		double Account_Balance = account.getAcc_Balance();
		account.setAcc_Balance(Account_Balance-Amount);
		//RD.Upadate(account);
	}
}
