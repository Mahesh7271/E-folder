package Regular;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import AccountDao.Account;
import DatabaseDao.Myconnection;
public class RegularDoa {
	Connection connection = Myconnection.GetDatabaseConncetion();
	
	public Account retriveAccount(int A_ID) 
	{
		Account account = null;
		try 
		{
			PreparedStatement PStatement1 = connection.prepareStatement("select * from Batch1Bank where ID = ?");
			PStatement1.setInt(1,A_ID);
			ResultSet rs =PStatement1.executeQuery();
			rs.next();
			account = new Account(rs.getInt(1),rs.getString(2),rs.getFloat(3));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return account;
	}
/*	public void	 Upadate(Account account)
	{
		try {
			PreparedStatement PState1 = connection.prepareStatement("update Batch1Bank set Balance=? where ID =?");
			System.out.println("Enter your Account Number To Upadte FName & LName ");
			PState1.setInt(3, account.getAcc_No());
			PState1.setDouble(1,account.getAcc_Balance());
			int i3 =PState1.executeUpdate();
			if (i3>0) 
				System.out.println("Record Updated...");
			 else
				 System.out.println("Record Not Updated...");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
	}*/
}
