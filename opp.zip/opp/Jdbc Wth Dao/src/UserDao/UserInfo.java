package UserDao;
import java.util.Scanner;
	import AccountDao.AccountInfo;
import Admininfo.AdminInfo;
import Regular.RegularDoa;
import Regular.RegularInfo;

public class UserInfo
{
	Scanner scanner = new Scanner(System.in);
	AccountInfo accountInfo= new AccountInfo();
	AdminInfo  adminInfo = new AdminInfo();
	public void AdminScreen()
	{
		System.out.println("Welcome to MDFC Bank in Pune");
		System.out.println("1 - Create New Admin"
						 + "2 - Display All Admin"
						 + "3 - Search Any Account in Bank"
						 + "4 - Exit");
		int choice = scanner.nextInt();
		switch (choice) {
		case 1:
			adminInfo.CreateAdmin();
			break;
		case 2:
			adminInfo.DisplayAllAdmin();
			break;
		case 3:
			accountInfo.SearchAccount();
			break;
		default:
			break;
		}
	
	}
	public void UserScreen()
	{
		System.out.println("Welcome to MDFC Bank in Pune  |User Screen|");
		System.out.println("1 - Create Account"
						 + "2 - Change Your Account Passowrd"
						 + "3 - Change Your Mobile Number"
						 + "4 - Exit");
		int choice = scanner.nextInt();
		switch (choice) {
		case 1:
			
			break;
		case 2:
			break;
		case 3:
			break;
		default:
			break;
		}
	}
	public void regularScreen()
	{
		RegularInfo regularInfo = new RegularInfo();
		System.out.println("Welcome to MDFC Bank in Pune |Regular User Screen|");
		System.out.println("1 - Withdrow Amount "
						 + "2 - Deposit  Amount "
						 + "3 - Change A Password"
						 + "4 - Change Mobile Number"
						 + "5 - Exit");
		int choice = scanner.nextInt();
		switch (choice) {
		case 1:
			regularInfo.WithdrowAmount();
			break;
		case 2:
			break;
		case 3:
			break;
		default:
			break;
		}
		
	}
}
