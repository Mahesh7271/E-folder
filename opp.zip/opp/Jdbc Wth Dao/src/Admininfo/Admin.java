 package Admininfo;


public class Admin 
{
	private int Admin_Id;
	private int Admin_pass;
	private String Admin_F_Name;
	private String Admin_L_Name;
	public Admin(int admin_Id, int admin_pass, String admin_F_Name, String admin_L_Name) {
		super();
		Admin_Id = admin_Id;
		Admin_pass = admin_pass;
		Admin_F_Name = admin_F_Name;
		Admin_L_Name = admin_L_Name;
	}
	public int getAdmin_Id() {
		return Admin_Id;
	}
	public void setAdmin_Id(int admin_Id) {
		Admin_Id = admin_Id;
	}
	public int getAdmin_pass() {
		return Admin_pass;
	}
	public void setAdmin_pass(int admin_pass) {
		Admin_pass = admin_pass;
	}
	public String getAdmin_F_Name() {
		return Admin_F_Name;
	}
	public void setAdmin_F_Name(String admin_F_Name) {
		Admin_F_Name = admin_F_Name;
	}
	public String getAdmin_L_Name() {
		return Admin_L_Name;
	}
	public void setAdmin_L_Name(String admin_L_Name) {
		Admin_L_Name = admin_L_Name;
	}
	
}
