package Admininfo;

import java.awt.Adjustable;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import AccountDao.Account;

public class AdminInfo 
{
	AdminDao AD = new AdminDao();
	Scanner scanner = new Scanner(System.in);
	List<Admin> Adminlist = new ArrayList<Admin>();
	public void  CreateAdmin() 
	{
		System.out.println("Enter Admin ID\tPass\tFirst Name\tLast_Name");
		Admin admin = new Admin(scanner.nextInt(), scanner.nextInt(),scanner.next(), scanner.next()); 
		Adminlist.add(admin);
		AD.InsertData(Adminlist);
	
	}
	public void  ModifyAdmin() 
	{
		System.out.println("Enter your Id or Password");
		int ID = scanner.nextInt();
		int pass = scanner.nextInt();
		
		
		
	}
	public void  DisplayAllAdmin() 
	{
		
	}
}
