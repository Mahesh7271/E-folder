package Admininfo;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import AccountDao.Account;
import DatabaseDao.Myconnection;

public class AdminDao 
{
	public void InsertData(List<Admin> adminlist)
	{
		Admin admin =adminlist.get(0);
		int i;
		try {
			Connection connection = Myconnection.GetDatabaseConncetion(); 
			PreparedStatement preparedStatement = connection.prepareStatement("insert into Batch1Admin values(?,?,?,?)"); 
			preparedStatement.setInt(1, admin.getAdmin_Id());
			preparedStatement.setInt(2, admin.getAdmin_pass());
			preparedStatement.setString(3, admin.getAdmin_F_Name());
			preparedStatement.setString(4, admin.getAdmin_L_Name());
			 i = preparedStatement.executeUpdate();
			if (i>0)
				System.out.println(" 1 more record inserted in Admin Database");
			else
			System.out.println(" NO record inserted in Database");

		} catch (SQLException e) {
			e.printStackTrace();
		}	
	}
}
