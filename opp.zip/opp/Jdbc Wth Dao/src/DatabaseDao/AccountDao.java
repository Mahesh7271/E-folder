package DatabaseDao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;
import AccountDao.Account;
public class AccountDao
{
	Scanner scanner = new Scanner(System.in);
	Connection connection = Myconnection.GetDatabaseConncetion(); 
	public void insertData(List<Account> account) throws SQLException
	{
		Account acc =account.get(0);
		PreparedStatement preparedStatement = connection.prepareStatement("insert into Batch1Bank values(?,?,?)"); 
		preparedStatement.setInt(1, acc.getAcc_No());
		preparedStatement.setString(2, acc.getAcc_Name());
		preparedStatement.setDouble(3, acc.getAcc_Balance());
		int i=preparedStatement.executeUpdate();
		if (i>0)
			System.out.println(" 1 more record inserted in Database");
		else
		System.out.println(" NO record inserted in Database");
	}
	public Account retriveData( List<Account> list,int A_ID)
	{
		Account account= null;
		try {
			PreparedStatement PStatement1 = connection.prepareStatement("select * from Batch1Bank where ID = ?");
			PStatement1.setInt(1,A_ID);
			ResultSet rs =PStatement1.executeQuery();
			rs.next();
			account = new Account(rs.getInt(1),rs.getString(2),rs.getFloat(3));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return account;
	}
	
}
