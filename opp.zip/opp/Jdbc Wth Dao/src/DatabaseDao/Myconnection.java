package DatabaseDao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Myconnection {

	public static  Connection  GetDatabaseConncetion() 
	{
		Connection connection = null;
		try 
		{
			Class.forName("oracle.jdbc.OracleDriver");
		 connection =DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","system");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return  connection;
	}
}
