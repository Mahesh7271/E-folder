public class BookMain {
	public static void main(String[] args) {
		
		BookInfo binfo=new BookInfo();
		Book book1[]=binfo.create();
		binfo.display(book1);
		
		
	}
}