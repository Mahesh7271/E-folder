
public class StudentMain {
	public static void main(String[] args) {
		StudentInfo studinfo = new StudentInfo();
	Student[]	stud = studinfo.create();
		studinfo.display(stud);
	}
}
