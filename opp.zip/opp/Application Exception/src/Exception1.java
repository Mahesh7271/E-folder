public class Exception1 
{
	public static void main(String[] args) 
	{
		try
			{
				int n1 = Integer.parseInt(args [0]);
				int n2 = Integer.parseInt(args [1]);
				int ans=n1/n2;
				System.out.println("Ans is :"+ans);
				System.out.println("print me.....");
			} 
		catch (ArithmeticException|ArrayIndexOutOfBoundsException e)
			{
				System.out.println("Exception is....."+e);
				System.out.println("print me.....");
			}
		finally 
			{
				System.out.println("print me.....");
				System.out.println(java.time.LocalDateTime.now());
			}
		}
}