


import java.util.Scanner;
public class CustomException
{
	public static void main(String[] args) 
	{
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter your name");
		String name = scanner.next();
		System.out.println("Enter your Age");
		int age= scanner.nextInt();
		try
		{
			if (age<18)
			{
				throw new InvaliedAgeException(age);
			}
			System.out.println("Valied Data.....");
		} 
		catch (InvaliedAgeException e)
		{
			System.out.println(e);	
		}

	}

}
