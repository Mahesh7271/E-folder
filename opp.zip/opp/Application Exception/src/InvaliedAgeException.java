public class InvaliedAgeException extends Exception
{
	private int age;
	public InvaliedAgeException(int age) 
	{
		this.age = age;
	}
	@Override
	public String toString() 
	{
		return "Invalied Age Exception : Your age " + age ;
	}
}