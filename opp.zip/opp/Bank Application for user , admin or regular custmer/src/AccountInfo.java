import java.util.Random;
import java.util.Scanner;

import javax.swing.text.AbstractDocument.LeafElement;
public class AccountInfo 
{
Scanner sc =new Scanner(System.in);
//========================================create a custmer============================================
	public Account[] createAccount()
	{
		System.out.println("How many account do want to you create");
		int n=sc.nextInt();
		Account[] acc = new Account[n];
		for (int i = 0; i < acc.length; i++) 
			{
			System.out.println("=====================Custmer Detailes==========================");
			System.out.println("Custmer Name (only capital)      :");
			String name=sc.next();
			System.out.println("Custmer Mobile number(10 digits) :");
			String phoneno = sc.next();
			System.out.println("Custmer Adhar number (12 digits) :");
			String adharno = sc.next();
			Custmer cust = new Custmer(name, phoneno, adharno);
			
			System.out.println("=====================Custmer Address===========================");
			System.out.println("Custmer place (current)         :");
			String place = sc.next(); 
			System.out.println("Custmer city  (current)         :");
			String city = sc.next();
			System.out.println("Custmer Pincode(ex-> 413702 like):");
			int pin = sc.nextInt();
			custadd cadd = new  custadd(place, city, "maharashtra", pin);
			
			bankAddress badd = new bankAddress("R And D E Dighi ","Alandi Road pune", "maharashtra",411015);
					
			System.out.println("=====================Account Detailes==========================");
			int accno=Accountno();	 
			System.out.println("Custmer Account Type       : ");
			String acctype = sc.next();
			System.out.println("Custmer Balance (deposit amount):");
			double amo = sc.nextDouble();
			acc[i] =new Account(accno, acctype , amo , 1234 , cust , cadd , badd );
			}
	return acc;
	}
//==========================================display user===========================================
	public void display(Account[] a)
	{
		for (int i = 0; i < a.length; i++) 
		{
			System.out.print  ("\n========================Account Details====================================");
			System.out.println("\n  Custmer Account number      : "+a[i].getAccountno()
					         + "\n  Custmer Account Type        : "+a[i].getAccType()
					         + "\n  Custmer Balance in (Rupess) : "+a[i].getBalance()
					         + "\n========================Custmer Details===================================="
					         + "\n  Custmer Name in (capital)   : "+a[i].getCustmer().getName()
					         + "\n  Custmer Mobile number (+91) : "+a[i].getCustmer().getPhoneno()                   
					         + "\n  Custmer Adhar number        : "+a[i].getCustmer().getAdharno()
					         + "\n========================Address Details===================================="
					         + "\n  Custmer city      (current) : "+a[i].getCadd().getCity()
					         + "\n  Custmer Pincode   (current) : "+a[i].getCadd().getPcode()
					         + "\n  Custmer place     (current) : "+a[i].getCadd().getPlace()
					         + "\n  Custmer State     (current) : "+a[i].getCadd().getState()
					         + "\n=====================Bank Address Details=================================="
					         + "\n               Bank city      : "+a[i].getBadd().getCity()
					         + "\n               Bank Pincode   : "+a[i].getBadd().getPcode()
					         + "\n               Bank place     : "+a[i].getBadd().getPlace()
					         + "\n               Bank State     : "+a[i].getBadd().getState()
					         + "\n==========================================================================="
					);
		}
	}
	
	public void search(Account[] acc ,int Newaccno ,int Npass)
	{
		for (Account a: acc)
		{
			if (a.getAccountno()==Newaccno && a.getPassword()==Npass)
			{
				System.out.println("your account is present in bank");
			}
			else 
				System.out.println("Your account is not present in bank");
		}	
	}
	
	public Account[] delete(Account acc[] ,int ano)
		{
			int i=0;
			Account temp[] = new Account[acc.length-1];
			for (Account a : acc)
			{ 
				if (a.getAccountno()!=ano)
				{
				temp[i]=a;	
				i++;
				}
			}
			System.out.println("Your Account Deleted succesfully");
		return temp;	
		}

	static int Accountno()
	{
		int len =4;
	    String numbers = "0123456789";
	    Random rndm_method = new Random();
	    char[] Accountnumber = new char[len];
	    for (int i = 0; i < len; i++)
	    {
	        Accountnumber[i] = numbers.charAt(rndm_method.nextInt(numbers.length()));
	    }
	    int result=0;
	    for (int i = 0; i < Accountnumber.length; i++) 
	    {
	    	int digit = Accountnumber[i]-'0';
	    	result *= 10;
	    	result += digit;
		}
	    return result;
	}
	public Account[] copyToMain(Account[] acc,Account[] main) 
	{
		int i,k =0;
		Account[] temp = new Account[acc.length+main.length];	
		
		for (i = 0; i < main.length; i++)
		{
		temp[i]=main[i];	
		}
		i--;
		for (int j = i; j < acc.length; j++)
		{
			temp[j]=acc[j];
		}
		
		return temp;
	}
	
	public Account[] Regular() 
	{
		int accno=0;
	//---------------------------------------------------------------------------------------------
		Account[] reg = new Account[5];
		Custmer cust =new  Custmer("mahesh", "9623897271", "564456"); 
		custadd cadd = new  custadd("Dattanagar","Dighi", "maharashtra",411015);
		bankAddress badd = new bankAddress("R And D E Dighi ","Alandi Road pune", "maharashtra",411015);
		accno = 1111;
	    reg[1] = new Account(accno, "saving", 500, 1234, cust, cadd, badd);	
	  //---------------------------------------------------------------------------------------------
	    Custmer cust1 =new  Custmer("mahesh", "9623897271", "564456"); 
		custadd cadd1 = new  custadd("Dattanagar","Dighi", "maharashtra",411015);  
		bankAddress badd1 = new bankAddress("R And D E Dighi ","Alandi Road pune", "maharashtra",411015);
		accno = 1112;
		reg[1] = new Account(accno, "saving", 500, 1234, cust1, cadd1, badd1);	
	  //---------------------------------------------------------------------------------------------
	    Custmer cust2 =new  Custmer("mahesh", "9623897271", "564456"); 
		custadd cadd2 = new  custadd("Dattanagar","Dighi", "maharashtra",411015);
		bankAddress badd2 = new bankAddress("R And D E Dighi ","Alandi Road pune", "maharashtra",411015);
		accno = 1113;
		reg[2] = new Account(accno, "saving", 500, 1234, cust2, cadd2, badd2);
	  //---------------------------------------------------------------------------------------------
	    Custmer cust3 =new  Custmer("mahesh", "9623897271", "564456"); 
		custadd cadd3 = new  custadd("Dattanagar","Dighi", "maharashtra",411015);
		bankAddress badd3 = new bankAddress("R And D E Dighi ","Alandi Road pune", "maharashtra",411015);
		accno = 1114;
		reg[3] = new Account(accno, "saving", 500, 1234, cust3, cadd3, badd3);  //	
		return reg;
	}

}