public class Admin 
{
	private int id;
	private String name;
	private int pass;
	private double mobno;
	public Admin(int id, String name, int pass, double mobno) 
	{
		super();
		this.id = id;
		this.name = name;
		this.pass = pass;
		this.mobno = mobno;
	}
	public int getId() 
	{
		return id;
	}
	public void setId(int id) 
	{
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPass() {
		return pass;
	}
	public void setPass(int pass) {
		this.pass = pass;
	}
	public double getMobno() {
		return mobno;
	}
	public void setMobno(double mobno) {
		this.mobno = mobno;
	}
}
