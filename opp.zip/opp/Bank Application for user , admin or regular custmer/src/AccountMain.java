import java.util.Scanner;
public class AccountMain 
{
	public static void main(String[] args) 
	{
		int len=0;
		Scanner sc = new Scanner(System.in);
		AccountInfo accountInfo = new AccountInfo();
		Transation transation = new Transation();
		Account  acc[]= null; 
		Account  accmain[]= null;
		Account  accreg[]= null;
		AdminInfo adminInfo=new  AdminInfo();
		Admin[] admin = null; 
		admin= adminInfo.create();
		accreg=accountInfo.Regular();
		do 
		{
			 System.out.println("===============================================================");
			 System.out.println("[ 1 :--> Create Account   |<>|  2 :--> Display Account   ]\n"
			 				  + "[ 3 :--> Search Account   |<>|  4 :--> Transation        ]\n"
			 				  + "[ 5 :--> Delete Account   |<>|  6 :--> Exit              ]");
			 System.out.println("===============================================================");
			 System.out.println("Enter your choice");
			 String choice = sc.next();
			 switch (choice) 
			 {                 
				case "1":
					acc=accountInfo.createAccount();
					break;
				case "2":
					accountInfo.display(acc);
					break;
				case "3":
					System.out.println("Enter Your Account Number Or Password");
					int Newaccno = sc.nextInt();
					int pass=sc.nextInt();
					accountInfo.search(acc, Newaccno,pass);
					break;
				case "4":
					transation.transation(acc);
					break;
				case "5":
					System.out.println("Enter Your Account Number Or Password");
					int ano = sc.nextInt();
					acc=accountInfo.delete(acc, ano);
					break;
				case "6":
					accmain=accountInfo.copyToMain(acc, accreg);
					accountInfo.display(accmain);
					break;
				default :
					System.out.println("--------------------Invalied choice---------------------");
					System.out.println("----------------Thank You && Visit Again----------------");
					break;
			 }
			 
		} while (1==1);
		
	}
}












































































































































