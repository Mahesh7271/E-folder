public class Account 
{
	private  int  accountno;
	private String accType;
	private double balance;
	private int password;
	private Custmer custmer;
	private custadd cadd;
	private bankAddress badd;

	public Account(int accountno, String accType, double balance, int password, Custmer custmer, custadd cadd,
			bankAddress badd) {
		super();
		this.accountno = accountno;
		this.accType = accType;
		this.balance = balance;
		this.password = password;
		this.custmer = custmer;
		this.cadd = cadd;
		this.badd = badd;
	}
	public int getPassword() {
		return password;
	}
	public void setPassword(int password) {
		this.password = password;
	}
	public int getAccountno() {
		return accountno;
	}
	public void setAccountno(int accountno) {
		this.accountno = accountno;
	}
	public String getAccType() {
		return accType;
	}
	public void setAccType(String accType) {
		this.accType = accType;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public Custmer getCustmer() {
		return custmer;
	}
	public void setCustmer(Custmer custmer) {
		this.custmer = custmer;
	}
	public custadd getCadd() {
		return cadd;
	}
	public void setCadd(custadd cadd) {
		this.cadd = cadd;
	}
	public bankAddress getBadd() {
		return badd;
	}
	public void setBadd(bankAddress badd) {
		this.badd = badd;
	}
	
}
