public class bankAddress 
{
	 private String place;
	 private String city;
	 private String  state;
	 private int pcode;

	 public bankAddress(String place, String city, String state, int pcode)
	 {
		super();
		this.place = place;
		this.city = city;
		this.state = state;
		this.pcode = pcode;
	}
	public String getPlace() 
	{
		return place;
	}
	public void setPlace(String place)
	{
		this.place = place;
	}
	public String getCity()
	{
		return city;
	}
	public void setCity(String city)
	{
		this.city = city;
	}
	public String getState() 
	{
		return state;
	}
	public void setState(String state) 
	{
		this.state = state;
	}
	public int getPcode() 
	{
		return pcode;
	}
	public void setPcode(int pcode) 
	{
		this.pcode = pcode;
	}
	 	
}
