
public class AdminInfo 
{
	public Admin[] create()
	{
		Admin[] admin = new Admin[5];
		admin[0] =new  Admin(1000, "mahesh bhonde", 7271,962389727);
		admin[1] =new  Admin(1001, "prtik more", 5555,123456789);
		admin[2] =new  Admin(1002, "prtik1", 7777,147258369);
		admin[3] =new  Admin(1003, "Abhishek", 1111,452258565);
		admin[4] =new  Admin(1004, "rohini", 2222,998877665);
		return admin;
	}
	public void Display(Admin[] admin)
	{
		for (Admin a : admin) 
		{
		System.out.println("Admin Name      :------> "+a.getName());	
		System.out.println("Admin password  :------> "+a.getPass());
		}
	}
}
