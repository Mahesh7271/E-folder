public class Custmer 
{
	 private String name;
	 private String phoneno;
	 private String  adharno;
	public Custmer(String name, String phoneno, String adharno) {
		super();
		this.name = name;
		this.phoneno = phoneno;
		this.adharno = adharno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhoneno() {
		return phoneno;
	}
	public void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
	}
	public String getAdharno() {
		return adharno;
	}
	public void setAdharno(String adharno) {
		this.adharno = adharno;
	}
	 
}
