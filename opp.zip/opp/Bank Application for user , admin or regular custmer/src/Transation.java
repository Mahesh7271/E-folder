import java.util.Scanner;
public class Transation 
{
	AccountInfo accountInfo = new AccountInfo();
	Scanner sc = new Scanner(System.in);
	public void transation(Account[] acc)
	{
		System.out.println("Enter your Account number or passsword ");
		int Newaccno =sc.nextInt();
		int pass=sc.nextInt();
		accountInfo.search(acc, Newaccno ,pass);
		System.out.println("=======================================================");
		System.out.println("[ 1 :--> Withdrow your Amount ]"
				         + "[ 2 :--> Deposit your  Amount ]");
		System.out.println("=======================================================");
		String choice = sc.next();
		switch (choice)
		{
		case "1":
			System.out.println("Enter your Amount to be Withdrow ");
			int amount = sc.nextInt();
			withDrow(acc,Newaccno, amount, pass);
			break;

		case "2":
			
			break;

		default:
			break;
		}
	}
	public void withDrow(Account[] acc,int Newno,int amount,int pass)
	{
		for (Account a : acc)
		{
			if (a.getAccountno()==Newno && a.getPassword()==pass)
			{
				a.setBalance(a.getBalance()-amount);
				System.out.println("Withdrow your amount is : "+amount);
				System.out.println("Your remaning amount is : "+a.getBalance());
			}
		}	
	
	}
}
