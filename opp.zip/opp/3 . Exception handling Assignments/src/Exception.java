import java.util.Scanner;

public class Exception 
{
	public static void main(String[] args) 
	{
		CalcAverage calcAverage = new CalcAverage();
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter Any Natural Number :");
		int num = scanner.nextInt();
		double result = calcAverage.avgFirstNumber(num);
		System.out.println("Average is : "+result);
	}

}
