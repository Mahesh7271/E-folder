
public class userIllegalArgumentException extends Exception
{

	@Override
	public String toString() 
	{
		return "Value must be Non-negative";
	}

}
