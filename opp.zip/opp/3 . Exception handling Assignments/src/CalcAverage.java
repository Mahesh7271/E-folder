public class CalcAverage 
{
	public double avgFirstNumber(int n) throws IllegalArgumentException
	{
		if (n<0)
		{
				throw new IllegalArgumentException("Value Must be Non-Negative");
		}
		double sum=0;
		for (int i = 0; i <=n; i++) 
		{
			sum=sum+1;
		}
		double average = sum/n;
		return average;
	}
}
























