import java.util.Random;

public class AccountNumber
{
    static char[] Accountno(int len)
    {
        System.out.println("Generating Account number using random() : ");
        System.out.print("You Account number is : ");
  
        // Using numeric values
        String numbers = "01234567890123456789";
  
        // Using random method
        Random rndm_method = new Random();
  
        char[] Accountnumber = new char[len];
  
        for (int i = 0; i < len; i++)
        {
            // Use of charAt() method : to get character value
            // Use of nextInt() as it is scanning the value as int
            Accountnumber[i] =
             numbers.charAt(rndm_method.nextInt(numbers.length()));
        }
        return Accountnumber;
    }
    public static void main(String[] args)
    {
        System.out.println(Accountno(8));
    }
}