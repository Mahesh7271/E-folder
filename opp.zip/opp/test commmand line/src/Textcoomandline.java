public class Textcoomandline 
{
	public static void main(String[] args)
	{
		System.out.println(args[0]);
		System.out.println(args[1]);
		int n1=Integer.parseInt(args[0]);
		int n2=Integer.parseInt(args[1]);
		int sum=0;
	for(int i = 0; i < n1; i++) 
	{
		 sum=sum+n2;		
	}
	System.out.println("multiplication is :"+sum);
	}
}
