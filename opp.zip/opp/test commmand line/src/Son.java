public class Son extends Father
{
 private int sage;
	 public void sage(int sage)
	 {
		this.sage=sage;
	 }
}
