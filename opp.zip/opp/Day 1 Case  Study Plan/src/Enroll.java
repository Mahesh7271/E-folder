import java.time.LocalDate;
import java.time.LocalDateTime;
public class Enroll 
{
	private Student student;
	private Course course;
	private String enrollmentdate;
	public Enroll(Student student, Course course, String enrollmentdate) {
		super();
		this.student = student;
		this.course = course;
		this.enrollmentdate = enrollmentdate;
	}
	public Student getStudent() 
	{
		return student;
	}
	public void setStudent(Student student) 
	{
		this.student = student;
	}
	public Course getCourse() 
	{
		return course;
	}
	public void setCourse(Course course) 
	{
		this.course = course;
	}
	public String getEnrollmentdate() 
	{
		return enrollmentdate;
	}
	public void setEnrollmentdate(String enrollmentdate) 
	{
		this.enrollmentdate = enrollmentdate;
	}

}
