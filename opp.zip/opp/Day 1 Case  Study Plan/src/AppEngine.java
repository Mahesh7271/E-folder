import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;
public class AppEngine 
{
	Scanner sc = new Scanner(System.in);	
	public void introduce(Course[] c)
	{
		for (int i = 0; i < c.length; i++) 
		{
			System.out.println("Course id\tcourse name\t\t\tcourse Duration \t\t course fees ");
			System.out.println(c[i].getId()+"\t\t"+c[i].getCoursename()+"\t"+c[i].getDuration()+"\t\t"+c[i].getFees());
		}
	}
	public void register(Student[] c)
	{
		for (int i = 0; i < c.length; i++) 
		{
			System.out.println("Student Id\t\tStudent Name\t Student Date of birth");
			System.out.println(c[i].getId()+"\t\t\t"+c[i].getName()+"\t\t\t"+c[i].getDob());
		}
	}
	public Student[] listofStudents()
	{
		Student[] s = new Student[4];
		s[0]= new Student(100, "mahesh",(double) 28022000);
		s[1]= new Student(100, "dinesh",(double) 10082000);
		s[2]= new Student(100, "mayuri",(double) 24032000);
		s[3]= new Student(100, "pratik",(double) 20022001);
		return s;
	}
	public Course[] listofCourse()
	{
		 Course[] courses = new Course[4];
		courses[0]= new Course(1001, "Java Full Stack devlopment", "placement regarding",	15000);
		courses[1]= new Course(1002, "Payton                    ", "placement regarding",	5000);
		courses[2]= new Course(1001, "c language                ", "placement regarding",	3000);
		courses[3]= new Course(1001, "c++                       ", "placement regarding",	3000);
		return courses;
	}
	public void Enroll( Student[] s , Course[] course)
	{
	introduce(course);
	register(s);
	}
	public String[] listofEnrollments()
	{
		String[] en = new String[4];
	en[0]="12/10/10";
	en[1]="10/04/21";
	en[2]="10/04/21";
	en[3]="10/04/21";
		return en;
		
	}
	public void display(String[] l , Course[] c ,Student[] s)
	{
		for (int i = 0; i < l.length; i++) 
		{
			System.out.println("Enrollment Date is             :"+l[i]);
			System.out.println("--------------------------------------------------------------------------------------------------------------------");
			System.out.println("Course id\tcourse name\t\t\tcourse Duration \t\t course fees ");
			System.out.println(c[i].getId()+"\t\t"+c[i].getCoursename()+"\t"+c[i].getDuration()+"\t\t\t"+c[i].getFees());
			System.out.println("Student Id\tStudent Name\t\t\t Student Date of birth");
			System.out.println(s[i].getId()+"\t\t"+s[i].getName()+"\t\t\t\t"+s[i].getDob());
			System.out.println("--------------------------------------------------------------------------------------------------------------------");
			
		}
		
	}
}
