public class Custmer 
{
	private String custName;
	private double custmobile;
	public Custmer(String custName, double custmobile, double adharno, String gmail) {
		super();
		this.custName = custName;
		this.custmobile = custmobile;
		Adharno = adharno;
		this.gmail = gmail;
	}
	public double getAdharno() {
		return Adharno;
	}
	public void setAdharno(double adharno) {
		Adharno = adharno;
	}
	public String getGmail() {
		return gmail;
	}
	public void setGmail(String gmail) {
		this.gmail = gmail;
	}
	private double Adharno;
	private String gmail;
	
	public Custmer(String custName, double custmobile) {
		super();
		this.custName = custName;
		this.custmobile = custmobile;	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public double getCustmobile() {
		return custmobile;
	}
	public void setCustmobile(double custmobile) {
		this.custmobile = custmobile;
	}
	
	
}
