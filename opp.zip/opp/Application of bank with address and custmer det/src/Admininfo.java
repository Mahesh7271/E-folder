
public class Admininfo
{
	public Admin[] create()
	{
	Admin[] admin =new Admin[6];
	admin[0]=new Admin("Mahesh Bhonde", 7271);
	admin[1]=new Admin("Tejas Bhonde", 1111);
	admin[2]=new Admin("Rutuja", 7997);
	admin[4]=new Admin("Prtik", 5555);
	admin[5]=new Admin("Rohini Ithape ", 3333);
	return admin;
	}
	public void display(Admin[] ar)
	{
		System.out.println("Name: \t\t password ");
		for (int i = 0; i < ar.length; i++) 
		{
			System.out.println(ar[i].getAdname()+"\t"+ar[i].getAdpass());					
		}
	}
}
