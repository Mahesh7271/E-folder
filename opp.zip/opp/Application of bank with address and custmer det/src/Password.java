import java.util.Random;
import java.util.Scanner;
/*==================================Create Password randomly or your choice==============================================================*/
public class Password 
{
	Scanner sc = new Scanner(System.in);
	public Regular[] Regularpass(Account[] p)
	{
		Regular r[]=new Regular[p.length];
		r[0]=new Regular(1010);		
		r[1]=new Regular(1010);		
		r[2]=new Regular(1010);		
		r[3]=new Regular(1010);		
		r[4]=new Regular(1010);		
		r[5]=new Regular(1010);		
		r[6]=new Regular(1010);		
		r[7]=new Regular(1010);		
		r[8]=new Regular(1010);		
		return r;
	}
private Account Password(int i)
{
		// TODO Auto-generated method stub
		return null;
	}
	/*==================================Create Password randomly or your choice==============================================================*/
	public String[] create(Account[] acc) 
	{
		String pass[] = new String[acc.length]; 
		for (int i = 0; i < acc.length; i++)
		{
			System.out.print("\n========================================================================");
			System.out.print("\n     Do you want to  create Password randomly  :  1");
			System.out.print("\n========================================================================");
				if(sc.nextInt()==1)
			{					
		       pass[i]=randomcreate_Password(4);
			}
			else
			{
		  	System.out.println("\nEnter any Password for account :"+acc[i].getAccountno());
			pass[i]=sc.next();		
			}
		}
		return pass;
	}
/*========================================Create a password randomly seprate function========================================================*/
public String randomcreate_Password(int len)
	{

		String temp =null ;
		System.out.println("Generating password using random() : ");
		String Capital_chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		String Small_chars = "abcdefghijklmnopqrstuvwxyz";
		String numbers = "0123456789";
				String symbols = "@#$*-+";


		String values = Capital_chars + Small_chars +
						numbers + symbols;

		// Using random method
		Random rndm_method = new Random();

		char password[] = new char[len];

		for (int i = 0; i < len; i++)
		{
				password[i] = values.charAt(rndm_method.nextInt(values.length())); 	
				
		}
		temp=String.valueOf(password);
		return (String) temp;
	}
/*=========================================Change a password=======================================================*/
public String[] changepassword(String[] parr,String newpass ,Account[] acc,int ano) 
	{
		String temp[] = new String[parr.length]; 
		for (int i = 0; i < acc.length; i++)
		{
			if(acc[i].getAccountno()==ano)
			{
				temp[i]=newpass;
			}
			else
			{
				temp[i]=parr[i];
			}
		}
		return temp;
	}
/*======================================Create account number  randomly==========================================================*/
static int Accountno(int len)
{
  
    // Using numeric values
    String numbers = "0123456789'";

    // Using random method
    Random rndm_method = new Random();

    char[] Accountnumber = new char[len];

    for (int i = 0; i < len; i++)
    {
        // Use of charAt() method : to get character value
        // Use of nextInt() as it is scanning the value as int
        Accountnumber[i] =
         numbers.charAt(rndm_method.nextInt(numbers.length()));
    }
    int result=0;
    for (int i = 0; i < Accountnumber.length; i++) 
    {
    	int digit = Accountnumber[i]-'0';
    	result *= 10;
    	result += digit;
	}
    return result;
}
		
}