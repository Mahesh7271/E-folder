public class Transation 
{
	public void withdrow(Account[] acc,int ano,int amo)
	{
		for (Account a : acc)
		{
			if (a.getAccountno()==ano)
			{
				System.out.println("Your Amount is "+a.getAccountno()+"withdrow balance is "+amo);
				a.setBalance(a.getBalance()-amo); 
				System.out.println("Remaning Account Balance is : "+a.getBalance());
			}
		}	
	}
	public void deposit(Account[] acc,int ano,int amo)
	{
		for (Account a : acc)
		{
			if (a.getAccountno()==ano)
			{
				System.out.println("Your Deposit Amount is : "+a.getBalance());
				a.setBalance(a.getBalance()+amo); 
				System.out.println("Your Amount is :  "+a.getAccountno()+"Successfull Deposit Amount is :  "+amo);
			}
		}	
	}
}
