public class Account 
{
	private  int  accountno;
	private String accType;
	private double balance;
    private Address add;
	private Custmer cust;
	public Account(int accountno, String accType, double balance, Address add, Custmer cust) {
		super();
		this.accountno = accountno;
		this.accType = accType;
		this.balance = balance;
		this.add = add;
		this.cust = cust;
	}
	public Account(char[] create_accountnumberrandomly, int nextInt, String next, double nextDouble, Address add2,
			Custmer cust2) {
		// TODO Auto-generated constructor stub
	}
	public int getAccountno() {
		return accountno;
	}
	public void setAccountno(int accountno) {
		this.accountno = accountno;
	}
	public String getAccType() {
		return accType;
	}
	public void setAccType(String accType) {
		this.accType = accType;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public Address getAdd() {
		return add;
	}
	public void setAdd(Address add) {
		this.add = add;
	}
	public Custmer getCust() {
		return cust;
	}
	public void setCust(Custmer cust) {
		this.cust = cust;
	}
	@Override
	public String toString() {
		return "Account accountno=" + accountno + ", accType=" + accType + ", balance=" + balance + ", add=" + add
				+ ", cust=" + cust ;
	}
	
}       