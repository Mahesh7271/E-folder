	import java.util.Scanner;
/*================================================================================================*/
public class Accountinfo
{
	Password p = new Password();
	Transation tran = new Transation();
	Scanner sc = new Scanner(System.in);
	/*=================================Create Regular person===============================================================*/
public Account[] Regular() 
{
	int accno=0;
//---------------------------------------------------------------------------------------------
	Account[] reg = new Account[9];
	Custmer cust = new Custmer("rutuja", 706600,123456, "rutuja@gmail.com");
    Address  add = new Address("Dighi", "15", "Dattanager", "pune","pune");
    accno = p.Accountno(8);
    reg[1] = new Account(accno,"saving",500, add, cust);	
  //---------------------------------------------------------------------------------------------
    Custmer cust1 = new Custmer("prtik",9595545,123456, "Pratik@gmail.com");
    Address  add1 = new Address("talegoan", "4555", "abc", "Talegoan","pune");
    accno = p.Accountno(8);
    reg[2] = new Account(accno,"saving",5000, add1, cust1);	
  //---------------------------------------------------------------------------------------------
    Custmer cust2 = new Custmer("mahesh",962389727,58182632, "bhondemahesh9999@gmail.com");
    Address  add2 = new Address("Dighi", "15", "Dattanager", "pune","pune");
    accno = p.Accountno(8);
    reg[3] = new Account(accno,"saving",1500, add2, cust2);
  //---------------------------------------------------------------------------------------------
    Custmer cust3 = new Custmer("Tanuja", 706600,7894, "Tanuja@gmail.com");
    Address  add3 = new Address("Dighi", "15", "Dattanager", "pune","pune");
    accno = p.Accountno(8);
    reg[4] = new Account(accno,"saving",500, add3, cust3);
  //---------------------------------------------------------------------------------------------
    Custmer cust4 = new Custmer("rohini", 969568,123456, "rohini1999@gmail.com");
    Address  add4 = new Address("Dhankawadi","65","Abcnager", "pune","pune");
    accno = p.Accountno(8);
    reg[5] = new Account(accno,"saving",1520, add4, cust4);
  //---------------------------------------------------------------------------------------------
    Custmer cust5 = new Custmer("Avni", 705812582,979797, "Avni@gmail.com");
    Address  add5 = new Address("Kharadi", "85", "Blue Berry", "pune","pune");
    accno = p.Accountno(8);
    reg[6] = new Account(accno,"saving",500, add5, cust5);	
  //---------------------------------------------------------------------------------------------
	return reg;
}
/*=================================create Account===============================================================*/
public Account[] Create()
{
	System.out.println("----------------Haw many account do you want-------------------");
	int n=sc.nextInt();
	Account[] acc = new Account[n]; 
	for (int i = 0; i < acc.length; i++)
	{
		System.out.println("--------Enter a Custmer imformation for "+(i+100)+"------------");
		System.out.println("=====================Custmer Detailes==========================");
		System.out.println("Custmer Name (only capital)      :");
		String name=sc.next();
		System.out.println("Custmer Mobile number(10 digits) :");
		double mobileno = sc.nextDouble();
		System.out.println("Custmer Adhar number (12 digits) :");
		double adharno = sc.nextDouble();
		System.out.println("Custmer Gmail id (abc@gmail.com) :");
		String gmail = sc.next();
		System.out.println("=====================Custmer Address===========================");
		System.out.println("Custmer Address (current)        :");
		String custadd = sc.next();
		System.out.println("Custmer Pincode(ex-> 413702 like):");
		String pin = sc.next();
		System.out.println("Custmer Tal : ");
		String tal = sc.next();
		System.out.println("=====================Account Detailes==========================");
		int accno = p.Accountno(8);
		System.out.println("Custmer Account Type   : ");
		String acctype= sc.next();
		System.out.println("Custmer Balance (deposit amount):");
		double amo = sc.nextDouble();
	    Custmer cust = new Custmer(name   , mobileno, adharno, gmail);
	    Address  add = new Address(custadd, pin     , custadd, tal  , "Pune");
	          acc[i] = new Account(accno  , acctype , amo    , add  , cust);
		System.out.println("-------Your account is created <====>Thank you for visit-------");
	 }
	return acc;
 }
/*====================================Display Regular custmer data============================================================*/
public void Regulardisplay(Account[] acc)
{
	for (Account a : acc)
	{
		System.out.println("------------------------"+a+"---------------------");
		System.out.println("\nCustmer Account number      : "+a.getAccountno()
				         + "\nCustmer Account Type        : "+a.getAccType()
				         + "\nCustmer Balance in (Rupess) : "+a.getBalance()
				         + "\nCustmer Name in (capital)   : "+a.getCust().getCustName()
				         + "\nCustmer Mobile number (+91) : "+a.getCust().getCustmobile()
				         + "\nCustmer Adhar number        : "+a.getCust().getAdharno()
				         + "\nCustmer Gmail id  (current) : "+a.getCust().getGmail()
				         + "\nCustmer Address   (current) : "+a.getAdd().getApAddress()
				         + "\nCustmer Pincode   (current) : "+a.getAdd().getPincode()
				         + "\nCustmer Village   (current) : "+a.getAdd().getVillage()
				         + "\nCustmer Taluka    (current) : "+a.getAdd().getTal()
				         + "\nCustmer  Dist     (current) : "+a.getAdd().getDist());
	}
	
}

/*====================================Display password[Admin use only]============================================================*/
public void Displaypass(Account acc[] ,String ar[])
{
	 for (int i = 0; i < acc.length; i++) 
	 {
		System.out.println("--------------------------------------------------");
		System.out.println(  " this -> Account number  :"+acc[i].getAccountno()
				           +"\n this -> Password        :"+ar[i]);
		System.out.println("--------------------------------------------------");
	 }	
}
/*====================================Dislpay Account Details============================================================*/
public void display(Account acc[]) 
{
	for (Account a : acc)
	{
		System.out.println("------------------------"+a+"---------------------");
		System.out.println("\nCustmer Account number      : "+a.getAccountno()
				         + "\nCustmer Account Type        : "+a.getAccType()
				         + "\nCustmer Balance in (Rupess) : "+a.getBalance()
				         + "\nCustmer Name in (capital)   : "+a.getCust().getCustName()
				         + "\nCustmer Mobile number (+91) : "+a.getCust().getCustmobile()
				         + "\nCustmer Adhar number        : "+a.getCust().getAdharno()
				         + "\nCustmer Gmail id  (current) : "+a.getCust().getGmail()
				         + "\nCustmer Address   (current) : "+a.getAdd().getApAddress()
				         + "\nCustmer Pincode   (current) : "+a.getAdd().getPincode()
				         + "\nCustmer Village   (current) : "+a.getAdd().getVillage()
				         + "\nCustmer Taluka    (current) : "+a.getAdd().getTal()
				         + "\nCustmer  Dist     (current) : "+a.getAdd().getDist());
	}

}
/*=========================================Search Account For Custmer in Bank=======================================================*/
public boolean  search(Account acc[] ,int ano)
	{
		boolean b=false;
		for (Account a : acc)
		{
			if (a.getAccountno()==ano)
			{
				b=true;
			}
		}
		return b;
	}
/*=========================================Delete Account For Custmer in Bank =======================================================*/
public Account[] delete(Account acc[] ,int ano)
	{
		int i=0;
		Account temp[] = new Account[acc.length-1];
		for (Account a : acc)
		{ 
			if (a.getAccountno()!=ano)
			{
			temp[i]=a;	
			i++;
			}
		}
	return temp;	
	}
/*==========================================Transation (withdrow or deposit  amount) For Custmer======================================================*/
public void transation(Account[] acc , int ano) 
{
    System.out.println("Press with [Or] 1 :- Withdrow the Amount ");
	System.out.println("Press dep  [Or] 2 :-  Deposit Amount     ");
	System.out.println("Enter your choice :");
	String tr=sc.next();
		switch (tr)
	{
	case "1":
	case "with":
		System.out.println("Enter Amount for Withdrow ");
		int amount = sc.nextInt();		
			tran.withdrow(acc,ano,amount);
		break;
	case "2":
	case "dep":
		System.out.println("Enter  Amount for Deposit ");
		int amount1 = sc.nextInt();		
			tran.deposit(acc, ano, amount1);
		break;
	case "3":
	case "exit":
			System.out.println("---------------ThanKs You @--------------");
		break;
	}
	
	}
}