public class Address
{
	private String ApAddress;
	private String pincode;
	private String village;
	private String tal;
	private String dist;
	
	public String getTal() {
		return tal;
	}
	public void setTal(String tal) {
		this.tal = tal;
	}
	public String getDist() {
		return dist;
	}
	public Address(String apAddress, String pincode, String village, String tal, String dist) {
		super();
		ApAddress = apAddress;
		this.pincode =pincode;
		this.village = village;
		this.tal = tal;
		this.dist = dist;
	}
	public void setDist(String dist) {
		this.dist = dist;
	}
	
	public Address(String tal, String dist) {
		super();
		this.tal = tal;
		this.dist = dist;
	}
	public Address(String apAddress, String pincode, String village)
	{
		super();
		ApAddress = apAddress;
		this.pincode = pincode;
		this.village = village;
	}
	public String getApAddress()
	{
		return ApAddress;
	}
	public void setApAddress(String apAddress)
	{
		ApAddress = apAddress;
	}
	public String getPincode() 
	{
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	public String getVillage() {
		return village;
	}
	public void setVillage(String village) {
		this.village = village;
	}
	
}
