public class Admin 
{
	private int joindate;
	private int id;
	private String Adname;
	private int Adpass;
	private int mobileno;
	public Admin(String adname, int adpass) {
		super();
		Adname = adname;
		Adpass = adpass;
			}
	public int getJoindate() {
		return joindate;
	}
	public void setJoindate(int joindate) {
		this.joindate = joindate;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getAdname() {
		return Adname;
	}
	public void setAdname(String adname) {
		Adname = adname;
	}
	public int getAdpass() {
		return Adpass;
	}
	public void setAdpass(int adpass) {
		Adpass = adpass;
	}
	public int getMobileno() {
		return mobileno;
	}
	public void setMobileno(int mobileno) {
		this.mobileno = mobileno;
	}
	
}
