public class Regular 
{
private int pass;

public Regular(int pass) {
	super();
	this.pass = pass;
}

public int getPass() {
	return pass;
}

public int setPass(int pass) {
	return this.pass = pass;
}
}
