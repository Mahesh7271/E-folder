import java.util.Scanner;
public class AccountMain 
{
	public static void main(String[] args) 
	{
	Scanner sc = new Scanner(System.in);
	int flag=0,accno;
	boolean check;
	Password p = new Password();
	     Admin admin[] = null;
	      Admininfo ad = new Admininfo();
	Accountinfo ainfo  = new Accountinfo();
	  Account    acc[] = null ;
	 Account regular[] = null ;
	 Account pass[] = null ;
	 Regular[] regpass = null ;
	String  password[] = null ;
	regular =ainfo.Regular();
	regpass=p.Regularpass(regular);

	//-----------------------------Create admin's and there password----------------------------------------------------------------------
	admin=ad.create();
	//ad.display(admin);
		do 
		{
			String ch="0";
			System.out.println("========================================================================================================");
			System.out.println("          You Are New User : 1 [or] Admin : 2 [or] user( Enter your type to be oprate a system )");
			System.out.println("========================================================================================================");
			int choice=sc.nextInt();
				do 
					{
//=============================================================New Custmer=============================================					
					if( choice==1 )
					{
						System.out.println("========================================================================================================");
				  	    System.out.println("[ Press create     [Or]  1 :- Create Account     || Press display    [Or]  2 :- Display Account         ]"
							           	+"\n[ Press search     [Or]  3 :- search Account     || Press delete     [Or]  4 :- Deleted Account         ]"
							            +"\n[ Press tran       [Or]  5 :- Transation Amonunt ||  Press exit      [Or]  6 :- Exit to be Sub Menu     ]");
						System.out.println("========================================================================================================");
						System.out.println("          Enter Your choice :" );
						System.out.println("========================================================================================================");
						ch = sc.next();
					}
//==========================================================Admin=============================================					
					else if( choice == 2)
					{
						System.out.println("Enter your Admin  passsword");
						int aadminpass=sc.nextInt();
						for (int i = 0 ; i < admin.length ; i++)
						{
							if(admin[i].getAdpass()==aadminpass)
							{
							System.out.println("Password is match @Admin name is    : @"+admin[i].getAdname());
							System.out.println("=========================================Official use only===============================================");
							System.out.println("[ Press delete      [Or]  7 :- delete Account     || Press cpassword  [Or]  8 :- Change Account Password  ]"
									        +"\n[ Press displaypass [Or]  9 :- Display Password of Account || Press display [Or]  2 :- Display Account    ]"
									        +"\n[ Press ad          [Or] 10 :- Display Admin Data          || Press reg [Or] 11:- Regular custmer         ]");
							System.out.println("=========================================================================================================");
							System.out.println("          Enter Your choice :" );
							System.out.println("========================================================================================================");
							ch = sc.next();
							System.out.println("test");
							}	
						}			
					}
//=============================================regular custmer=====================================================================================================
					else if (choice==3) 
					{
						System.out.println("========================================================================================================");
				  	    System.out.println("[ Press display    [Or]  2 :- Display Account    || Press cpassword  [Or]  8 :- Change Account Password  ]"
							           	+"\n[ Press search     [Or]  3 :- search Account     || Press exit      [Or]  6 :- Exit to be Sub Menu       ]"
							            +"\n[ Press tran       [Or]  5 :- Transation Amonunt ||                                                      ]");
						System.out.println("========================================================================================================");
						System.out.println("          Enter Your choice :" );
						System.out.println("========================================================================================================");
						ch = sc.next();
						flag=2;
					}
					else 
						ch="0";
//==============================================================================================================================================
			switch (ch) 
			{
				case "1":
				case "create":
					acc=ainfo.Create();
					password=p.create(acc);
					flag=1;
					break;			
				case "2":
				case "display":
					System.out.println("test");
					if(flag==1)
						ainfo.display(acc);
					else if(flag==2)
					{
					System.out.println("Enter your password");
					int p1= sc.nextInt();
					for (int i = 0; i < regpass.length; i++)
					{
						System.out.println(i);
						if( regpass[i].getPass()==p1 )
						{
							System.out.println("test");
						}
							
					}
					}
					else
						System.out.println("Create a account Firstly");
					break;			
				case "3":
				case "search":
					if(flag==1)
					{
						System.out.println("Enter Your Account number To be search :");
						int ano=sc.nextInt();
						check=ainfo.search(acc, ano);
						if (check)
						System.out.println("Given Account Are Present in Bank ");		
						else 
				 		System.out.println("Given Account Are Not-Present in Bank ");		
					}
					else
						System.out.println("Create a account Firstly");
					break;
				case "7":
				case "4":
				case "delete":
					if(flag==1)
						{
						System.out.println("Enter Your Account number To be deleted :");
						int ano=sc.nextInt();
					 	acc=ainfo.delete(acc, ano);
					 	System.out.println("your Account are ddeleted ");
					 	ainfo.display(acc);
						}
					else
						System.out.println("Create a account Firstly");
					break;
				case "5":
				case "tran":
					if(flag==1)
						{
						System.out.println("Enter Your Account number To be Transation :");
					 	int ano=sc.nextInt();
					 	check=ainfo.search(acc, ano);
					 		if (check)
					 		{
					 			System.out.println("Given Account Are Present in Bank ");
					 			ainfo.transation(acc,ano);
					 		}
					 		else 
					 			System.out.println("Given Account Are Not-Present in Bank ");		
					 			ainfo.transation(acc,ano);
						 }
					else
						System.out.println("Create a account Firstly");
					break;
				case "8":
				case "cpassword":
					System.out.println("Enter account number");
					int ano4=sc.nextInt();
					check=ainfo.search(acc, ano4);
					System.out.println("-----------------------------------------------------");
					if (check)
						System.out.println("       Given Account Are Present in Bank             ");		
					else 
						System.out.println("      Given Account Are Not-Present in Bank          ");		
					 	System.out.println("-----------------------------------------------------");
					 	System.out.println("~~~~~~~~~~~~~~Enter Any new password~~~~~~~~~~~~~~~~~");
						String pas1=sc.next();
						System.out.println("~~~~~~~~~~~~~re-type conferm password~~~~~~~~~~~~~~~~");
						String pas2=sc.next();
							if (pas1==pas2)
							{
								System.out.println("test");
								p.changepassword(password, pas1, acc,ano4);
							}
							else
								System.out.println(pas1+" : Password are not match :"+pas2);
						break;
				case "10":
			    case "ad":
			    	ad.display(admin);  	
			    	break;
			    case "11":
			    case "reg":
			    	ainfo.Regulardisplay(regular);
			    	break;
			    	case "displaypass":
					case "9":
						System.out.println("--------------------------------------------------------------------");
						ainfo.Displaypass(acc, password);
				    	break;
			}//switch
			System.out.println("\n<----------------Do you want to continue :-->press 1---------------->\n");
		}while (1==sc.nextInt());
			System.out.println("\n<----------------Do you want to continue for Admin [or] user:-->press 1---------------->\n");
	}while (1==sc.nextInt());
  }

}



