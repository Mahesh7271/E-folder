public class passwordvar 
{
	private String password;
	private int pass;
	public passwordvar(String password)
	{
		super();
		this.password = password;
	}
	public passwordvar(String password, int pass) {
		super();
		this.password = password;
		this.pass = pass;
	}
	public int getPass() {
		return pass;
	}
	public void setPass(int pass) {
		this.pass = pass;
	}
	public String getPassword() 
	{
		return password;
	}
	public void setPassword(String password) 
	{
		this.password = password;
	}

	


	

	

	



	

}
