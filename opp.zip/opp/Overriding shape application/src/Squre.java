
public class Squre extends Shape
{
	private float r;
	public Squre(float r) {
		this.r = r;
	}

	@Override
	public void FindArea() 
	{
		float ta;
		ta=r*r;
		System.out.println("Area of Square is : "+ta);
	}
	
}
