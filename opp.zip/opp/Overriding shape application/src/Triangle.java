
public class Triangle extends Shape {
	private float b;
	private float h;
	public Triangle(float b, float h) {
		this.b = b;
		this.h = h;
	}
	@Override
	public void FindArea() {
		float ta;
		ta=0.5f*b*h;
		System.out.println("Area of Triangle is : "+ta);
	
	}

}
