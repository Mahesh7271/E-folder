public class ShapeMain 
{
	public static void main(String [] ar) 
	{
		Shape s[] =new Shape[10] ;
		s[0]= new paino();
		s[1]= new Flute();
		s[2]= new Guitar();
		s[3]= new paino();
		s[4]= new Flute();
		s[5]= new Guitar();
		s[6]= new paino();
		s[7]= new Flute();
		s[8]= new Guitar();
		s[9]= new Guitar();
		Display(s);
		/*
		s[0]= new Circle(10);
		s[1]= new Triangle(10, 10);
		s[2]= new Rectangle(10, 10);
		s[3]= new Squre(10);
		s[4]= new Rectangle(10, 10);
		Display(s);*/
	}
	private static void Display(Shape arr[])
	{
		for (int i = 0; i < arr.length; i++) 
		{
			if (arr[i] instanceof paino)
			{
			System.out.println("----------- Paino Class---------------");
			arr[i].Display();
			}
			else if (arr[i] instanceof Flute)
			{
			System.out.println("----------- Flute Class---------------");
			arr[i].Display();
			}
			else if (arr[i] instanceof Guitar)
			{
			System.out.println("----------- Guitar class---------------");
			arr[i].Display();
			}
			else 
				System.out.println("------thank you-----------------");
			}
	}
}
