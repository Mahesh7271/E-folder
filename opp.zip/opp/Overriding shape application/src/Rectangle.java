
public class Rectangle extends Shape {
	private float l;
	private float b;
	public Rectangle(float l, float b) {
		this.l = l;
		this.b = b;
	}
	@Override
	public void FindArea() 
	{
		float ta;
		ta=l*b;
		System.out.println("Area of Rectangle is : "+ta);
	
	}

}
