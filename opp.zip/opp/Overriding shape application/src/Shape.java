
public class Shape 
{
	public void FindArea()
	{
		
	}
	public void Display()
	{
		
	}
}
