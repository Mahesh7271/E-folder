
public class bankAbstract 
{
	
	public void bankFirstscreen()
	{
		
	}
	public void bankUserscreen()
	{
		
	}

	public void bankRegularUserscreen()
	{
		
	}
	public void bankAdminscreen()
	{
		
	}
	public void createAccount ()
	{
	}
	public void display() 
	{
		
	}
	
	
}
