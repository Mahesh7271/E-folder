import java.util.Scanner;
public class AccountMain extends bankAbstract
{
	public static void main(String[] args) 
	{
		/***int len=0;
		Scanner sc = new Scanner(System.in);
		AccountInfo accountInfo = new AccountInfo();
		Account  acc[]= null; 
		Account  accmain[]= null;
		Account  accreg[]= null;
		Admin[] admin = null;
		*/
		AccountInfo accountInfo = new AccountInfo();
		accountInfo.bankFirstscreen();
	}
}












































































































































