   public class Admin 
{
	private int id;
	private String Password;
	private String AdminName;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	public String getAdminName() {
		return AdminName;
	}
	public void setAdminName(String adminName) {
		AdminName = adminName;
	}
	public Admin(int id, String password, String adminName) {
		super();
		this.id = id;
		Password = password;
		AdminName = adminName;
	}
}
