import java.util.Scanner;
public class AccountInfo extends bankAbstract
{
	AccountMethodes accountMethodes =new AccountMethodes();
	Scanner sc = new Scanner(System.in);
	@Override
	public void bankFirstscreen() 
	{
		do 
		{
			System.out.println("==============================================================================");
			System.out.println("         Welcome to Online State Bank of India (SBI) , Branch Dighi            ");
			System.out.println("------------------------------------------------------------------------------");
			System.out.println("   Tell us who you are :  "
					         + "\n1.        New User "
					         + "\n2.        Regular User"
					         + "\n3.        Admin "
					         + "\n4.        Exit");
			System.out.println("==============================================================================");
			System.out.println("Enter your choice");
			 int  choice = sc.nextInt();
			 switch (choice)
			 {
				case 1:
					bankUserscreen();
					break;
				case 2:
					bankRegularUserscreen();
					break;
				case 3:
					bankAdminscreen();
					break;
				case 4:
				default:
					System.out.println("----------------------------Thanks for visit----------------------------------");
				break;
			}

			System.out.println("==============================================================================");
			System.out.println("                 Do you want to Continue Bank_First _Screen  press 1");
		} while (1==sc.nextInt());
	
		System.out.println("------------------------------------------------------------------------------");
		System.out.println("---------------------------"+java.time.LocalDateTime.now()+"----------------------------");
		System.out.println("----------------------------Thanks for visit----------------------------------");
	}
	@Override
	public void bankUserscreen() 
	{
		System.out.println("==============================================================================");
		System.out.println("         Welcome to Online State Bank of India (SBI) , Branch Dighi           ");
		System.out.println("-------------------------------Bank_User_Screen-------------------------------");
		System.out.println(  "1.        Create A New Account "
				         + "\n2.        New policy / Noties"
				         + "\n3.        Any help for Registration"
				         + "\n4.        Exit");
		System.out.println("==============================================================================");
		System.out.println("Enter your choice");
		 int  choice = sc.nextInt();
		 switch (choice)	
		 {
			case 1:
				
				accountMethodes.createAccount();
				break;
			case 2:
				break;
			case 3:
				break;
			case 4:
			default:
				System.out.println("----------------------------Thanks for visit----------------------------------");
				break;
		}
	}
	@Override
	public void bankRegularUserscreen()
	{
		do 
		{
			System.out.println("==============================================================================");
			System.out.println("         Welcome to Online State Bank of India (SBI) , Branch Dighi            ");
			System.out.println("------------------------------------------------------------------------------");
			System.out.println("   Tell us who you are :  "
					         + "\n1.        Display you Account Imformation"
					         + "\n2.        Update any imformation "
					         + "\n3.        Transaction "
					         + "\n3.        Transaction "
					         
					         + "\n4.        Exit");
			System.out.println("==============================================================================");
			System.out.println("Enter your choice");
			 int  choice = sc.nextInt();
			 switch (choice)
			 {
				case 1:
					accountMethodes.display();
					break;
				case 2:
					break;
				case 3:
					break;
				case 4:
				default:
					System.out.println("----------------------------Thanks for visit----------------------------------");
				break;
			}

			System.out.println("\n==============================================================================");
			System.out.println("                 Do you want to Continue Bank_First _Screen  press 1");
		} while (1==sc.nextInt());
	
		System.out.println("------------------------------------------------------------------------------");
		System.out.println("---------------------------"+java.time.LocalDateTime.now()+"----------------------------");
		System.out.println("----------------------------Thanks for visit----------------------------------");
}
	
	
}
