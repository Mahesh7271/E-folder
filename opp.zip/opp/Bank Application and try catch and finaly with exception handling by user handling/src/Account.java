
public class Account 
{
	private int accountNo;
	private String accountType;
	private float accountBalance;
	private int accountPassword;
	private Custmer custmer;
	private Addresss addresss;
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public float getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(float accountBalance) {
		this.accountBalance = accountBalance;
	}
	public int getAccountPassword() {
		return accountPassword;
	}
	public void setAccountPassword(int accountPassword) {
		this.accountPassword = accountPassword;
	}
	public Custmer getCustmer() {
		return custmer;
	}
	public void setCustmer(Custmer custmer) {
		this.custmer = custmer;
	}
	public Addresss getAddresss() {
		return addresss;
	}
	public void setAddresss(Addresss addresss) {
		this.addresss = addresss;
	}
	public Account(int accountNo, String accountType, float accountBalance, int accountPassword, Custmer custmer,
			Addresss addresss) {
		super();
		this.accountNo = accountNo;
		this.accountType = accountType;
		this.accountBalance = accountBalance;
		this.accountPassword = accountPassword;
		this.custmer = custmer;
		this.addresss = addresss;
	}
}
