import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Random;
import java.util.Scanner;

public class AccountMethodes extends bankAbstract
{ 
	@Override
	public void createAccount() 
	{
	Scanner scanner = new Scanner(System.in);
	try
	{
		Class.forName("oracle.jdbc.OracleDriver");
		Connection connection = 
				DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","system");
		System.out.println("-------------------------------------------------------------------");
		PreparedStatement PStatement = connection.prepareStatement("insert into Custmer values(?,?,?,?,?)");
		PreparedStatement PStatement1 = connection.prepareStatement("insert into Address values(?,?,?,?)");
		PreparedStatement PStatement2 = connection.prepareStatement("insert into Bank values(?,?,?,?)");
		do 
		{
			System.out.println("Enter Account Id");
			int ID = scanner.nextInt();
			String id = Integer.toString(ID);
			PStatement.setString(1, id);
			System.out.println("Enter Custmer First Name");
			PStatement.setString(2, scanner.next());
			System.out.println("Enter Custmer Last Name");
			PStatement.setString(3, scanner.next());
			System.out.println("Enter Custmer PANCARD Number or ADHARCARD Number");
			PStatement.setString(4, scanner.next());
			System.out.println("Enter Custmer Moblie Number");
			PStatement.setString(5, scanner.next());
			PStatement1.setString(1, id);
			System.out.println("Enter Custmer City");
			PStatement1.setString(2, scanner.next());
			System.out.println("Enter Custmer State");
			PStatement1.setString(3, scanner.next());
			System.out.println("Enter Custmer Pincode");
			PStatement1.setInt(4, scanner.nextInt());
			int i1 =PStatement1.executeUpdate();
			PStatement2.setString(1, id);
			PStatement2.setString(2, id);
			System.out.println("Enter Type Name");
			PStatement2.setString(3,scanner.next());
			System.out.println("Enter Amount to be Deposit");
			PStatement2.setString(4,scanner.next());
			int i2 =	PStatement2.executeUpdate();
			int i =PStatement.executeUpdate();
			if (i>0 && i1>0 && i2>0 ) 
				System.out.println("Record Inserted...");
			else 
				System.out.println("NOt Record Inserted...");
			System.out.println("Create One More Account in Bank Press |1| ");
		} while (scanner.nextInt()==1);
	} 
	catch (ClassNotFoundException e) {
		e.printStackTrace();
	}
	catch (SQLException e) {
		e.printStackTrace();
	}
}


	@Override
	public void display() 
	{
		try 
		{
			Class.forName("oracle.jdbc.OracleDriver");
		Connection connection = 
				DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","system");
		System.out.println("-------------------------------------------------------------------");
		Statement stmt=connection.createStatement();  
		// execute query  
		ResultSet rs=stmt.executeQuery("select * from Bank");  
		ResultSetMetaData md = rs.getMetaData(); 
		System.out.println("------------------------------------------------------------------------");
		for (int i = 1; i <= md.getColumnCount(); i++)
		{
			System.out.print(md.getColumnName(i)+"\t");
			
		}
		System.out.println();
		while(rs.next())  
			System.out.println(rs.getInt(1)+"\t"+rs.getInt(2)+"\t"+rs.getString(3)+"\t"+rs.getString(4));  
		ResultSet rs1=stmt.executeQuery("select * from Custmer");  
		ResultSetMetaData md1 = rs1.getMetaData(); 
		System.out.println("------------------------------------------------------------------------");
		for (int i = 2; i <= md1.getColumnCount(); i++)
		{
			System.out.print(md1.getColumnName(i)+"\t");
		}
		System.out.println();
		while(rs1.next())  
		System.out.println(rs1.getString(2)+"\t"+rs1.getString(3)+"\t"+rs1.getString(4)+"\t"+rs1.getString(5));  
		ResultSet rs2=stmt.executeQuery("select * from Address");  
		ResultSetMetaData md2 = rs.getMetaData(); 
		System.out.println("------------------------------------------------------------------------");
		for (int i = 2; i <= md2.getColumnCount(); i++)
		{
			System.out.print(md2.getColumnName(i)+"\t");
		}
		System.out.println();
		while(rs2.next())  
		System.out.println(rs2.getString(2)+"\t"+rs2.getString(3)+"\t"+rs2.getInt(4));  
		connection.close();  
		}
		catch (ClassNotFoundException | SQLException  e)
		{
			e.printStackTrace();
		}	
	}
}
