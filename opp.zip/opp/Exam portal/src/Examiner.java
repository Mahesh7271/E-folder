import java.util.Scanner;
public class Examiner 
{
	ExamInfo examInfo = new ExamInfo();
	Scanner scanner  = new Scanner(System.in);
	Admin[] a = examInfo.createAdmin();
	public void ExaminerloginScreen()
	{
		System.out.println("-----------------------------------------------------------------------");
		System.out.println("   Welcome to Online Mcq  Exam portal");
		System.out.println("-----------------------------------------------------------------------");
		int j=0;
		    System.out.println("   Examiner Login Screen To Enter Your valied Imformation"
						        +"\n   Enter Admin Id \n\t\t");
			int Id = scanner.nextInt();
			System.out.println("   Enter Admin Password");
			String password = scanner.next();
			System.out.println("-----------------------------------------------------------------------");
			int i=0;
			while (i<a.length)
			{
					if ( password.equals(a[i].getAdmin_password()) && Id==a[i].getAdminId() ) 
					{	
						System.out.println("-----------------------------------------------------------------------");
						System.out.println(a[i].getAdminName()+"\t"+"Welcome to Online Mcq  Exam portal ##Admin Pages");
						Examiner();
						break;
					}
					else
					{
						Try(i);
					}
		   	}
	}
	public void Try(int n)
	{
		if (n==0)
		{
			System.out.println("Invalied Admin ID try re-enter valied id or password");
		}
		if (n==a.length)
		{
			ExaminerloginScreen();
		}
		else
		{
			ExaminerloginScreen();
		}
	}
	public void Examiner() 
	{
		System.out.println("-----------------------------------------------------------------------");
		System.out.println("1.   Create any test for 4 options"
						+"\n2.   Display all Student imformation to eligible for test"
						+"\n3.   Display all Admins "
						+"\n4.   Display Already Created Test ");
		
		System.out.println("-----------------------------------------------------------------------");
		int choice = scanner.nextInt();
		switch (choice) 
		{
	case 1:
		createAdmintest();	
		Examiner();	
		break;
	case 2:
		displayallstudent();
		Examiner();	
		break;
	case 3:
		displayAllAdmins(a);
		Examiner();	
		break;
	case 4:
		
		break;

		default:
			break;
		}
	}
	public Question[] createAdmintest()
	{
		System.out.println("How many questions do you want enter :");
		int size = scanner.nextInt();
		Question[] q = new Question[size];
		for (int i = 0; i < q.length; i++) 
		{
			System.out.println(" Enter your Question "+(i++));
			String question = scanner.nextLine();
			System.out.println(" Enter your Option 1  ");
			String option_a = scanner.nextLine();
			System.out.println(" Enter your Option 2  ");
			String option_b = scanner.nextLine();
			System.out.println(" Enter your Option 3  ");
			String option_c = scanner.nextLine();
			System.out.println(" Enter your Option 4  ");
			String option_d = scanner.nextLine();
			System.out.println(" Enter your Answer for "+(i++));
			String ans = scanner.nextLine();
			q[i] = new Question((100+i), question, option_a, option_b, option_c, option_d, ans);	
		}
		return q;
		
	}
	public void displayallstudent() 
	{
		
	}
	public void displayAllAdmins(Admin[] a) 
	{
		for (int i = 0; i < a.length; i++) 
		{
			System.out.println("Admin ID Number :\t"+a[i].getAdminId());
			System.out.println("Admin Name      :\t"+a[i].getAdminName());
			System.out.println("Admin Password  :\t"+a[i].getAdmin_password());
		}
	}
	public void displayallstudentTest() 
	{
		
	}
}
