import java.util.Scanner;
public class StudentExamscreen
{
	   ExamInfo examInfo  = new ExamInfo(); 
         Scanner scanner  = new Scanner(System.in);
         public Student login()
         {
        	 System.out.println("  Enter Student Imformation");
        	 System.out.println("  Roll No");
        	 int studentRoll =scanner.nextInt(); 
        	 System.out.println("  PRN Number");
        	 String studentPRN = scanner.next();
        	 System.out.println("  Name");
        	 String studentName =scanner.next();
        	 System.out.println("  Moblie Number");
        	 String studentMoblie = scanner.next();
        	 Student stud =new Student(studentRoll, studentPRN, studentName, studentMoblie);  
        	 
			return stud;
		 }
	public void StudentScreen() 
	{
	    Question[] questions = null;
		    Ans []  StudentAns= null;
		  Student student =login();  
		 int correct;
		System.out.println("-----------------------------------------------------------------------");
		System.out.println("Welcome to Online Mcq  Exam portal");
		System.out.println("-----------------------------------------------------------------------");
		System.out.println("1.   Language Test 20 Question  (20 Marks )"
						+"\n2.   Ability  Test 20 Question  (20 Marks)"
						+"\n3.   Java Language 25 Marks ");
		
		System.out.println("-----------------------------------------------------------------------");
		int choice = scanner.nextInt();
		switch (choice) 
		{
		case 1:
			LanguageTest(student);
			break;
		case 2:
			AbilityTest(student);
			break;
		case 3:
		 	 questions = examInfo.createExam_Java();
			   StudentAns = examInfo.DisplayQuestion(questions);
			    correct = examInfo.Result(StudentAns,questions);
			System.out.println("Correct Ans : "+correct);
			break;
		default:
			break;
		}
	}
	public void AbilityTest(Student student) 
	{
	    Question[] questions = null;
	    Ans[]  StudentAns= null;
	int correct;
	System.out.println("-----------------------------------------------------------------------");
	System.out.println("Welcome to Online Mcq  Exam portal");
	System.out.println("-----------------------------------------------------------------------");
	System.out.println("1.   Ability Test 1 25 Marks"
					+"\n2.   Ability Test 2 25 Marks"
					+"\n3.   Ability Test 3 25 Marks ");
	
	System.out.println("-----------------------------------------------------------------------");
	int choice = scanner.nextInt();
	switch (choice) 
	{
	case 1:
		    	questions = examInfo.createExam_C();
		       StudentAns = examInfo.DisplayQuestion(questions);
		          correct = examInfo.Result(StudentAns,questions);
		          examInfo.finalyResult("Ability Test 1 25 Marks", questions.length, correct,student);
		break;
	case 2:
	 	 questions = examInfo.createExam_Cpp();
		   StudentAns = examInfo.DisplayQuestion(questions);
		    correct = examInfo.Result(StudentAns,questions);
		    examInfo.finalyResult("Ability Test 2 25 Marks", questions.length, correct,student);
		break;
	case 3:
	 	 questions = examInfo.createExam_Java();
		   StudentAns = examInfo.DisplayQuestion(questions);
		    correct = examInfo.Result(StudentAns,questions);
		    examInfo.finalyResult("Ability Test 3 25 Marks", questions.length, correct,student);
		    break;
	default:
		break;
	}
		
	}
	public void LanguageTest(Student student) 
    {
	    Question[] questions = null;
	    Ans[]  StudentAns= null;
	 int correct;
	System.out.println("-----------------------------------------------------------------------");
	System.out.println("Welcome to Online Mcq  Exam portal");
	System.out.println("-----------------------------------------------------------------------");
	System.out.println("1.   C Language 25 Marks"
					+"\n2.   C++ Language 25 Marks"
					+"\n3.   Java Language 25 Marks ");
	
	System.out.println("-----------------------------------------------------------------------");
	int choice = scanner.nextInt();
	switch (choice) 
	{
	case 1:
			questions = examInfo.createExam_C();
	    	StudentAns = examInfo.DisplayQuestion(questions);
	        correct = examInfo.Result(StudentAns,questions);
	        examInfo.finalyResult("C Language 25 Marks", questions.length, correct,student);
		    break;
	case 2:
	 	 	questions = examInfo.createExam_Cpp();
	 	 	StudentAns = examInfo.DisplayQuestion(questions);
		    correct = examInfo.Result(StudentAns,questions);
		    examInfo.finalyResult("C++ Language 25 Marks", questions.length, correct,student);
		    break;
	case 3:
			questions = examInfo.createExam_Java();
			StudentAns = examInfo.DisplayQuestion(questions);
		    correct = examInfo.Result(StudentAns,questions);
		    examInfo.finalyResult("Java Language 25 Marks ", questions.length, correct,student);
		    break;
	default:
		break;
	}
	}
	
}
