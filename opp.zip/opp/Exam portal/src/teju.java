public class teju
{
	public static void main(String[] args) 
	{
		int n=1,i=1;
		while (i<=10) 
		{
			i=1;
			while (i<=10)
			{
				System.out.print("\t"+(n*i));
				i++;
			}
			System.out.println("");	
		}
	}
}
