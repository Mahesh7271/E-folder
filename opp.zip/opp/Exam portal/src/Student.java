
public class Student 
{
	int studentRoll;
	String studentPRN;
	String studentName;
	String studentMoblie;
	public Student(int studentRoll, String studentPRN, String studentName, String studentMoblie) {
		super();
		this.studentRoll = studentRoll;
		this.studentPRN = studentPRN;
		this.studentName = studentName;
		this.studentMoblie = studentMoblie;
	}
	public int getStudentRoll() {
		return studentRoll;
	}
	public void setStudentRoll(int studentRoll) {
		this.studentRoll = studentRoll;
	}
	public String getStudentPRN() {
		return studentPRN;
	}
	public void setStudentPRN(String studentPRN) {
		this.studentPRN = studentPRN;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getStudentMoblie() {
		return studentMoblie;
	}
	public void setStudentMoblie(String studentMoblie) {
		this.studentMoblie = studentMoblie;
	}
	
}
