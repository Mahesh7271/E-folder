
public class Question2 
{
	 private int questionId ;
		private String Question  ; 
		private String  Option_a ;
		private String  Option_b ;
		
		public Question2(int questionId, String question, String option_a, String option_b, String ans) {
			super();
			this.questionId = questionId;
			Question = question;
			Option_a = option_a;
			Option_b = option_b;
			this.ans = ans;
		}

		public int getQuestionId() {
			return questionId;
		}

		public void setQuestionId(int questionId) {
			this.questionId = questionId;
		}

		public String getQuestion() {
			return Question;
		}

		public void setQuestion(String question) {
			Question = question;
		}

		public String getOption_a() {
			return Option_a;
		}

		public void setOption_a(String option_a) {
			Option_a = option_a;
		}

		public String getOption_b() {
			return Option_b;
		}

		public void setOption_b(String option_b) {
			Option_b = option_b;
		}

		public String getAns() {
			return ans;
		}

		public void setAns(String ans) {
			this.ans = ans;
		}

		private String  ans;
		
}
