import java.util.Scanner;

public class ExamInfo 
{
	Scanner scanner  = new Scanner(System.in);
	public Admin[] createAdmin()
	{
		Admin[] a=new Admin[4];
		a[0]=new Admin(1001, "Mahesh", "9999");
		a[1]=new Admin(1002, "Rahul", "1234");
		a[2]=new Admin(1003, "Mayur", "Mayur");
		a[3]=new Admin(1004, "Apurna", "Apurna");
		return a;
	}
	public Question[] createExam_C()
	{
		Question question[] = new Question[20];
		question[0] =new Question(101," What is c language?","object oriented language"," Procedural oriented language","High Level","both 2 and 3","4");//
		question[1] =new Question(102," Who invented C Language.?","Charles Babbage","Grahambel","Dennis Ritchie","Steve Jobs","3");//
		question[2] =new Question(103," C Language is a successor to which language.?","D Language","FORTRAN","BASIC","B Language","4");
		question[3] =new Question(104," C is a which level language.?"," Low Level","High Level","Low + High","None","2");
		question[4] =new Question(105," What is the present C Language Standard.?","C99 ISO/IEC 9899:1999","C11 ISO/IEC 9899:2011"," C05 ISO/IEC 9899:2005","C10 ISO/IEC 9899:2010","2");
		question[5] =new Question(106," C language was invented to develop which Operating System.?","Android","Linux","Ubuntu","Unix","4");
		question[6] =new Question(107," C language was invented in the year.?","1999","1978","1972","1990","3");
		question[7] =new Question(108," C language is used in the development of .?","Databases","Graphic applications","Word Processors","All of the above","4");
		question[8] =new Question(109," A C program is a combination of.?","Variables","Statements","Functions","All of the above","4");
		question[9] =new Question(110,"  Single Line Comment // is also called.?","C++ Style Comment"," Java Style Comment","  PHP Style Comment","All the above","4");
		question[10] =new Question(111," What is an Identifier in C Language.?","Name of a Function or Variable","Name of a Macros","Name of Structure or Union","All the above.","4");
		question[11] =new Question(112," What is the number of characters used to distinguish Identifier or Names of Functions and Global variables.?","31","32","33","28","1");
		question[12] =new Question(113," An Identifier can start with.?"," Alphabet"," Underscore ( _ ) sign","Any character that can be typed on a keyboard","Option A & Option B","4");
		question[13] =new Question(114," Choose correct statements"," A constant value does not change\nA variable value can change according to needs.","A constant can change its values\nA variable can have one constant value only."," There is no restriction on number of values for constants or variables.","Constants and Variables can not be used in a singe main function.","1");
		question[14] =new Question(115," Number of Keywords present in C Language are .?","32","34","62","64","1");
		question[15] =new Question(116," Find an integer constant.","3.140","34"," '125' ","None of the above","2");
		question[16] =new Question(117," Each statement in a C program should end with.?"," Semicolon ;"," Colon :"," Period . (dot symbol)","None of the above.","1");
		question[17] =new Question(118," Identify wrong C Keywords below.","auto, double, int, struct","break, else, long, switch","case, enum, register, typedef","char, extern, intern, return","4");
		question[18] =new Question(119," Find a correct C Keyword below.","breaker"," go to"," shorter","default","4");
		question[19] =new Question(120," What are the new features of C11 or ISO IEC 9899 2011 standard.?"," Type generic Macros, Static Assertions"," Multi Threading, Anonymous Unions, quick_exit"," Bounds Checking Interfaces, Anonymous Strurctures","all","1");
				return question	;                                                                          
	}
	public Question[] createExam_Cpp() 
	{ 
		Question q[] = new Question[20];
		q[0] =new Question(201, "Delaration a pointer more than once may cause ____", "Abort", "Error", "Trap", "Null", "3");
		q[1] =new Question(202, "Which one is not a correct variable type in C++?", "float", "real", "int", "double", "2");
		q[2] =new Question(203, "Which operation is used as Logical 'AND'", "Operator- +", "Operator-||", "Operator-&&", "Operator-&", "3");
		q[3] =new Question(204, "An expression A.B in C++ means ____", "B is member of Object A", "A is member of object B", "Product of A and B", "None of these", "3");
		q[4] =new Question(205, "A C++ code line ends with ___", "A Semicolon (;)", "A Fullstop(.)", "A Comma (,)", "A Slash (/)", "1");
		q[5] =new Question(206, "______ function is used to allocate space for array in memory.", "malloc()", "realloc()", "alloc()", "calloc()", "4");
		q[6] =new Question(207, "A ponter pointing to a variable that is not initialized is called ____", "Void Pointer", "Null Pointer", "Empty Pointer", "Wild Pointer", "b");
		q[7] =new Question(208, "Default constructor has ____ arguments.", "No argument", "One Argument", "Two Argument", "None of these", "1");
		q[8] =new Question(209, "A class whos objects can not be created is known as _____", "Absurd Class", "Super Class", "Dead Class", "Abstract Class", "4");
		q[9] =new Question(210, "Which class allows only one object to be created.", "Nuclear Family Class", "Abstruct Class", "Sigleton Class", "Numero Uno Class", "c");
		q[10] =new Question(211, "Reusability of code in C++ is achieved through ____", "Polymorphism", "Inheritance", "Encapsulation", "Both A and B", "2");
		q[11] =new Question(212, "In CPP, members of a class are ______ by default.", "Public", "Private", "Protected", "Static", "2");
		q[12] =new Question(213, "In C++ Program, inline fuctions are expanded during ____", "Run Time", "Compile Time", "Debug Time", "Coding Time", "1");
		q[13] =new Question(214, "To perfor file input / output operation in C++, we must include which header file ?", "<fiostream>", "<ifstream>", "<ofstream>", "<fstream>", "4");
		q[14] =new Question(215, "An exceptio in C++ can be generated using which keywords.", "thrown", "threw", "throw", "throws", "3");
		q[15] =new Question(216, " Who invented C++?", "Dennis Ritchie", "Ken Thompson", "Brian Kernighan", "Bjarne Stroustrup", "4");
		q[16] =new Question(217, " C++ is ______________", "object oriented programming language", "procedural programming language", "both procedural and object oriented programming language", "functional programming language", "3");
		q[17] =new Question(218, "Which of the following user-defined header file extension used in c++?", "c", "cpp", "css", "html", "2");
		q[18] =new Question(219, " Which of the following is a correct identifier in C++?", " VAR_1234", "$var_name", "7VARNAME", "7var_name", "1");
		q[19] =new Question(220, "Which of the following approach is used by C++?", " Left-right", "Right-left", "Bottom-up", "Top-down", "3");
		return q	;                                                                          
		
	}
	public Question[] createExam_Java()
	{
		Question q[] = new Question[20];
		q[0] =new Question(301, "Java is a Successor to which programming language?", "B", "C", "C++", "D", "3");
		q[1] =new Question(302, "Who invented Java language?", "Dennis Ritchie", "James Gosling", "Serge Page", "Larry Page", "2");
		q[2] =new Question(303, "What is the original name of Java Programming language?", "J++", "C++", " OAK", " TEAK", "3");
		q[3] =new Question(304, "Which laboratory was Java invented or developed in?", " Bell Laboratory", "Sun Microsystems", "Dennis Ritchie Office", "Johnson and Johnson", "2");
		q[4] =new Question(305, "The name 'JAVA' is known to the world as?", "A Tea Brand in India", "A Coffee Brand in Africa", "An Island in Indonesia", " Ragi Malt Juice", "c");
		q[5] =new Question(305, "Java language was originally developed for operating?", "TV", "TV Set-top box", " Embedded System equipment", " All the above", "4");
		q[6] =new Question(306, "What type of Java Programs can be run inside a Java supported Web Browser?", "Stand alone", " Struts", "Applets", "AWT", "3");
		q[7] =new Question(307, " Whic company owns Java at present?", " IBM", "Microsoft", " Sun Microsystems", "Oracle", "4");
		q[8] =new Question(308, "What was the reason for huge initial success of Java?", "WWW (World Wide Web)", "Smart TV Evolution", "Smart Home Automation", "None of the above", "1");
		q[9] =new Question(309, " What is the advantage of EXE files?", "Run Faster", "Efficient", "No separate program required to run", "All the above", "4");
		q[10] =new Question(310, "Computer Viruses and Trojans are often transmitted along with which files?", " JPG files", "TXT files", " EXE files", ".ICO files", "3");
		q[11] =new Question(311, "What is an Interpreter?", " An interpreter converts instructions line by line", "An Interpreter converts source code to low-level code", " Interpreters are slow to execute", "All the above", "4");
		q[12] =new Question(312, "What is a Compiler?", "Compilers work fast", "A compiler converts source code to low-level code", "A Compiler converts all instructions in one go.", "All the above", "4");
		q[13] =new Question(314, "What is the file name extension of a Java source program?", ".j", ".java", ".ja", ".jax", "2");
		q[14] =new Question(315, "What does JVM stands for?", "Java Variable Machine", "Java Virtual Machine", " Java Virtual Mechanism", " None of the above", "2");
		q[15] =new Question(316, " When was first Version of Java i.e Java 1.0 was released?", "1991", "1994", " 1996", "1999", "3");
		q[16] =new Question(317, "What is JIT in Java?", "Java In Time Thread", "Java In Timer", "Just In Time Compiler", "Just In Time Runnable", "3");
		q[17] =new Question(318, " What is the Java distribution type used to build Web Apps in Java?", " Java SE", "Java EE", "Java ME", "Java Embedded", "2");
		q[18] =new Question(319, " What is the Java command used to compile a java program from Command Line or Command Prompt or CMD?", ">javac hello.java", ">javacomp hello.java", ">javacmd hello.java", ">java hello.java", "1");
		q[19] =new Question(320, "A function in C language is similar to what in Java language?", " Method", "Member", " Variable", " None of the above", "1");
		return q	;                                                                          
	}
	public Question[] ability_test1() 
	{
		//https://www.examsbook.com/general-english-questions-and-answers-for-competitive-exam
		Question[] q = new Question[20];
		q[0] = new Question(101, "Bolt from the blue", ". Thundering", " A complete surprise", " Inform something bad", ".No idea", "2");
		q[1] = new Question(102, "Blue blood", "Belonging to low class society", "Give complain in written", ".Member of high class society", "Complain give verbally", "3");
		q[2] = new Question(103, " When the Principal entered the class, a student���. on the blackboard.", " Wrote ", " was writing ", " writes ", " is writing ", "2");
		q[3] = new Question(104, "", "", "", "", "", "");
		q[4] = new Question(105, "", "", "", "", "", "");
		q[5] = new Question(106, "", "", "", "", "", "");
		q[6] = new Question(107, "", "", "", "", "", "");
		q[7] = new Question(108, "", "", "", "", "", "");
		q[8] = new Question(109, "", "", "", "", "", "");
		q[9] = new Question(110, "", "", "", "", "", "");
		q[10] = new Question(111, "", "", "", "", "", "");
		q[11] = new Question(112, "", "", "", "", "", "");
		q[12] = new Question(113, "", "", "", "", "", "");
		q[13] = new Question(114, "", "", "", "", "", "");
		q[14] = new Question(115, "", "", "", "", "", "");
		q[15] = new Question(116, "", "", "", "", "", "");
		q[16] = new Question(117, "", "", "", "", "", "");
		q[17] = new Question(118, "", "", "", "", "", "");
		q[18] = new Question(119, "", "", "", "", "", "");
		q[19] = new Question(120, "", "", "", "", "", "");
		
		return q	;                                                                          
	}
	/*public Question[] createExam_C++()()
	{
		System.out.println("How many question");
		Question question[] = new Question[5];
		question[0] =new Question("What is c ?","object oriented language","Process oriented language");
		question[1] =new Question("what is java?","object oriented language","Process oriented language");
		question[2] =new Question("What is c++ ?","object oriented language","Process oriented language");
		question[3] =new Question("What is Sql ?","Structured query language","Structure oriented language");
		question[4] =new Question("What is Array ?","Collection of Similar data Type","Collection of different data type");
			return question	;
	}*/
	
	public int  Result(Ans[] studentAns , Question[] adminAns) 
	{
		int count=0;
		for (int i = 0; i < adminAns.length; i++) 
		{
			if((studentAns[i].getN1()).equals(adminAns[i].getAns()))
			{
				count++;
			}
		}
		return count;
	}
	public Ans[] DisplayQuestion(Question[] questions)
	{
		int j=100;
		Ans[] studentAns = new Ans[questions.length];
		for (int i = 0; i < questions.length; i++)
		{
			System.out.println(questions[i].getQuestionId()+"\t"+questions[i].getQuestion());
			System.out.println("--------------------------------------------------");
			System.out.println("1\t"+questions[i].getOption_a());
			System.out.println("2\t"+questions[i].getOption_b());
			System.out.println("3\t"+questions[i].getOption_c());
			System.out.println("4\t"+questions[i].getOption_d());
			System.out.println("---------------------------------------------------");
			System.out.println("Enter Answer 1 or 2  :");
			studentAns[i]= new Ans(scanner.next());
		}
		 return studentAns;
	}
	public void finalyResult(String str,int len,int cor,Student student)
	{
		System.out.println("---------------------------------------------------");
		System.out.println("    Welcome to Online Mcq  Exam Result portal");
		System.out.println("---------------------------------------------------");
		System.out.println(" Student Name   :--"+student.studentName);
		System.out.println(" Student Roll   :--"+student.studentRoll+
				         "\n Student Name   :--"+student.studentName);
		System.out.println(" Student Mobile :--"+student.studentMoblie);
		System.out.println("---------------------------------------------------");
		System.out.println("Test name         :--"+str);
		System.out.println("Total Questions   :-- "+len);
		System.out.println("Correct Questions :-- "+cor );
		System.out.println("Worong Questions  :-- "+(len-cor));
		System.out.println("Test Time "+"\t\t"+java.time.LocalDateTime.now());
		System.out.println("---------------------------------------------------");
		
	}
}