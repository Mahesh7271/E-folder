import java.util.Scanner;

public class OnlineExamPortal
{
	public static void main(String[] args) 
	{
		StudentExamscreen student =new StudentExamscreen();
		Examiner examiner =new Examiner();
		Scanner scanner = new Scanner(System.in);
		System.out.println("-----------------------------------------------------------------------");
		System.out.println("Welcome to Online Mcq  Exam portal");
		System.out.println("-----------------------------------------------------------------------");
		System.out.println("1.   Student Exam "
						+"\n2.   Examiner     "
						+"\n3.   Exit         ");
		
		System.out.println("-----------------------------------------------------------------------");
		int choice = scanner.nextInt();
		switch (choice) 
		{
		case 1:
			student.StudentScreen();
			break;
		case 2:
			examiner.ExaminerloginScreen();
			break;
		case 3:
			
			break;

		default:
			break;
		}
	}
}
