
public class Question 
{
	   private int questionId ;
	private String Question  ; 
	private String  Option_a ;
	private String  Option_b ;
	private String  Option_c ;
	private String  Option_d ;
	
	private String  ans;
	
	public Question(int questionId, String question, String option_a, String option_b, String option_c, String option_d,
			String ans) {
		super();
		this.questionId = questionId;
		Question = question;
		Option_a = option_a;
		Option_b = option_b;
		Option_c = option_c;
		Option_d = option_d;
		this.ans = ans;
	}
	public int getQuestionId() {
		return questionId;
	}
	public void setQuestionId(int questionId) {
		this.questionId = questionId;
	}
	public String getQuestion() {
		return Question;
	}
	public void setQuestion(String question) {
		Question = question;
	}
	public String getOption_a() {
		return Option_a;
	}
	public void setOption_a(String option_a) {
		Option_a = option_a;
	}
	public String getOption_b() {
		return Option_b;
	}
	public void setOption_b(String option_b) {
		Option_b = option_b;
	}
	public String getOption_c() {
		return Option_c;
	}
	public void setOption_c(String option_c) {
		Option_c = option_c;
	}
	public String getOption_d() {
		return Option_d;
	}
	public void setOption_d(String option_d) {
		Option_d = option_d;
	}
	public String getAns() {
		return ans;
	}
	public void setAns(String ans) {
		this.ans = ans;
	}
	 	
}
