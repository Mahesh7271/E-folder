
public class Admin
{
	private int    adminId;
	private String adminName;
	private String Admin_password;
	public Admin(int adminId, String adminName, String admin_password) {
		this.adminId = adminId;
		this.adminName = adminName;
		Admin_password = admin_password;
	}
	public int getAdminId() {
		return adminId;
	}
	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}
	public String getAdminName() {
		return adminName;
	}
	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}
	public String getAdmin_password() {
		return Admin_password;
	}
	public void setAdmin_password(String admin_password) {
		Admin_password = admin_password;
	}
	
}
