
public class Ans 
{
	private String n1;

	public Ans(String n1) {
		super();
		this.n1 = n1;
	}

	public String getN1() {
		return n1;
	}

	public void setN1(String n1) {
		this.n1 = n1;
	}
	
}
