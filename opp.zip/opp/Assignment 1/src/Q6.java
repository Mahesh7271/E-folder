import java.util.Scanner;
public class Q6 
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("\n enter a string");
		String rev=sc.next();
		rev.length();
		System.out.println("length:"+rev.length());
		rev.toUpperCase();
		int len= rev.length();
		System.out.println("upper case :"+rev.toUpperCase());
		String revs = "";
		for (int i = len-1; i >=0; i--) 
		{
			revs = revs+rev.charAt(i);
		}
			if(rev.equals(revs))
			{
				System.out.println("String is Palindrome");
			}
			else
				{
				System.out.println("String is NOT Palindrome");
				}
		}

}
