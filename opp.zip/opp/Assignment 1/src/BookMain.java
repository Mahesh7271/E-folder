/*Create a class Book which describes its Book_title and Book_price. Use getter and setter methods to get & set the Books description. 

Implement createBooks and showBooks methods to create n objects of Book in an array.  Display the books along with its description as follows:-

Book Title			Price
	Java Programming		Rs.350.50
	Let Us C			Rs.200.00

Note: createBooks & showBooks should not be member functions of Book class.

*/
public class BookMain 
{
public static void main(String[] args)
{
Bookinfo b = new Bookinfo();
Book[] book1 =b.create();
b.Display(book1);
}
}
