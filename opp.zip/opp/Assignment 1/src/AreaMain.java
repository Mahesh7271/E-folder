import java.util.Scanner;
//Define a class Rectangle with its length and breadth. 

public class AreaMain {

	public static void main(String[] args) 
	{
		float r ,h,b;
		Scanner sc = new Scanner(System.in);
		do {
			Area a=new Area();
			System.out.println("***************************************************");
			System.out.println("\n how many number to calculate  area of rectangle:");
			int number= sc.nextInt();

			for (int i = 0; i < number; i++)
			{
				System.out.println("\n enter base and height :");
				b= sc.nextFloat();
				h= sc.nextFloat();
			a.rectangle(h,b);
			}
		
			System.out.println("do you want to continue press  1");
		} while (1==sc.nextInt());
			System.out.println("*********************thank you*********************");
			
	}

}
