import java.util.Scanner;

public class q7 
{
	public static void main(String[] args) 
	{
	Scanner sc = new Scanner(System.in);
	System.out.println("\n Enter any to number");
	int number = sc.nextInt();
	int number1 = sc.nextInt();
	int ans1=number;
	int ans=0;
	System.out.print(ans1+"\t"+number1+"\t");
	for (int i = 0; i < 13; i++)
	{
	ans=ans1+number1;//1+3
	ans1=number1;//3
	number1=ans;//4
	System.out.print(ans+"\t");
	}
	
	}
	

}
