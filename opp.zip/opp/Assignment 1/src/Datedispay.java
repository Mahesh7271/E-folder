import java.text.ParseException;
import java.text.SimpleDateFormat;

public class Datedispay 
{
	public static void main(String[] args) throws ParseException 
	{
		System.out.println(java.time.LocalDate.now());
	}

	}
