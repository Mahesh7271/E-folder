
public class Q5 
{
	public static void main(String[] args) 
	{
	Date date[] =new Date[5];
	date[0] =new Date(100,"Mahesh");
	date[1] =new Date(100,"Mahesh");
	date[2] =new Date(100,"Mahesh");
	date[3] =new Date(100,"Mahesh");
	date[4] =new Date(100,"Mahesh");
	
	for (int i = 0; i < date.length; i++) 
	{
		System.out.println("Employee Number       : "+date[i].getEmp_Number());	
		System.out.println("Employee Name         : "+date[i].getEmp_name());	
		System.out.println("Employee Joining date : "+java.time.LocalDate.now());
	}
	
	}

}
