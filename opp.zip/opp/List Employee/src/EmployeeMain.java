import java.util.List;
import java.util.Scanner;

public class EmployeeMain 
{
	public static void main(String[] args) 
	{
		Scanner  scanner = new Scanner(System.in);
		int ch;
		EmployeeInfp employeeInfp  = new EmployeeInfp();
		List<Employee> list=null;
		int empId;
		do {
			System.out.println("\n1---Create Employee list"
					         + "\n2---Display Employee list"
					         + "\n3---Search Employee in list"
					         + "\n4---Delete Employee in list"
					         + "\n5---Set operation Employee in list");
			ch = scanner.nextInt();
			switch (ch) 
			{
			case 1:
				list=employeeInfp.create();
				break;
			case 2:
				employeeInfp.displayList(list);
				break;
			case 3:
				System.out.println("Enter your Employee Id to Search");
				 empId = scanner.nextInt();
				employeeInfp.searchObject(list, empId);
				break;
			case 4:
				System.out.println("Enter your Employee Id to Delete");
				empId = scanner.nextInt();
				employeeInfp.delete(list, empId);
				
				break;
			case 5:
				System.out.println("Enter your Employee Id to Search");
				empId = scanner.nextInt();	
				System.out.print("\n1---Change Id"
								+"\n2---Change Name"
								+"\n3---Change Salary");
				System.out.println("Enter your chioce");
				ch=scanner.nextInt();
				switch (ch) {
				case 1:
					employeeInfp.setOprationID(list, empId);
					break;
				case 2:
					employeeInfp.setOprationNAME(list, empId);
					break;
				case 3:
					employeeInfp.setOprationSALARY(list, empId);
					break;

				default:
					System.out.println("Invalied choice");
					break;
				}
				employeeInfp.setOprationID(list, empId);
				break;
//search display
			default:
				System.out.println("Invalied choice");
				break;
			}
			
			System.out.println("DO you want to continue press 1");
		} while (scanner.nextInt()==1);
	}

}
