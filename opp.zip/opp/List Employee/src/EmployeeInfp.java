import java.util.*;
import java.util.ArrayList;
public class EmployeeInfp 
{
	Scanner scanner = new Scanner(System.in);
	public List<Employee> create()
	{
		 int empId;
		 String empName;
		 double empSalary;
		int ch;
		List<Employee> list=new ArrayList<Employee>();
		do 
		{
		System.out.println("Employee Id");
		empId = scanner.nextInt();
		System.out.println("Employee Name");
		empName = scanner.next();
		System.out.println("Employee Salary");
		empSalary = scanner.nextDouble();
		Employee employee = new Employee(empId, empName, empSalary);	
		list.add(employee);
			System.out.println("DO YOU WANT TO ADD ANY OTHER EMPLOYEE IMFORMATION IN LIST PRESS 1");
		} 
		while (scanner.nextInt()==1);
		return list;		
	}
	
	public void  displayList(List<Employee> list) 
	{
		for (Employee e : list)
		{
			System.out.println("Employee Id\tEmployee Name\tEmployee Salary");
			System.out.println("\t"+e.getEmpId()+"\t"+e.getEmpName()+"\t\t"+e.getEmpSalary());
		}
	}
	public Employee searchObject(List<Employee> list, int EmpId )
	{
		Employee employee =null;
		
		for (Employee e : list)
		{
			if (e.getEmpId()==EmpId)
			{
				employee= e;
				System.out.println("Data is Found");
			}
		}
		return employee;
	}
	public void delete(List<Employee> list,int EmpId)
	{
		Employee empTemp = searchObject(list, EmpId);
		for (Employee e : list) {
		if (empTemp!=null)
		{
			list.remove(empTemp);
			System.out.println("Data is Removed....");
				
		}
		else
		System.out.println("Enter your Correct Account deteils");
		}
	}
	public void setOprationID(List<Employee> list,int EmpId)
	{
		Employee empTemp = searchObject(list, EmpId);
		System.out.println("Enter your id");
		int id =scanner.nextInt();
		for (Employee e : list) {
		if (empTemp!=null)
		empTemp.setEmpId(id);	
		else
		System.out.println("Enter your Correct Account deteils");
		}
	
	}
	public void setOprationNAME(List<Employee> list,int EmpId)
	{
		Employee empTemp = searchObject(list, EmpId);
		System.out.println("Enter your name");
		String id =scanner.next();
		for (Employee e : list) {
		if (empTemp!=null)
		empTemp.setEmpName(id);
		else
		System.out.println("Enter your Correct Account deteils");
		}
	
	}
	public void setOprationSALARY(List<Employee> list,int EmpId)
	{
		Employee empTemp = searchObject(list, EmpId);
		System.out.println("Enter your Salary");
		double id =scanner.nextDouble();
		for (Employee e : list) {
		if (empTemp!=null)
		empTemp.setEmpSalary(id);	
		else
		System.out.println("Enter your Correct Account deteils");
		}
	
	}

}
