import java.util.Scanner;

public class CurrencyConvarterMain 
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		Convter a[] = new Convter[7]; 
		a[0] = new dollar();
		a[1] = new Pound();
		a[2] = new Euro();
		a[3] = new HKD();
		a[4] = new CD();
		a[5] = new Bt();
		a[6] = new IDR();
		do
		{
			System.out.println("============================================================================================");
			System.out.println("  [    1  :-->  Indian to dollar           |<>|    11  :-->  dollar To Indian              ]\n "
							 + " [    2  :-->  Indian to Pound            |<>|    12  :-->  Pound To Indian               ]\n "
							 + " [    3  :-->  Indian to Euro             |<>|    13  :-->  Euro  To Indian               ]\n "
							 + " [    4  :-->  Indian to Hong Kong Dollar |<>|    14  :-->  Hong Kong Dollar To Indian    ]\n "
							 + " [    5  :-->  Indian to Canadian Dollar  |<>|    15  :-->  Canadian Dollar To Indian     ]\n "
							 + " [    6  :--> Indian to Bangladeshi taka  |<>|    16  :-->  Bangladeshi taka To Indian    ]\n "
							 + " [    7  :--> Indian to Indonesian Rupiah |<>|    17  :-->  Indonesian Rupiahndian        ]" );
					
			System.out.print  ("===========================================================================================\n");
			System.out.println("        Enter your choice              ");
			int choice = sc.nextInt();
			System.out.println("Enter your Amount to be check Convert currency");
			float amount = sc.nextFloat();
			switch (choice) 
			{
			case 1:
				a[0].indianToany(amount);;
				break;
			case 2:
				a[1].indianToany(amount);;
				break;
			case 3:
				a[2].indianToany(amount);
				break;
			case 4:
				a[3].indianToany(amount);
				break;
			case 5:
				a[4].indianToany(amount);
				break;
			case 6:
				a[5].indianToany(amount);
				break;
			case 7:
				a[6].indianToany(amount);
				break;
			case 11:
				a[0].anyToindian(amount);;
				break;
			case 12:
				a[1].anyToindian(amount);;
				break;
			case 13:
				a[2].anyToindian(amount);
				break;
			case 14:
				a[3].anyToindian(amount);
				break;
			case 15:
				a[4].anyToindian(amount);
				break;
			case 16:
				a[5].anyToindian(amount);
				break;
			case 17:
				a[6].anyToindian(amount);
				break;
			
			default:
				System.out.println("-------------------------invalied choice------------------------");
				break;
			}
			System.out.println("============================================================================================");
		} while (1==1);
	}
}
