
public class Convter 
{
	public void indianToany(float amount)
	{
		
	}
	public void anyToindian(float amount)
	{
		
	}

}
