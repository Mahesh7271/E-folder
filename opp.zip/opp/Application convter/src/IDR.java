public class IDR extends Convter
{
	@Override
	public void indianToany(float amount)
	{
		float co = (float) (amount*193.9714);
		System.out.println("Your Amount To Indonesian Rupiha   :-->  "+co);
	}
	@Override
	public void anyToindian(float amount) 
	{
		float co = (float) (amount*0.0052);
		System.out.println("Your Amount To Indian Rupee   :-->  "+co);
	}
}
