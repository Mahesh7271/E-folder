public class Euro extends Convter
{

	@Override
	public void indianToany(float amount)
	{
		float co = (float) (amount*0.0116);
		System.out.println("Your Amount To Euro  :-->  " +co );
	
	}

	@Override
	public void anyToindian(float amount) 
	{
		float co = (float) (amount*86.31);
		System.out.println("Your Amount To Indian Rupee   :-->  "+co);
	}
	
}
