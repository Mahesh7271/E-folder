public class Pound extends Convter
{

	
	@Override
	public void indianToany(float amount) 
	{
		float co = (float) (amount*0.0099);
		System.out.println("Your Amount To British Pound   :-->  "+co);
		
	}

	@Override
	public void anyToindian(float amount) 
	{
		float co = (float) (amount*100.617);
		System.out.println("Your Amount To Indian Rupee   :-->  "+co);
	}
}
