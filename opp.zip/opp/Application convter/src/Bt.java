public class Bt extends Convter
{
	@Override
	public void indianToany(float amount) 
	{
		float co = (float) (amount*1.1604);
		System.out.println("Your Amount To Bangladeshi Taka :-->  " +co );	
	}
	@Override
	public void anyToindian(float amount) 
	{
		float co = (float) (amount*0.8618);
		System.out.println("Your Amount To Indian Rupee   :-->  "+co);
	}
}
