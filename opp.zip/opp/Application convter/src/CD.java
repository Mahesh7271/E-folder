
public class CD extends Convter
{
	@Override
	public void indianToany(float amount) 
	{
		float co = (float) (amount*0.0172);
		System.out.println("your Amount To Canadian doller  :-->  " +co );
	
	}
	@Override
	public void anyToindian(float amount) 
	{
		float co = (float) (amount*58.1528);
		System.out.println("Your Amount To Indian Rupee   :-->  "+co);
	}
}
