public class HKD extends Convter
{
	@Override
	public void indianToany(float amount)
	{
		float co = (float) (amount*0.1057);
		System.out.println("your Amount To Hong Kong Dollar  :-->  " +co );
	
	}
	@Override
	public void anyToindian(float amount) 
	{
		float co = (float) (amount*9.4607);
		System.out.println("Your Amount To Indian Rupee   :-->  "+co);
	}
}
