
public class dollar extends Convter 
{
	@Override
	public void indianToany(float amount) 
	{
		float co = (float) (amount*0.0136);
		System.out.println("To United States Doller amount :-->  " +co );
	}
	@Override
	public void anyToindian(float amount) 
	{
		float co = (float) (amount*73.6475);
		System.out.println("To Indian Rupee  amount  :-->  "+co);
	}
	
}
