public class Devloper  extends Employee
{
	private int nofhr;

	public int getNofhr() {
		return nofhr;
	}

	public void setNofhr(int nofhr) {
		this.nofhr = nofhr;
	}

	public Devloper(int empId, String empName, double empSalary, int nofhr) {
		super(empId, empName, empSalary);
		this.nofhr = nofhr;
	}

	@Override
	public String toString() {
		return "Devloper [getNofhr()=" + getNofhr() + ", getEmpId()=" + getEmpId() + ", getEmpName()=" + getEmpName()
				+ ", getEmpSalary()=" + getEmpSalary() + "]";
	}

	/*@Override
	public String toString() 
	{
		// TODO Auto-generated method stub
		return getEmpId()+"\t"+getEmpName()+"\t"+getEmpSalary()+"\t"+getNofhr();
	}*/
	
	
}
