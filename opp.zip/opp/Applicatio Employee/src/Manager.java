public class Manager extends Employee
{
	private double bons;

	public Manager(int empId, String empName, double empSalary, double bons) {
		super(empId, empName, bons);
		this.bons = bons;
	}

	public double getBons() {
		return bons;
	}

	public void setBons(double bons) {
		this.bons = bons;
	}
	@Override
	public String toString() {
		return "Manager [getBons()=" + getBons() + ", getEmpId()=" + getEmpId() + ", getEmpName()=" + getEmpName()
				+ ", getEmpSalary()=" + getEmpSalary() + "]";
	}
	@Override
	public boolean equals(Object obj) 
	{
		Manager m=(Manager)obj;
		System.out.println(m.getEmpName()+" Compare with " +this.getEmpName());
		if ((this.getEmpId()==m.getEmpId()) && (this.getEmpName()==m.getEmpName()) )
		{
			return true;
		}
		return false;
	}

	/*@Override
	public String toString() {
		// TODO Auto-generated method stub
		return getEmpId()+"\t"+getEmpName()+"\t"+getEmpSalary()+"\t"+getBons();
	}*/
	
	
}
