public class EmployeeMain 
{
	public static void main(String[] args) 
	{
		// pass the array 5 manager
	
		Manager managerobj =new Manager(1001, "Prtik", 70000, 5000);
		Manager managerobj1 =new Manager(1001, "Prtik", 70000, 5000);
		Devloper devogj= new Devloper(1002, "Mahesh", 70000, 20);
		Manager m =managerobj;
		if (managerobj==managerobj1)
			{
			System.out.println("same");	
			}
		if (managerobj.equals(m))
			{
			System.out.println("object are Same");	
			}
		else 
			System.out.println("different");
			
		display(managerobj,"Manager");
		display(devogj,"Devloper");
	
	}
	public static void display(Employee eogj,String str)
	{
		System.out.println(eogj);
		System.out.println(str+" Id :"+eogj.getEmpId());
		System.out.println(str+" Name :"+eogj.getEmpName());
		System.out.println(str+" Salary :"+eogj.getEmpSalary());
		if (eogj instanceof Manager)
		{
			Manager m = (Manager)eogj;
			System.out.println(str+" Bonus :"+m.getBons());
		}
		if (eogj instanceof Devloper)
		{
			Devloper d = (Devloper)eogj;
			System.out.println(str+" No of Hours:"+d.getNofhr());
		}
		
	}
}
