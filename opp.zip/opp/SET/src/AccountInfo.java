import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class AccountInfo {

	public Map<String,Account> create()
	{
		Map<String,Account> carmap = new TreeMap<String,Account>();
		carmap.put("100", new Account(100, "Mahesh", 120000));																			
		carmap.put("101   ", new Account(120, "Prtik", 2500000));
		carmap.put("102  ", new Account(105, "Abhi", 120500));
		carmap.put("103  ", new Account(5, "rahul", 451321));
		return carmap;
		
	}
	public void Display(Map<String,Account> carmap)
	{Set<String> carset =  carmap.keySet();
	Iterator<String>  itr = carset.iterator();
	while (itr.hasNext()) {
		String string = (String) itr.next();
		Account acc = carmap.get(string);
		System.out.println(string+"\t"+acc.getAcc_No()+"\t"+acc.getAcc_Name()+"\t"+acc.getAcc_balance());
		
	}
	System.out.println(carmap);
	}
}
