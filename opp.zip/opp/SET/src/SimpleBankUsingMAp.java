import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class SimpleBankUsingMAp {

	public static void main(String[] args) {
		AccountInfo accountInfo = new AccountInfo();
		
		Map<String,Account> carmap = accountInfo.create();
		accountInfo.Display(carmap);

	}

}
