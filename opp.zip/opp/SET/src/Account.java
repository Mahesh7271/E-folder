public class Account 
{
	private int Acc_No;
	private String Acc_Name;
	private double Acc_balance;
	public Account(int acc_No, String acc_Name, double acc_balance) {
		super();
		Acc_No = acc_No;
		Acc_Name = acc_Name;
		Acc_balance = acc_balance;
	}
	public int getAcc_No() {
		return Acc_No;
	}
	public void setAcc_No(int acc_No) {
		Acc_No = acc_No;
	}
	public String getAcc_Name() {
		return Acc_Name;
	}
	public void setAcc_Name(String acc_Name) {
		Acc_Name = acc_Name;
	}
	public double getAcc_balance() {
		return Acc_balance;
	}
	public void setAcc_balance(double acc_balance) {
		Acc_balance = acc_balance;
	}
}
 