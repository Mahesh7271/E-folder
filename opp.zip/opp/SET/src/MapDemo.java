import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
public class MapDemo {
	public static void main(String[] args)
	{
		
		Map<String,Integer> carmap = new TreeMap<String,Integer>();
		carmap.put("Maruti", 800000);
		carmap.put("Bmw   ", 800000);
		carmap.put("tata  ", 800000);
		carmap.put("audi  ", 800000);
		carmap.put("ford  ", 800000);
		System.out.println(carmap);
		System.out.println(carmap.get("tata"));
		if (carmap.containsKey("tata"))
			System.out.println(carmap.get("tata"));
		carmap.remove("tata");
		System.out.println(carmap);
		System.out.println(carmap);
		Set<String> carset =  carmap.keySet();
		System.out.println(carset);
				
		Iterator<String>  itr = carset.iterator();
	
		while (itr.hasNext()) {
			String string = (String) itr.next();
			System.out.println("for key " +string+"values"+carmap.get(string));
			
		}
	}

}
