import java.util.Set;
import java.util.TreeSet;

public class Employee_info 
{
	public Set<Employee> create()
	{
		Employee e1 =new Employee(1001,	"Rahul", 100000);
		Employee e2 =new Employee(1002,	"Rahul", 100000);
		Employee e3 =new Employee(1003,	"Rahul", 100000);
		Employee e4 =new Employee(1004,	"Rahul", 100000);
		Set<Employee> empset = new TreeSet<Employee>(); 
		
		empset.add(e1);
		empset.add(e2);
		empset.add(e3);
		empset.add(e4);
		return empset;
		
	}
	public void Display(Set<Employee> e) 
	{
		for (Employee employee : e) {
			System.out.println("Employee ID \tEmployee Name \tEmployee Salary");
			System.out.println(+employee.getE_id()+"\t\t"+employee.getE_name()+"\t\t"+employee.getE_salary());
				}
	}
}
