

import java.util.Set;
public class set 
{
	public static void main(String[] args) 
	{
	
		Employee_info employee_info =  new  Employee_info();
		Set<Employee> e =employee_info.create();
		employee_info.Display(e);
	}
}
