interface Compartment
{
	default void Display()
	{
		
	}
}
