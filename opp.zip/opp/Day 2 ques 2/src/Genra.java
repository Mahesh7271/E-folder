
public class Genra  implements Compartment
{

	@Override
	public void Display() {
		System.out.println("--------This is General Coach---------");
	}

}
