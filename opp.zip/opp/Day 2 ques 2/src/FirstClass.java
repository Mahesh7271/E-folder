
public class FirstClass implements Compartment
{

	@Override
	public void Display()
	{
		System.out.println("--------This is FirstClass Coach--------");
	}
	
}
