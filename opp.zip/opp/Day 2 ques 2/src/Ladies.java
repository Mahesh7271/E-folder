
public class Ladies implements Compartment{

	@Override
	public void Display() {
	System.out.println("----------This is ladies coach-----------");
	}
	
}
