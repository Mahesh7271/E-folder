
public class Sportcar extends Car
{
	protected int AirBaloonType;
	public Sportcar(int speed, int noOfGear, int airBaloonType) 
	{
		super(speed, noOfGear);
		AirBaloonType = airBaloonType;
	}
	@Override
	public void Display() 
	{
		System.out.println("Sportcar AirBaloonType = "+AirBaloonType+"\nspeed is ="+speed+ "\nNumber Of Gear=" + noOfGear);
	}
}
