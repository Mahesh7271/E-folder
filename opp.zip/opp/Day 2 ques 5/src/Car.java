public class Car 
{
	protected int speed;
	protected int noOfGear;
	public Car(int speed, int noOfGear) {
		this.speed = speed;
		this.noOfGear = noOfGear;
	}
	public void drive()  
	{
	speed =5;
	noOfGear=3;
	}
	public int getSpeed() {
		return speed;
	}
	public void setSpeed(int n) {
		this.speed = n;
	}
	public int getNoOfGear() {
		return noOfGear;
	}
	public void setNoOfGear(int noOfGear) {
		this.noOfGear = noOfGear;
	}
	public void Display()
	{
	System.out.println("speed="+this.speed+": # of Gear = "+this.noOfGear);	
	}

}
