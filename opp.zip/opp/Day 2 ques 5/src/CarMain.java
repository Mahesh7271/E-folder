public class CarMain 
{
	public static void main(String[] args) 
	{
		Sportcar sp = new  Sportcar(10, 50, 3);
		sp.Display();
	}

}
