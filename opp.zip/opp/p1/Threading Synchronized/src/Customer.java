
public class Customer extends Thread
{
	private  Shopping shopping;

	public Customer(Shopping shopping) 
	{
		this.shopping = shopping;
	}
	@Override
	public void run() 
	{
		
			for (int i = 0; i < 4; i++) 
			{
				shopping.SaveData("Customer");
				}
			}
		
}
