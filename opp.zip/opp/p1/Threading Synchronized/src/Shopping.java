
public class Shopping 
{

	public void  SaveData(String string)
	{
		System.out.println(string+"\tsave data");
		
	}
	/*public void displayData(String string)
	{
	System.out.println(string+"\tDisplay data");	
	}*/
}
