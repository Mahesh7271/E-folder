
public class Admin extends Thread 
{
	private Shopping s;
	
	public Admin(Shopping s)
	{
		this.s = s;
	}

	public void run() 
	{
		synchronized (s)
		{
			s.SaveData("admin");
		}
	}
}
