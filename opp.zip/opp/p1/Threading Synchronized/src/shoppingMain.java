
public class shoppingMain
{
	public static void main(String[] args) 
	{
		Shopping shopping = new Shopping();
		Customer customer = new Customer(shopping);
		Admin admin = new Admin(shopping);
		
		System.out.println("Customer thread is :\t"+customer.isAlive());
		System.out.println("   Admin thread is :\t"+admin.isAlive());
		customer.start();
		System.out.println("Customer thread is :\t"+customer.isAlive());
		System.out.println("   Admin thread is :\t"+admin.isAlive());
		try {
			customer.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println("Customer thread is :\t"+customer.isAlive());
		System.out.println("   Admin thread is :\t"+admin.isAlive());
		admin.start();
		System.out.println("Customer thread is :\t"+customer.isAlive());
		System.out.println("   Admin thread is :\t"+admin.isAlive());
		
		try {
			admin.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Customer thread is :\t"+customer.isAlive());
		System.out.println("   Admin thread is :\t"+admin.isAlive());
	}


}
