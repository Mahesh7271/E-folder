
public class TestInner 
{
	public static void main(String[] args)
	{
		DataReadWrite  d =new DataReadWrite(); 
		Consumer consumer = new Consumer(d);
		Producer producer =new Producer(d);
		producer.start();
		consumer.start();
		System.out.println(consumer.isAlive());
		System.out.println(producer.isAlive());
		System.out.println("Thanks");
	}
}
