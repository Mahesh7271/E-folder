
public class Consumer extends Thread
{
		int n=1;
	private DataReadWrite dataReadWrite;

	
	public Consumer(DataReadWrite dataReadWrite) {
		this.dataReadWrite = dataReadWrite;
	}


	public void run() 
	{
		synchronized (dataReadWrite) 
		{
			while (true)
			{
				dataReadWrite.getData();
			}
		}
	}
}
