
public class Producer extends Thread
{
	int n=1;
	private DataReadWrite dataReadWrite;

	public Producer(DataReadWrite dataReadWrite) 
	{
		this.dataReadWrite = dataReadWrite;
	}
	public void run()
	{
		synchronized (dataReadWrite) 
		{
			while (true)
			{
				dataReadWrite.putData(n++);
			}
			/*
			 * Register 600 open
			 * 10 deploma marksheeet
			 *  lc deploma lc
			 *  last year marksheet 
			 *  cast certicate
			 *  3 year income
			 *  non-creminal /
			 * cast vaLIDITY
			 * 600
			 * */
		}
	}
	
}
