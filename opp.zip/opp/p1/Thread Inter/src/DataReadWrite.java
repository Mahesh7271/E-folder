
public class DataReadWrite 
{
	int Number;
	boolean b = false;
	public void putData(int n)
	{
		if (b)
		{
			try 
			{
				wait();
			} catch (Exception e) 
			{
				e.printStackTrace();
			}
			this.Number = n;
			System.out.println("Putdata value Product"+n);
			b=true;
			notify();
		}
	}
	public void getData()
	{
		if (b==false)
		{
			try 
			{
				wait();
			} catch (Exception e) 
			{
				e.printStackTrace();
			}
			b=false;
			System.out.println("value consume"+Number);
			notifyAll();
		}
	}
}
