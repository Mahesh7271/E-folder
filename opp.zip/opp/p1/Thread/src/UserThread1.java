
public class UserThread1
{

	String arr[];
	int sum=0;
	public  UserThread1(String[] arr) 
	{
	this.arr=arr;
	}
	public void  run()
	{
	addition();	
	}
	public void addition()
	{
		for (int i = arr.length-1 ; i>=0; i--)
		{
		System.out.println(arr[i]);
		sum=sum+Integer.parseInt(arr[i]);
		}
	}
	public void start() {
		// TODO Auto-generated method stub
		
	}
}

