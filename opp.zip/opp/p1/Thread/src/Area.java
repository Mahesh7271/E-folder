
public class Area extends Thread
{
	float r;
	public  Area (float r) 
	{
		this.r = r;
	}
	public void  run()
	{
	 area();
	}
	public float  area()
	{
		float area = (float) (3.14*r*r);
		return area;
		
	}
	}

