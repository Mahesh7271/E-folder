import java.util.Scanner;

public class Areathread extends Thread
{
	private Area cal;
	private Area1 cal1;

	public Areathread(Area cal ,Area1 cal1) 
	{
		this.cal = cal;
		this.cal1 = cal1;
		
		new Thread(this).start(); 
	}
	public void  run()
	{
		Scanner sc =new Scanner(System.in);

			System.out.println("\n 1 -- Area of circle   "
							 + "\n 2 -- Area of Ractangle");
			System.out.println("\n Enter your choice");
			int ch =sc.nextInt();
		switch (ch) 
		{
			case 1:
				System.out.println("Area of circle "+cal.area());	
					break;
			case 2:
				System.out.println("Area of Ractangle "+cal1.area());	
				break;
			default:
				System.out.println("Invalid option ");
				break;
		}

	}
}
