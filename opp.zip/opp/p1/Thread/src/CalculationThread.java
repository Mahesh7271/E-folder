import java.util.Scanner;

public class CalculationThread implements Runnable
{
	private Calculation cal;

	public CalculationThread(Calculation cal) {
		super();
		this.cal = cal;
		new Thread(this).start(); 
	}
	public void  run()
	{
		Scanner sc =new Scanner(System.in);
			System.out.println("\n 1 -- Add "
							 + "\n 2 -- Sub "
							 + "\n 3 -- Mul "
							 + "\n 4 -- Div ");
			System.out.println("\n Enter your choice");
			int ch =sc.nextInt();
			try
			{
				Thread.sleep(3000);
			} 
			catch (InterruptedException e)
			{
				e.printStackTrace();
			}
		switch (ch) 
		{
			case 1:
				try
				{
					Thread.sleep(3000);
				} 
				catch (InterruptedException e)
				{
					e.printStackTrace();
				}
				System.out.println("Addtion is "+cal.getsum());	
					break;
			case 2:
				try
				{
					Thread.sleep(3000);
				} 
				catch (InterruptedException e)
				{
					e.printStackTrace();
				}
				System.out.println("Subtraction is "+cal.getsub());	
				break;
			case 3:
				try
				{
					Thread.sleep(3000);
				} 
				catch (InterruptedException e)
				{
					e.printStackTrace();
				}
				System.out.println("multiplication is "+cal.getMul());	
				break;
			case 4:
				try
				{
					Thread.sleep(3000);
				} 
				catch (InterruptedException e)
				{
					e.printStackTrace();
				}
				System.out.println("Divistion "+cal.getdiv());	
				break;
			
			default:
				System.out.println("Invalid option ");
				break;
		}
	}
}
