
public class Thrading {

	public static void main(String[] args) {
		UserThread thread1= new UserThread(10, 20);
		UserThread thread2= new UserThread(100, 200);
		thread1.setName("User1");
		thread1.start();
		thread2.start();
		System.out.println("thank you");
		for (int i = 1; i < 5; i++) {
			System.out.print("\n"+i);
		}

		UserThread1 thread3= new UserThread1(args);
		System.out.println();
		thread3.run();
	}

}
