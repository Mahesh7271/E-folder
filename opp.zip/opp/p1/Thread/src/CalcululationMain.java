import java.util.Scanner;

public class CalcululationMain 
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
			
			System.out.println("\n 1 for Arithmatic operation"
							 + "\n 2 for Area Calcutaion     ");
			System.out.println("Enter your choice  ");
			int ch =sc.nextInt();
			switch (ch) 
			{
			case 1:
				System.out.println("Enter any two Number ");
				int n1=sc.nextInt();
				int n2=sc.nextInt();
				Calculation calculation = new Calculation(n1, n2);
				CalculationThread calculationThread = new CalculationThread(calculation);
				Thread t=new  Thread(calculationThread);
				t.start();
				try 
				{
					Thread.sleep(1000);
				}
				catch (InterruptedException e) {
					e.printStackTrace();
				}
												
				break;
			
			case 2:
				Area area = new Area(10);
				Area1 area1 = new Area1(10,45);
				Areathread areathread = new Areathread(area, area1);
				areathread.start();
									
				break;

			default:
				break;
			}
		}

}
