public class Dmeo extends Thread
{
	String str;
	public Dmeo(String str) 
	{
		this.str = str;
	}
	public void  run()
	{
		for (int i = 0; i <= 5; i++)
		{
			System.out.println(str +"\t"+i);
			try 
			{
				Thread.sleep(3000);
			}
			catch (InterruptedException e)
			{
				e.getStackTrace();
			}
		}
	}
}
