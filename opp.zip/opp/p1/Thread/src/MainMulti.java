
public class MainMulti {

	public static void main(String[] args)
	{
		Area a =new Area(10);
		Area1 a1 = new Area1(10, 20);
		/*
		Dmeo d = new Dmeo("java");
		Dmeo d1 = new Dmeo("python");
		*/
		System.out.println(a);
		System.out.println(a1);
		
		System.out.println(a.isAlive());
		System.out.println(a1.isAlive());

		a.start();
		a1.start();

		System.out.println(a.isAlive());
		System.out.println(a1.isAlive());
		for (int i = 0; i < 5; i++)
		{
			System.out.println(i);
			
		}
	}
	

}
