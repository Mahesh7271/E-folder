
public class Area1 extends Thread
{
	float b;
	float h;
	public  Area1 (float b ,float h) 
	{
		this.b = b;
		this.h = h;
			
	}
	public void  run()
	{
	}
	public float area() 
	{
		float area = (float) (b*h);
		System.out.println( "Area is"+area);
	
		return area;
		
	}
	}


