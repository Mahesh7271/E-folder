import java.util.Scanner;
public class toWord 
{
	public static void main(String[] args)
	{
		Scanner scanner =new Scanner(System.in);
		do
		{
			System.out.println("Enter Number");
			String string = scanner.next();
			if (string.length() == 0)   
			{  
				System.out.println("The string is empty.");  
				return;  
			}  
			if (string.length()<10)
			{
				int num=Integer.parseInt(string);
				System.out.println(convert(num));
			}
			else
				System.out.println("\n The given number has more than 10 digits.");  
			System.out.println("--------------------------| 1 |--------------------------");
		} while (1==1);
	}
	static  String convert(int num)
	{
		String str="";
		if (num<100) 
			str = fun(num);
		else if (num>=100  && num<1000)//hun
			str=fun(num/100)+" Hundread " + convert(num%100);
		else if (num>=1000  && num<100000)//t
			str=fun(num/1000)+" Thousand " + convert(num%1000);
		else if (num>=100000  && num<10000000)//l
			str=fun(num/100000)+" Lakh " + convert(num%100000);
		else if (num>=10000000  && num<1000000000)//c
			str=fun(num/10000000)+" Crore " + convert(num%10000000);
		return str;
	}
	static String fun(int num)
	{
	String str ="";
	String[] units = {" Zero ", " One " , " Two ", " Three ", " Four ", " Five ", 
			          " Six ", " Seven ", " Eight ", " Nine "," Ten ", " Eleven ",
			          " Twelve ", " Thirteen ", " Fourteen ", " Fifteen ", " Sixteen ",
			          " Seventeen ", " Eighteen ", " Nineteen "};
	String[] tens  = {" ",  " ", " Twenty ", " Thirty ", " Forty ", " Fifty ", " Sixty ", " Seventy ", " Eighty ", " Ninety "};
	
	if (num<20)
	{
		str=units[num];
		return str;
		}
	else if(num>=20 && num<100)
	{
		str=tens[num/10] + units[num%10];
	}
	return str;
	}

}
