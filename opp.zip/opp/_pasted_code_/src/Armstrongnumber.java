import java.util.Scanner;

public class Armstrongnumber {
	public static void main(String[] args) 
	{
		Scanner scanner= new Scanner(System.in);
		System.out.println("Enter your Number ");
		int number=scanner.nextInt();
		addtion(number);
			}
	static void addtion(int number) 
	{
		int rem=0;
		int result=0;
		int arr[] = null;
		int i=0;
		while (number!=0)
		{
			rem=number%10;
			result += rem*rem*rem;
			number /=10;
			arr[i]=rem;
			i++;
			System.out.println(+arr[i]);
		}

	}
}
