

public class test {
public static void main(String[] args) {
    String string = "hello how? are y**ou Akanksha-Mishra?";    
    int count = 0, spec = 0;
    for(int i = 0; i < string.length(); i++) {  
        if ((string.charAt(i)>64 && string.charAt(i)<=122) || string.charAt(i) == 32) 
        {    
            count++;
        }      
    }     
    spec = string.length() - count;
    System.out.println("Number of Special Characters: " + spec);    


}}
