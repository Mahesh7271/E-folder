import java.util.Scanner;

public class Solution {

	public static int  calculation(char[] product,char[] productId )
	{
		int count=0;
		for (int i = 0; i < product.length; i++) 
		{
			if (product[i]=='a'||product[i]=='u'||product[i]=='i'||product[i]=='o'||product[i]=='e'||product[i]=='A'||product[i]=='E'||product[i]=='I'||product[i]=='U'||product[i]=='O') 
				{
					break;
				}
			else
			{
				System.out.println(product[i]);
				count++;	
			}
			}
		
		return count;
		
	}
	public static void main(String[] args) 
	{
		
	Scanner scanner = new Scanner(System.in);
	char[] productID = {'a','i','e','o','u','A','I','E','O','U'};
	int size =scanner.nextInt();
	char[] product= new char[size];
		for (int i = 0; i < product.length; i++)
		{
			product[i] =scanner.next().charAt(0);
		}
		System.out.println(calculation(product, productID));
	}
}
