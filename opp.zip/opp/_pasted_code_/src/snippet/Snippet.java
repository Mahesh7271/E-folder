package snippet;

public class Snippet {
		private String city;
}

