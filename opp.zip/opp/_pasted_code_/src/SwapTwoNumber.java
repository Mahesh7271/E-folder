import java.util.Scanner;

public class SwapTwoNumber {
	public static void main(String[] args) {
		/**
		 * Scanner scanner = new Scanner(System.in);
		 **/
		int a = 20;
		int b = 30;
		System.out.println(a + "\t" + b);
		a = a + b;// 50
		b = a - b;
		a = a - b;
		System.out.println(a + "\t" + b);
	}
}
