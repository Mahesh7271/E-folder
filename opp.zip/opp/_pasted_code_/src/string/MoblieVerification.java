package string;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MoblieVerification {

	public static void main(String[] args) 
	{
		Scanner scanner = new Scanner(System.in);
		do 
		{
			System.out.println("Enter your Mobile number");
			String string = scanner.next();
			if (isVarification(string)) 
				System.out.println("Valid Mobile Number");
			else
				System.out.println("not valid");
	
		} while (1==1);
	}
	public static Boolean isVarification(String str) 
	{
		Pattern pattern = Pattern.compile("(0/91)?[7-9][0-9]{9}");
		Matcher matcher = pattern.matcher(str);
		return(matcher.find() && matcher.group().equals(str));
	}
}
