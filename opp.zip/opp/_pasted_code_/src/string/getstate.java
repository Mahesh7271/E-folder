package string;

import java.util.Scanner;

public class getstate 
{
	public static void main(String[] args)
	{
		
		Scanner scanner = new Scanner(System.in);
		do {
			System.out.println("Enter your state in 'mh'|or|'Mh 'and any");
			String string = scanner.next();
			char[] arr = getstate(string);
			String str = String.valueOf(arr);
			System.out.println(str);
	
		} while (1==1);
			}

	private static char[]  getstate(String str)
	{
		String name="";
		
		if(str.equals("Ap") || str.equals("AP") || str.equals("ap") || str.equals("aP"))
		{
			name = "Andhra Pradesh";
		}
		else if(str.equals("Ar") || str.equals("AR") || str.equals("aR") || str.equals("ar"))
		{
			name = "Arunachal Pradesh";
		}
		else if(str.equals("AS") || str.equals("As") || str.equals("aS") || str.equals("as"))
		{
			name = "Assam";
		}
		else if(str.equals("BR") || str.equals("Br") || str.equals("BR") || str.equals("br"))
		{
			name = "bihar";
		}
		else if(str.equals("CT") || str.equals("cT") || str.equals("Ct") || str.equals("ct"))
		{
			name = "Chhattisgarh";
		}
		else if(str.equals("Ga") || str.equals("GA") || str.equals("gA") || str.equals("ga"))
		{
			name = "Goa";
		}
		else if(str.equals("Gj") || str.equals("GJ") || str.equals("gJ") || str.equals("gj"))
		{
			name = "Gujrat";
		}
		else if(str.equals("HR") || str.equals("Hr") || str.equals("hR") || str.equals("hr"))
		{
			name = "Haryana";
		}
		else if(str.equals("hp") || str.equals("hP") || str.equals("Hp") || str.equals("HP"))
		{
			name = "Himachal Pradesh";
		}
		else if(str.equals("JK") || str.equals("Jk") || str.equals("jK") || str.equals("jk"))
		{
			name = "Jammu Amd Kashmir";
		}
		else if(str.equals("JH") || str.equals("Jh") || str.equals("jH") || str.equals("jh"))
		{
			name = "Jharkhand";
		}
		else if(str.equals("KL") || str.equals("Kl") || str.equals("kL") || str.equals("kl"))
		{
			name = "Kerala";
		}
		else if(str.equals("Mp") || str.equals("MP") || str.equals("mP") || str.equals("mp"))
		{
			name = "Madhya Pradesh";
		}
		else if(str.equals("mh") || str.equals("MH") || str.equals("Mh") || str.equals("mH")|| str.equals("maharashtra"))
		{
			name = "Maharashtra";
		}
		else if(str.equals("mn") || str.equals("Mn") || str.equals("mN") || str.equals("MN"))
		{
			name = "Manipur";
		}
		else if(str.equals("ml") || str.equals("Ml") || str.equals("mL") || str.equals("ML"))
		{
			name = "Meghalaya";
		}
		else if(str.equals("mz") || str.equals("mZ") || str.equals("Mz") || str.equals("MZ"))
		{
			name = "Mizoram";
		}
		else if(str.equals("Nl") || str.equals("nL") || str.equals("NL") || str.equals("nl"))
		{
			name = "Nagaland";
		}
		else if(str.equals("oR") || str.equals("Or") || str.equals("OR") || str.equals("or"))
		{
			name = "Orissa";
		}
		else if(str.equals("PB") || str.equals("pb") || str.equals("Pb") || str.equals("pB"))
		{
			name = "Punjab";
		}
		else if(str.equals("rJ") || str.equals("Rj") || str.equals("RJ") || str.equals("rj"))
		{
			name = "Rajasthan";
		}
		else if(str.equals("sk") || str.equals("SK") || str.equals("Sk") || str.equals("sK"))
		{
			name = "Sikkim";
		}
		else if(str.equals("TN") || str.equals("tN") || str.equals("Tn") || str.equals("tn"))
		{
			name = "Tamil Nadu";
		}
		else if(str.equals("TR") || str.equals("tr") || str.equals("Tr") || str.equals("tR"))
		{
			name = "Tripura";
		}

		else if(str.equals("uT") || str.equals("Ut") || str.equals("ut") || str.equals("UT"))
		{
			name = "Uttarakhand";
		}
		else if(str.equals("UP") || str.equals("Up") || str.equals("uP") || str.equals("up"))
		{
			name = "Uttar Pradesh";
		}

		else if(str.equals("WB") || str.equals("Wb") || str.equals("wb") || str.equals("wB"))
		{
			name = "West Bengal";
		}
		else if(str.equals("aD") || str.equals("AD") || str.equals("Ad") || str.equals("ad"))
		{
			name = "Andaman And Nicobar Islands";
		}
		else if(str.equals("CH") || str.equals("Ch") || str.equals("ch") || str.equals("cH"))
		{
			name = "Chandigarh";
		}

		else if(str.equals("Dl") || str.equals("dL") || str.equals("Dl") || str.equals("dl"))
		{
			name = "Delhi";
		}
		else if(str.equals("LD") || str.equals("Ld") || str.equals("lD") || str.equals("ld"))
		{
			name = "Lakshadweep";
		}
			else 
			name =str;
		
		char[] c = name.toCharArray(); 
		return c;
	}
}
