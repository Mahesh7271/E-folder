package string;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class pincode {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		do {
			
		System.out.println("Enter pincode");
		String num =scanner.nextLine();
		System.out.println(num+":"+IsValiedPincode(num));
		} while (1==1);
		}
	public static boolean IsValiedPincode(String pincode)
	{
		String regex ="^[1-9]{1}[0-9]{2}\\s{0,1}[0-9]{3}$"; 
		Pattern pattern =Pattern.compile(regex);
		
		if (pincode==null) 
		{
			return false;
		}
		Matcher matcher = pattern.matcher(pincode);
		
		return matcher.matches();
	}
}
