package string;

import java.util.Scanner;

public class bank {

	public static void main(String[] args)
	{
		
		Scanner scanner = new Scanner(System.in);
		do {
			System.out.println("Enter your Bank type  in 'cr'|or|'sa 'and any");
			String string = scanner.next();
			char[] arr = getstate(string);
			String str = String.valueOf(arr);
			System.out.println(str);
	
		} while (1==1);
			}

	private static char[]  getstate(String str)
	{
		String name="";
		
		if(str.equals("nr") || str.equals("Nr") || str.equals("nR") || str.equals("NR"))
		{
			name = "NRI ";
		}
		else if(str.equals("rd") || str.equals("Rd") || str.equals("RD") || str.equals("rd"))
		{
			name = "Recurring Deposit ";
		}
		else if(str.equals("FX") || str.equals("Fx") || str.equals("fX") || str.equals("fx")|| str.equals("dp"))
		{
			name = "Fixed Deposit";
		}
		else if(str.equals("Sl") || str.equals("SL") || str.equals("sL") || str.equals("sl"))
		{
			name = "Salary";
		}
		else if(str.equals("SA") || str.equals("Sa") || str.equals("sA") || str.equals("sa"))
		{
			name = "Saving";
		}
		else if(str.equals("CR") || str.equals("cR") || str.equals("Cr") || str.equals("cr"))
		{
			name = "Current";
		}
			else 
			name =str;
		
		char[] c = name.toCharArray(); 
		return c;
	}
}
