package string;

import java.util.Scanner;

public class VowelPostion {

	public static void main(String[] args) {
		Scanner scanner =new Scanner(System.in );
		System.out.println("Enter your String");
		String string = scanner.next();
		int j = 0;
		int vowel[] = new int[string.length()];
		for (int i = 0; i < string.length(); i++) {
			if (string.charAt(i)=='u'||string.charAt(i)=='o'||string.charAt(i)=='i'||string.charAt(i)=='e'||string.charAt(i)=='a') 
			{
				int k=i+1;
			vowel[j]=k;
			j++;
			}
		}
		System.out.println(vowel[1]);
	}

}
