package string;

public class HelloWord {

	public static void main(String[] args) {
		System.out.println(args); 
	}

}
