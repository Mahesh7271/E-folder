package string;

import java.util.Scanner;

public class VowelOfString
{
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Who many string do you want to Enter :");
		int size = scanner.nextInt();
		String[] String = new String[size];
		for (int i = 0; i < String.length; i++) {
			String[i]=scanner.next();
		}
		System.out.println("=================================================");
		System.out.println("Your String Is following:");
		for (String string2 : String) {
			System.out.println(string2);
		}
		System.out.println("=================================================");
		for (int i = 0; i < String.length; i++) {
			
			System.out.println(+(i+1)+" : String is\t"+String[i]);
			System.out.println(" \t\t    Vowel is :"+isVowel(String[i]));
			System.out.println(" \t\tConstent  is :"+isCons(String[i]));
		
		System.out.println("-------------------------------------------------");
		}
	}
	public static int isVowel(String string) 
	{
		int count=0;
			for (int i = 0; i < string.length(); i++) {
				if (string.charAt(i)=='a' || string.charAt(i)=='e'|| string.charAt(i)=='i'|| string.charAt(i)=='o'|| string.charAt(i)=='u'|| string.charAt(i)=='A'|| string.charAt(i)=='E'|| string.charAt(i)=='I'|| string.charAt(i)=='O'|| string.charAt(i)=='U') 
					count++;
			}
		return count;
	}
	public static int isCons(String string) 
	{
		int count=0;
		for (int i = 0; i < string.length(); i++) {
			if (string.charAt(i)=='a' || string.charAt(i)=='e'|| string.charAt(i)=='i'|| string.charAt(i)=='o'|| string.charAt(i)=='u'|| string.charAt(i)=='A'|| string.charAt(i)=='E'|| string.charAt(i)=='I'|| string.charAt(i)=='O'|| string.charAt(i)=='U') 
			{
				
			}
				else
				{
				count++;
				}
		}
		return count;
	}
}
