
public class Natralnumber {
	// Prints numbers from 1 to n
	static void printNos(int n) {
		if (n > 0) {
			/* System.out.print(n + " "); D */
			printNos(n - 1);
			System.out.println(n + " ");
		}
		return;
	}

	// Driver Code
	public static void main(String[] args) {
		printNos(1000);
	}
}

// This code is contributed by Manish_100
