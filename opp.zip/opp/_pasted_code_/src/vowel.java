import java.util.Scanner;

public class vowel 
{
	public static void main(String[] args)
	{
		Scanner scanner= new Scanner(System.in);
		String  string = scanner.next();
		int Vowel[] =new  int [string.length()];
		int Senm=0;
		int j=0;
		int count=0;
		int len= string.length();
		for (int i = 0; i < len; i++) 
		{
			if (
			      string.charAt(i)=='a' || string.charAt(i)=='e' || string.charAt(i)=='i' 
			   || string.charAt(i)=='o' || string.charAt(i)=='u' || string.charAt(i)=='A'
			   || string.charAt(i)=='E' || string.charAt(i)=='I' || string.charAt(i)=='O'
			   || string.charAt(i)=='U'
			   ) 
			{
				int temp=i+1;
				Vowel[j]=temp;
				j++;
				count++;
			}
			else
			{
				Senm++;
			}
		}
		System.out.println("Available Number of vowel is  :"+count);
		for (int i = 0; i < Vowel.length; i++) {
			System.out.print("\t"+Vowel[i]);
		}
		System.out.println("what is position you can see"
				+ "\n Please Enter postion");
		int e=scanner.nextInt();
				System.out.println(Vowel[e-1]);
	
	}
}
