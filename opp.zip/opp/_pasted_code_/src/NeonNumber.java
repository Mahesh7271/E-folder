import java.util.Scanner;

public class NeonNumber 
{
	public static void main(String[] args) 
	{
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter Number to check neon number");
		int number =scanner.nextInt();
		int sqr =number*number;
		int rem,result=0;
		while (sqr>0) 
		{
			rem =sqr%10;
			result=result+rem;
			sqr/=10;
		}
		if (number==result)
			System.out.println("Neon Number");
		else
			System.out.println("Not Neon Number");
	}
}
