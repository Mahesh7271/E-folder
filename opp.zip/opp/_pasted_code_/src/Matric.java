import java.util.Scanner;

public class Matric {

	public static void main(String[] args)
	{
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter Your Size");
		int size = scanner.nextInt();
		int arr[][] = new int [size][size];
		int Ans[]=new int[size];
		int finalsum=0;
		System.out.println("Enter Array Element ");
		
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr.length; j++) {
				arr[i][j]=scanner.nextInt();
			}
		}
		System.out.println("------------------------------------------");
		System.out.println("\t Display Matrix\t");
		System.out.println("------------------------------------------");
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr.length; j++) {
				System.out.print(arr[i][j]+"\t");
			}
			System.out.println();
		}
		System.out.println("------------------------------------------");
		System.out.println("\t Addtion of Matrix\t");
		System.out.println("------------------------------------------");
		for (int i = 0; i < arr.length; i++) {
			int sum=0;
			for (int j = 0; j < arr.length; j++) {
				System.out.print("."+arr[i][j]+"\t");
				sum+=arr[i][j];
			}
			System.out.print("|"+sum+"|");
			finalsum+=sum;
			System.out.println();
		}
		System.out.println("------------------------------------------");
		for (int k = 0; k <arr.length ; k++) 
		{
			int add=0;
			for (int i = 0; i < arr.length; i++)
			{
				add+=arr[i][k];
			}
			     Ans[k]=add;
			     finalsum+=add;
		}
		for (int i = 0; i < Ans.length; i++) {
			System.out.print("|"+Ans[i]+"|"+"\t");
		}
		int temp=0;
		int j = 1;
		for (int i = 1; i <=arr.length; i++) {
			if(i==j)
			{
			temp+=arr[i-1][j-1];
			j++;
			}
		}
		System.out.print("|"+temp+"|");
		System.out.print("|"+finalsum+"|");
		}
}
