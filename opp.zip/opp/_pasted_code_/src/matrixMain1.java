import java.util.Scanner;

public class matrixMain1 {

	public static void main(String[] args) 
	{
		int r1,c1,r2,c2;
		Scanner sc=new Scanner(System.in);
		//matrix1
		System.out.println("How many rows and column do you want : in Matrix 1");
		r1=sc.nextInt();
		c1=sc.nextInt();
		System.out.println("How many rows and column do you want : in Matrix 2");
		r2=sc.nextInt();
		c2=sc.nextInt();
		int mat1[][]=new int[r1][c1];
		int mat2[][]=new int[r2][c2];
		int c[][]=new int[r2][c2];/*
		System.out.println("1 - Display matrix"
				       + "\n2 - Addtion of matrix"); 
		System.out.println("Enter your choice");
		int choice = sc.nextInt(); 
		switch (choice) {
		case 1:
			System.out.println("Digit for matrix 1");
				DisplayMat(mat1);
			System.out.println("Digit for matrix 2");
				DisplayMat(mat2);
			break;

		default:
			break;
		}*/
		System.out.println("Enter Digit for matrix 1");
		for(int i=0;i<mat1.length;i++)
		{
			for (int j = 0; j < mat1.length; j++) {
				
				mat1[i][j]=sc.nextInt();
			}
		}
		
		System.out.println("Enter Digit for matrix 2");
		for(int i=0;i<mat2.length;i++)
		{
			for (int j = 0; j < mat2.length; j++) {
				
				mat2[i][j]=sc.nextInt();
			}
		}
		System.out.println("Digit for matrix 1");
		for(int i=0;i<mat1.length;i++)
		{
			for (int j = 0; j < mat1.length; j++)
			{
				System.out.print(mat1[i][j]+"\t");
			}
			System.out.println();
		}
		System.out.println("Digit for matrix 2");
		for(int i=0;i<mat2.length;i++)
		{
			for (int j = 0; j < mat2.length; j++)
			{
				System.out.print(mat2[i][j]+"\t");
			}
			System.out.println();
		}
		
		for(int i=0;i<2;i++)
		{    
		    for(int j=0;j<2;j++)
		    {    
		    c[i][j]=0;      
		    for(int k=0;k<2;k++)      
		    {      
		    c[i][j]+=mat1[i][k]+mat2[k][j];      
		    }
		    System.out.print(c[i][j]+" ");  //printing matrix element  
		    }
		    System.out.println();//new line    
		    }    
		    
	}
	public static void DisplayMat(int mat[][] ) 
	{
		for(int i=0;i<mat.length;i++)
		{
			for (int j = 0; j < mat.length; j++)
			{
				System.out.print(mat[i][j]+"\t");
			}
			System.out.println();
		}
		
	}
	public static void Addtion(int mat1[][] , int mat2[][]) {
		
	}
}