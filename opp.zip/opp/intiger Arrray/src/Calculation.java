 class Calculation2 
{
	public static void greter(int ...x)
	{
		System.out.println("length of giveen in is :"+x.length);
		int sum=0;
		for (int i = 0; i < x.length; i++) {
			
		}
		System.out.println("addtion of number :"+sum);
	}
}
 public class Calculation
 {
	 public static void main(String[] args) 
	 {
	  Calculation2 c = new Calculation2();
	  c.greter(10,20,30);
	  c.greter(10,20,30,40);
	  c.greter(10,20,30,40,50);
	 }
 }