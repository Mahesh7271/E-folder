	import java.util.Scanner;
import java.util.StringTokenizer;

public class numberofvowel
{
		public static void main(String[] args) 
		{
			Scanner sc = new Scanner(System.in);
			int vowel[]= new int [10];
			int con[]= new int [10];
			System.out.println( "How many name do you want to enter");
			int n=sc.nextInt();
			String[] str =new String[n];
			for (int i = 0; i < n; i++)
			{
			str[i]=sc.next();
			}
			for (int i = 0; i < str.length; i++)
			{
				System.out.println(str[i]);
			}
		}
		public int vowels(String str[])
		{
			int count=0;
			int i,vowel=0;
			for (int j = 0; j < str.length; j++) 			
			{
				for (i = 0; i < str.length; i++)
				{
					
				}
			} 
			return count;
					
			}
		}



