public class WrapperclassDemo 
{
	public static void main(String[] args) 
	{
		int n1=10;
		// boxing .primitive to object
		Integer iboj=new Integer(n1);
		//unboxing .object to primitive 
		int x=iboj.intValue();
		//************************************
	//java 5
		int y=10;
		Integer iogj=y;//Autoboxing
		int z=iogj;//unAutoboxing
		//----------------------------------
		
		System.out.println(iogj.toBinaryString(y));
		System.out.println(iogj.toHexString(y));
	}

}
