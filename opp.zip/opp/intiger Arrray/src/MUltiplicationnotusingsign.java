import java.util.Scanner;

public class MUltiplicationnotusingsign 
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your two number");
		int a=sc.nextInt();//10
		int b=sc.nextInt();//20
		int add=0;
		for (int i = 0; i < b; i++)
		{
			add=add+a;
		}
		System.out.println("multiplication of two numbwe is :"+add);
	}

}
