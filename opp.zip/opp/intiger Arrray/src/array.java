import java.util.Iterator;
import java.util.Scanner;
public class array 
{
	Scanner sc =new Scanner(System.in);
	public int[] create()
	{
		System.out.println("how many element in array");
		int no=sc.nextInt();
		int[] arr= new int[no];
		for (int i = 0; i < arr.length; i++)
		{
			arr[i]=sc.nextInt();
		}
	return arr;
	}
	
	public void display(int[] acc)
	{
		for (int a : acc)
		{
		System.out.println(a);	
		}
	}
	
	public int[] incerseSize(int[] arr,int no, int p)
	{
	int[] newarr = new  int[arr.length+1];
	for (int i = 0; i < newarr.length; i++)
	{
		if(arr[i]==p)
			newarr[i]=no;
		else
		newarr[i]=arr[i];
	}
	return newarr;
	}
	public int[] Deletetemplement(int arr[],int number)
	{
		int j=0;
		int temp[] = new int[arr.length-1]; 
		for (int i : arr) 
		{
			if(i!=number)
				temp[j]=arr[i];
			j++;
		}
		return temp;
	}
	public void insert(int[] acc,int no,int p)
	{
		System.out.println("first len"+acc.length);
		int[] ac = new int[acc.length+1];
		for (int j = 0; j < acc.length; j++) 
		{
			ac=incerseSize(acc,no,p);
					System.out.println("------------element added------------");
		}
	}
}
