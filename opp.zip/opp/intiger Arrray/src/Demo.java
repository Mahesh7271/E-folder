import static java.lang.System.out;
public class Demo 
{
	int num1;
	 static int num2;
	 public void  show()
 {
	   	out.println("value of  num 1 :" +num1);
	out.println("value of  num 2 :"+num2);
 }
 public static void  display() 
 {
	 Demo dd = new Demo();
	 dd.num1=300;
	out.println("value of  num 1 :" +dd.num1);
	out.println("value of  num 2 :"+num2);	
 }

	 public Demo()
	 {
		System.out.println("defualt construrctor of demo 1 class");
	} 
	{
		
	}

	public  Demo(int n1,int n2) 
	{
		this.num1=n1;
		this.num1=100;
	}
	
	
}
