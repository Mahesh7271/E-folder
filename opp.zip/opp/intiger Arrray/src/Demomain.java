import static java.lang.System.out;
public class Demomain 
{
	
	public static void main(String[] args) 
	{
		
	}
	static
	{
		System.out.println("static block");
		Demo dem = new Demo();
		Demo dem1 = new Demo();
		Demo dem2 = new Demo();
		
		dem1.num1=10;
		dem1.num2=10;
		System.out.println("value of  num 1 :" +dem1.num1);
		System.out.println("value of  num 2 :"+dem1.num2);
		dem.num1=20;
		dem.num2=20;
		System.out.println("value of  num 1 :" +dem.num1);
		System.out.println("value of  num 2 :"+dem.num2);
		dem2.num1=30;
		dem2.num2=30;
		System.out.println("value of  num 1 :" +dem2.num1);
		System.out.println("value of  num 2 :"+dem2.num2);
		System.out.println("value of  num 1 :" +dem1.num1);
		System.out.println("value of  num 2 :"+dem1.num2);
	    
		System.out.println(" inport static  ");

	}}
