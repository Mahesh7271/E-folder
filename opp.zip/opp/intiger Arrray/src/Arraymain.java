import java.util.Scanner;

public class Arraymain 
{
	public static void main(String[] args)
	{
		int a[]=null;
		array arr = new array();
	Scanner sc = new Scanner(System.in);

	do {
		System.out.print( "\n 1: Create array"
				+  "\n 2: Display array      "
				+  "\n 3: Insert array       "
				+  "\n 4: Delete array");
System.out.println("Enter your choice :      ");
int ch=sc.nextInt();
switch (ch) 
{
case 1:
	a=arr.create();
	break;
case 2:
	arr.display(a);
	
	break;
case 3:
	System.out.println("Enter new number And postion");
	int no=sc.nextInt();
	int p=sc.nextInt();
	arr.insert(a,no,p);
	
	break;
case 4:
	System.out.println("Enter new number ");
	int no1=sc.nextInt();
	a=arr.Deletetemplement(a,no1);
	arr.display(a);
	break;
default:
	System.out.println("----------------THANK YOU----------------");
	break;
}
		System.out.println("------1----------1------------1------------1");
	} while (1==sc.nextInt());
	}

}
