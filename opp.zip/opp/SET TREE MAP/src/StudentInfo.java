import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class StudentInfo 
{
	public Map<Integer, Student>  Create()
	{
	Map<Integer, Student> stud  =new TreeMap<Integer, Student>();	
	stud.put(100,new Student(2, "Mahesh", 12000, 150000));
	Set<Integer> carset =  stud.keySet();
	// Student integer key set is collect in set object
	// Student 
	Iterator<Integer>  itr = carset.iterator();
	
	while (itr.hasNext()) {
		Integer i= (Integer) itr.next();
		Student acc = stud.get(i);
		System.out.println(i+"\t"+acc.getS_Id()+"\t"+acc.getS_Name()+"\t"+acc.getS_PaidFees()+"\t"+acc.getS_TotalFees());
	System.out.println(stud);
	}
	
	return stud;
	}
}
//3*2*6*
