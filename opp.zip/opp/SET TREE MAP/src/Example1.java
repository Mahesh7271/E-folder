
public class Example1 {
	public static void main(String[] args) {
		StudentInfo info = new StudentInfo();
		info.Create();
	}

}
