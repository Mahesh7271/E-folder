public class Student 
{
	private int S_Id;
	private String S_Name;
	private float S_PaidFees;
	private float S_TotalFees;
	public Student(int s_Id, String s_Name, float s_PaidFees, float s_TotalFees) {
		super();
		S_Id = s_Id;
		S_Name = s_Name;
		S_PaidFees = s_PaidFees;
		S_TotalFees = s_TotalFees;
	}
	public int getS_Id() {
		return S_Id;
	}
	public void setS_Id(int s_Id) {
		S_Id = s_Id;
	}
	public String getS_Name() {
		return S_Name;
	}
	public void setS_Name(String s_Name) {
		S_Name = s_Name;
	}
	public float getS_PaidFees() {
		return S_PaidFees;
	}
	public void setS_PaidFees(float s_PaidFees) {
		S_PaidFees = s_PaidFees;
	}
	public float getS_TotalFees() {
		return S_TotalFees;
	}
	public void setS_TotalFees(float s_TotalFees) {
		S_TotalFees = s_TotalFees;
	}
}
