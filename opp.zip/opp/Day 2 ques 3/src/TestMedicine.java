public class TestMedicine 
{
	public static void main(String[] args) 
	{
		Medicine[] m = new Medicine[10];
		m[0] = new Tab();
		m[1] = new Syrup();
		m[2] = new Ointment();
		m[3] = new Tab();
		m[4] = new Syrup();
		m[5] = new Ointment();
		m[6] = new Tab();
		m[7] = new Syrup();
		m[8] = new Ointment();
		m[9] = new Ointment();
 		display(m);
	}
	public static void display(Medicine[] a) 
	{
		for (int i = 0; i < a.length; i++)
		{
			if (a[i] instanceof Tab)
			{
				System.out.println("Tab------->");
				a[i].Display();
			}
			else if (a[i] instanceof Syrup)
			{
				System.out.println("Syrup------->");
				a[i].Display();
			}
			else if (a[i] instanceof Ointment)
			{
				System.out.println("Ointment------->");
				a[i].Display();
			}
		}
		System.out.println("-------------------Thank you & Visit again---------------");
	}

}
