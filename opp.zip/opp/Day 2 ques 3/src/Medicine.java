public class Medicine 
{
	public void Display()
	{
		
	}
	public void Display(int n)
	{
		
	}
}
