
public class Counter  extends Thread
{
	Storage st;
	public Counter(Storage st) 
	{
		this.st = st;
	}

	@Override
	public void run() 
	{
		for (int i = 0; i < 5 ; i++) 
		{
			System.out.println(Thread.currentThread().getName()+" "+st.getValue()+i);
		}
	}

}
