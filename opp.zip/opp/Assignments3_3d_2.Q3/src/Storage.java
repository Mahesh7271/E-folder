public class Storage 
{
	/*** Implement three classes: Storage, Counter and Printer
	  *  The Storage class should store an integer.
	  *  The Counter class should create a thread and starts counting from 0 (0,1,2,3�) and
	  *   stores each value in the Storage class. 
	  *	  The Printer  Class should create a thread that 
	  *   keeps reading the value in the Storage class and printing it.
	 */
	int  i;
    public synchronized void setValue(int i)
	  {
          this.i = i;
	  }
    public synchronized int getValue()
	  {
          return this.i;
    }
}
