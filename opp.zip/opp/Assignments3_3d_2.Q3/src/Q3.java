public class Q3 
{
	public static void main(String[] args) 
	{
		Storage storage = new Storage();
		Counter counter =new Counter(storage);
		Printer printer =new Printer(storage);
		counter.setName("mahesh");
		printer.setName("tejas");
		counter.start();
		printer.start();
		System.out.println(counter.isAlive());
		System.out.println(printer.isAlive());
	}
}
