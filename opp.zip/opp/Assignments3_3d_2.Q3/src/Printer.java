
public class Printer extends Thread
{
	Storage st;
	
	public Printer(Storage st) 
	{
		this.st = st;
	}

	@Override
	public void run() 
	{
			for (int i = 0; i < 5 ; i++) 
			{
			st.setValue(i);	
				try 
				{
					Thread.sleep(40000);
				} catch (InterruptedException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}	
	}
}