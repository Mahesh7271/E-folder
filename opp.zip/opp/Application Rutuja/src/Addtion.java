import java.util.Scanner;

public class Addtion
{
	public static void  main(String [] args)
	{
		Scanner sc = new Scanner(System.in);
		do 
		{
			System.out.println("------------------Rutuja Shelar ----------------");
			System.out.println("enter two number");
			double num1 = sc.nextDouble();
			double num2 = sc.nextDouble();
			double add=num1*num2;
			System.out.println("multiplication of two number = "+add);
			
		}
		while (0!=1);

	}
}