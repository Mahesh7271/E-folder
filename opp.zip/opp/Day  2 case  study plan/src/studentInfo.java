import java.util.Scanner;

import javax.swing.plaf.synth.SynthSeparatorUI;

public class studentInfo 
{
//=================================create data for 5 Student =========================================
	public Student[] create()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("How many Student Do you  want to Enter :  ");  
		int n = sc.nextInt();
		Student[] temp = new Student[n]; 
		for (int i = 0; i < temp.length; i++) 
		{
			System.out.println("Enter student id  : Student Name :  Student Date of Birth  ");
			temp[i]=new Student(sc.nextInt(), sc.next(), sc.nextDouble());
		}
		return temp;
	}
//=================================create data for 5 Student =========================================
	public void displayStudentdata( Student[] stud)
	{
		for (Student s : stud)
		{
			System.out.println("===================================================================");
			System.out.println("Student Id \tStudent Name\t StudentDate of Birth");
			System.out.println(s.getId()+"\t\t"+s.getName()+"\t\t\t"+s.getDob());
			System.out.println("===================================================================");
		}
	}
//=================================create data for Course =========================================
public Course[] create1()
{
	Course[] course = new Course[2];
	course[0]= new Course(1001, "Java Full Stack devlopment", "placement regarding",	15000);
	course[1]= new Course(1001, "Java Full Stack devlopment", "placement regarding",	15000);
	return course;
}
//=================================display data for Cousres =========================================
	public void display(Course[] c) 
	{
		System.out.println("--------------------------------------------------------------------");
		System.out.println("                  for avalable courese");
		System.out.println("--------------------------------------------------------------------");
		for (int i = 0; i < c.length; i++) 
		{
			System.out.println("Course id\tcourse name\t\t\tcourse Duration \t\t course fees ");
			System.out.println(c[i].getId()+"\t\t"+c[i].getCoursename()+"\t"+c[i].getDuration()+"\t\t"+c[i].getFees());
			                     //1001, "Java Full Stack devlopment", "placement regarding",	15000
		}
	}
	
}

