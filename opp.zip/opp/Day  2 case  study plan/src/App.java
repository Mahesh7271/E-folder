import java.time.LocalDate;

public class App 
{
	public static void main(String[] args) 
	{
		Course[] courses = null;
		Student[] students=null;
		String[] lo=null;
		
	AppEngine appEngine = new AppEngine();
	courses=appEngine.listofCourse();
	students=appEngine.listofStudents();
	lo=appEngine.listofEnrollments();
	System.out.println("--------------------------------------------------------------------------------------------------------------------");
	appEngine.introduce(courses);
	System.out.println("--------------------------------------------------------------------------------------------------------------------");
	appEngine.register(students);
	System.out.println("--------------------------------------------------------------------------------------------------------------------");
	appEngine.display(lo, courses, students);
	}

}
