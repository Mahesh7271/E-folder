public class Course 
{
	private int id;
	private String Coursename;
	private String Duration;
	private double fees;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCoursename() {
		
		return Coursename;
	}
	public void setCoursename(String coursename) {
		Coursename = coursename;
	}
	public String getDuration() {
		return Duration;
	}
	public void setDuration(String duration) {
		Duration = duration;
	}
	public double getFees() {
		return fees;
	}
	public void setFees(double fees) {
		this.fees = fees;
	}
	public Course(int id, String coursename, String duration, double fees) {
		super();
		this.id = id;
		Coursename = coursename;
		Duration = duration;
		this.fees = fees;
	}
}
