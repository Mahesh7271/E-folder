import java.util.Scanner;

public class StudentMain 
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		do
		{
			studentInfo sinfo = new studentInfo();
			Student[] student = null;
			Course c[]=null;
			
			System.out.println("------------------------------------------------------------------");
			System.out.println("     1 : for  Method called as Scenario1   to :");
			System.out.println("    -- create few objects of student class ");
			System.out.println("    -- call the display objects of studentinfo class ");
			System.out.println("------------------------------------------------------------------");
			System.out.println("     2 : for  Method called as Scenario2   to :");
			System.out.println("    -- Create Array of student class and store few objescts in it ");
			System.out.println("    -- call the display objects of studentinfo class ");
			System.out.println("------------------------------------------------------------------");
			System.out.println("     3 : for  Method called as Scenario3   to :");
			System.out.println("    -- Create Array of student and tack input for user and store ");
			System.out.println("    -- call the display objects of studentinfo class ");
			System.out.println("------------------------------------------------------------------");
			int choice = sc.nextInt();
			if (choice==1)
			{
			student = sinfo.create();
			          sinfo.displayStudentdata(student);
			}
			else if(choice==2)
			{
				student = sinfo.create();
	            sinfo.displayStudentdata(student);
		    }	
			else if (choice==3) 
			{
				student = sinfo.create();
	            sinfo.displayStudentdata(student);
	            c=sinfo.create1();	
	            sinfo.display(c);
			}
			System.out.println("------------------------thank you && visit again-------------------");
		
			System.out.println("do you want to continue press 1");
		} while (1==sc.nextInt());
		}

}
