
public class UserException extends Exception
{
	int n1,n2;
	public UserException(int n1, int n2) 
	{
		this.n1 = n1;
		this.n2 = n2;
	}
	@Override
	public String toString() {
		return "Your number is not valied for Arthmetic operation \n "
				+ "[n1=" + n1 + ", n2=" + n2 + "]";
	}
	

}
