
import java.util.Scanner;
public class Q2 
{
	public static void main(String[] args) throws UserException 
	{
		Scanner scanner = new Scanner(System.in);
		System.out.println("\n Enter your Two Number for Arthmetic operation");
		int first_Number = scanner.nextInt();
		int second_Number = scanner.nextInt(); 
		Number  number = new Number(first_Number, second_Number);
		try 
		{
			if (0==first_Number||0==second_Number)
			{
				throw new UserException(first_Number, second_Number);
			}
				else
				{
					System.out.println("Your number is valied for Arthmetic operation");
				}
		} 
		catch (UserException e)
		{
		System.out.println(e);
		if (first_Number==0)
		{
			System.out.println("re_enter you FirstNumber "+first_Number);
			first_Number = scanner.nextInt();
		}
		if (second_Number==0)
		{
			System.out.println("re_enter you second_number "+second_Number);
			 second_Number = scanner.nextInt();
		}
		number =new Number(first_Number, second_Number);
		}
		System.out.println("1.  Add"
				       + "\n2.  Sub"
				       + "\n3.  Mul"
				       + "\n4.  Div");
		System.out.println("Enter your choice :");
		int choice = scanner.nextInt();
		switch (choice)
		{
		case 1:
			System.out.println(+number.Addition());
			break;
		case 2:
			System.out.println(+number.subtarction());
			break;
		case 3:
			System.out.println(+number.Multiplication());
			break;
		case 4:
			System.out.println(+number.Division());
			break;
		}
	}

}
