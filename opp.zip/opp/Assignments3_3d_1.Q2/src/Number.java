
public class Number 
{
	 int First_Number;
	 int Second_Number;
     double Result;
     
	public Number(int first_Number, int second_Number) 
	{
		
		First_Number = first_Number;
		Second_Number = second_Number;
	}
	
	public double  Addition()
	{
		return First_Number+Second_Number;
	}
	public double  subtarction()
	{
		return First_Number-Second_Number;
	}
	public double  Multiplication()
	{
		return First_Number*Second_Number;	
	}
	public double  Division()
	{
		return First_Number/Second_Number; 
	}
	
}
