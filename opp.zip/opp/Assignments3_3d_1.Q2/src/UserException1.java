
public class UserException1 extends Exception
{
	int n1,n2;
	public UserException1(int n1, int n2) 
	{
		this.n1 = n1;
		this.n2 = n2;
	}
	@Override
	public String toString() {
		return "Your number is notvalied for Division Arthmetic operation \n "
				+ "[n1=" + n1 + ", n2=" + n2 + "]";
	}
	

}
