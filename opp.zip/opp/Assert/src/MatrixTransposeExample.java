import java.util.Scanner;
public class MatrixTransposeExample
{  
	static Scanner scanner =new Scanner(System.in);
	public static void main(String args[])
	{
		Scanner scanner =new Scanner(System.in);
	    int a= scanner.nextInt();
	    String[] b=new String[a];
	    for (int i = 0; i < b.length; i++)
	    {
			 b[i]= scanner.next();
		}
	    cal(b);
	}
	static void cal(String [] b)
	{
		for (int i = 0; i < b.length; i++)
		{
			char c1 =b[i].charAt(0);
			char c2 =b[i].charAt(1);
			int number1=Character.getNumericValue(c1);
			int number2=Character.getNumericValue(c2);
		     number(number1 ,number2);	
	    }
	}
	static  void number(int a,int b) 
	{
		int num=1;
      	for (int i = 0; i<b ; i++)
      	{
			num=num*a;
		} 
      	System.out.println(num);
	}
	static  void Matrix() {
		int i=scanner.nextInt();
		int original[][] = new int[i][i];    
			for (int i1 = 0; i1 < i; i1++) 
		    {
		        for (int j = 0; j < i; j++) 
		        {
		            original[i1][j] = scanner.nextInt();
		        }
		    }
		int transpose[][]=new int[i][i]; 
	
		for(int t=0;t<i;t++)
		{    
			for(int j=0;j<i;j++)
			{    
			transpose[t][j]=original[j][t];  
			}    
		}    
		int c[][]=new int[i][i];  //3 rows and 3 columns  
	
		//adding and printing addition of 2 matrices    
		for(int q=0;q<i;q++)
		{    
			for(int j=0;j<i;j++)
			{    
			c[q][j]=original[q][j]+transpose[q][j];    //use - for subtraction  
			}
		}	
		for(int y=0;y<i;y++)
		{    
			for(int j=0;j<i;j++)
			{    
			System.out.print(c[y][j]+" ");    
			}    
		System.out.println();//new line    
		}    
	
	
	}
	
}
	
/*		int i=scanner.nextInt();
		int original[][] = new int[i][i];    
			for (int i1 = 0; i1 < i; i1++) 
		    {
		        for (int j = 0; j < i; j++) 
		        {
		            original[i1][j] = scanner.nextInt();
		        }
		    }
		int transpose[][]=new int[i][i]; 
	
		for(int t=0;t<i;t++)
		{    
			for(int j=0;j<i;j++)
			{    
			transpose[t][j]=original[j][t];  
			}    
		}    
		int c[][]=new int[i][i];  //3 rows and 3 columns  
	
		//adding and printing addition of 2 matrices    
		for(int q=0;q<i;q++)
		{    
			for(int j=0;j<i;j++)
			{    
			c[q][j]=original[q][j]+transpose[q][j];    //use - for subtraction  
			}
		}	
		for(int y=0;y<i;y++)
		{    
			for(int j=0;j<i;j++)
			{    
			System.out.print(c[y][j]+" ");    
			}    
		System.out.println();//new line    
		}    
	}
*/