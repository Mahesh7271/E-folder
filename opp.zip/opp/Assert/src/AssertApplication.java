import java.util.Scanner;
public class AssertApplication 
{
	public void display() 
	{
		int age;
		Scanner scanner =new Scanner(System.in);
		System.out.println("Enter your age");
		age = scanner.nextInt();
		assert age>0:"Invalied";
		 System.out.println("----thanks----");
	}
}
