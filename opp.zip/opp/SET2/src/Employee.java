public class Employee implements Comparable<Employee>
{
private int E_id;
private	String E_Name;
private	double E_salary;
public int getE_id() {
	return E_id;
}
public void setE_id(int e_id) {
	E_id = e_id;
}
public String getE_name() {
	return E_Name;
}
public void setE_name(String e_name) {
	E_Name = e_name;
}
public double getE_salary() {
	return E_salary;
}
public void setE_salary(double e_salary) {
	E_salary = e_salary;
}
public Employee(int e_id, String e_name, double e_salary) {
	E_id = e_id;
	E_Name = e_name;
	E_salary = e_salary;
}
@Override
public int compareTo(Employee e) 
{
	if (this.getE_id()>e.getE_id()) 
		return 1;
	else if (this.getE_id()<e.getE_id()) 
		return -1;
	else 
		return 0;
} 

}
