
public class customException extends Exception
{

	@Override
	public String toString() 
	{
		return "customException Your [value is less than 500]";
	}

}
