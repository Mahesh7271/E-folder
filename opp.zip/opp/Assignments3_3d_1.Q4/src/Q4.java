import java.util.Scanner;

public class Q4 
{
	public static void main(String[] args) 
	{
		/**
		 * empId		int     	           
		 * empName  	string       
		 * designation	string	           
		 * basic 		double               
		 */
		Scanner  scanner = new Scanner(System.in);
		System.out.println("Enter your Id");
		int id = scanner.nextInt();
		System.out.println("Enter your Name ");
		String name = scanner.next();
		System.out.println("Enter your destination ");
		String d = scanner.next();
		System.out.println("Enter your Basic ");
		double b = scanner.nextDouble();
		Employee employee = new Employee(id, name, d, b);
		employee.printDET();
		employee.CalculateHRA();
	}

}
