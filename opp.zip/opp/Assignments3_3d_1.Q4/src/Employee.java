
public class Employee{
/*
	5. 	Create a class with following specifications.							
	addadClass Emp									     
			
		empId		int     	           
		empName  	string       
		designation	string	           
		basic 		double               
		hra	            double	readOnly

	Methods
			printDET()
			calculateHRA()
			printDET() methods will show details of the EMP. 			                  
			calculateHRA() method will calculate HRA based on basic. 

	There will 3 designations supported by the application.								
	If designation  is �Manager�  - HRA will be 10% of BASIC
	if designation  is �Officer�  - HRA will be 12% of BASIC
	if category is �CLERK�  - HRA will be 5% of BASIC

	 Have constructor to which you will pass, empId, designation, basic and price. 

	And checks whether the BASIC is less than 500 or not. If it is less than 500 raise a custom Exception as given below

	Create LowSalException class with proper user message to handle BASIC less than 500.   
*/
			int empId;     	           
			String empName  ;
			String designation;
			double basic ;              
			double hra	;
			public Employee(int empId, String empName, String designation, double basic) 
			{
				
				this.empId = empId;
				this.empName = empName;
				this.designation = designation;
				this.basic = basic;
			}
			public int getEmpId() 
			{
				return empId;
			}
			public void setEmpId(int empId) 
			{
				this.empId = empId;
			}
			public String getEmpName() {
				return empName;
			}
			public void setEmpName(String empName) {
				this.empName = empName;
			}
			public String getDesignation() {
				return designation;
			}
			public void setDesignation(String designation) {
				this.designation = designation;
			}
			public double getBasic() {
				try 
				{
					if (basic<500) 
					{
						throw new customException();
					}
				}
				catch (customException e)
				{
				System.out.println(e);
				}
				return basic;
			}
			public void setBasic(double basic) {
				this.basic = basic;
			}
			public double getHra() {
				return hra;
			}
			public void setHra(double hra) {
				this.hra = hra;
			} 
			/**
			printDET()
			calculateHRA()
			printDET() methods will show details of the EMP. 			                  
			calculateHRA() method will calculate HRA based on basic. 
			 */
			
			public void  printDET()
			{
				System.out.println("Employee  id         : "+empId);
				System.out.println("Employee  Name       : "+empName);
				System.out.println("Employee  Basic      : "+hra);
				System.out.println("Employee  designation:"+designation);
				CalculateHRA();
			}
			/*
			 *  calculateHRA() method will calculate HRA based on basic. 
			 *	There will 3 designations supported by the application.								
			 *	If designation  is �Manager�  - HRA will be 10% of BASIC
			 *	if designation  is �Officer�  - HRA will be 12% of BASIC
			 *	if category is �CLERK�  - HRA will be 5% of BASIC
			*/
			public void CalculateHRA()
			{
				if (designation=="Manager" || designation=="manager") 
				{
					hra = basic*0.1;
					System.out.println("Hra Of Manager  :"+hra);
					
				}
				else if (designation=="Officer" || designation=="officer") 
				{
					hra = basic*0.12;
					System.out.println("Hra Of Manager  :"+hra);
					
				}
				else if (designation=="CLERK" || designation=="clerk") 
				{
					hra = basic*0.05;
					System.out.println("Hra Of Manager  :"+hra);
					
				}
			}

}
