public class Medicine 
{
	public void Display()
	{
		
	}
}
