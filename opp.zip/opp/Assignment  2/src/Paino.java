public class Paino extends Shape
{

	@Override
	public void Display()
	{
		System.out.println("Piano is Playing tan tan tan tan");
	}
	
}
