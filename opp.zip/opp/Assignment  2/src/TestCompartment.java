
public class TestCompartment 
{

	public static void main(String[] args) 
	{
		Compartment c[] = new Compartment[10];
		c[0]=new FirstClass();
		c[1]=new Ladies();
		c[2]=new Genra();
		c[3]=new Lugg();
		c[4]=new FirstClass();
		c[5]=new Ladies();
		c[6]=new Genra();
		c[7]=new Lugg();
		c[8]=new FirstClass();
		c[9]=new Ladies();
		display(c);
	}
	public static void display(Compartment[] c) 
	{
		for (int i = 0; i < c.length; i++) 
		{
			if (c[i] instanceof FirstClass )
			{
				System.out.println("First Class coach");
			    c[i].Display();	
			}
			else if (c[i] instanceof  Ladies )
			{
				System.out.println("Ladies coach");
			    c[i].Display();	
			}
			if (c[i] instanceof Genra )
			{
				System.out.println("General Class coach");
			    c[i].Display();	
			}
			if (c[i] instanceof Lugg)
			{
				System.out.println("Luaggage coach");
			    c[i].Display();	
			}
		}
		System.out.println("\n\n -----------------Happy Journey------------------");
		
	}

}
