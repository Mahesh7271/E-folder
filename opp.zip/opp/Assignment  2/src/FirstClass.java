
public class FirstClass extends Compartment
{

	@Override
	public void Display()
	{
		System.out.println("--------This is FirstClass Coach--------");
	}
	
}
