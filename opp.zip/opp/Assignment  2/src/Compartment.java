
public class Compartment
{
	public void Display()
	{
		
	}
}
