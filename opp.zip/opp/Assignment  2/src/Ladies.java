
public class Ladies extends Compartment{

	@Override
	public void Display() {
	System.out.println("----------This is ladies coach-----------");
	}
	
}
