
public class Ointment extends Medicine
{

	@Override
	public void Display() 
	{
		System.out.println("-----------------------------------------------------");
		System.out.println("Company name  is   : Vaseline,Petroleum jelly ");
		System.out.println("Company Address is :  indian ");
		System.out.println("Relieve dry skin,including your lips and eyelids");
		System.out.println("-----------------------------------------------------");

	}
	
}
