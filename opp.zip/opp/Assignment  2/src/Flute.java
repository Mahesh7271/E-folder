public class Flute extends Shape
{
	@Override
	public void Display()
	{
		System.out.println("Flute is playing toot toot toot toot");
	}

}
