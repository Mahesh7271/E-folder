public class Tab extends Medicine
{

	@Override
	public void Display() 
	{
		System.out.println("-----------------------------------------------------");
		System.out.println("Company name  is   : Cipla ");
		System.out.println("Company Address is : Mumbai ,indian ");
		System.out.println("Store in cool dry place and external use only        ");
		System.out.println("-----------------------------------------------------");

	}
	
}
