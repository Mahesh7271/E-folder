
public class Shape 
{
	public void Display()
	{
		
	}
}
