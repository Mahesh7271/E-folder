
public class Guitar extends Shape
{
	@Override
	public void Display()
	{
		System.out.println("Guitar is playing tin tin tin ");
	}

}
