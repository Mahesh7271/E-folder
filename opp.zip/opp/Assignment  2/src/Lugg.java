
public class Lugg extends Compartment
{

	@Override
	public void Display() 
	{
		System.out.println("--------This is Luggage coach----------");
	}
	
}
