public class Syrup extends Medicine
{

	@Override
	public void Display() 
	{
		System.out.println("-----------------------------------------------------");
		System.out.println("Company name  is   : maple Syrup");
		System.out.println("Company Address is : Mumbai ,indian ");
		System.out.println("Thick,Sweet Liquid Concentration of Medicine is Suger");
		System.out.println("-----------------------------------------------------");
	}
	
}
