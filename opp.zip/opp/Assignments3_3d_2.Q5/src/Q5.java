
public class Q5 {
	public static void main(String[] args) 
	{
		Mahesh m1 = new Mahesh("Mahesh");	
		Mahesh m2 = new Mahesh("tejas");	
		
		m1.start();
		m2.start();
	}

}
