
public class Mahesh extends Thread{

	Thread Mahi;
	private  String Name;
	
	public Mahesh(String name) {
		super();
		Name = name;
	}

	@Override
	public void run() 
	{
		System.out.println("Thread running  : "+Name);
		for (int i = 0; i < 4; i++) {
			System.out.println();
			System.out.println(Name);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
				System.out.println("Thread has been Interrupted");
				}
		}
	}
	public void start() 
	{
		System.out.println("Thread is Started");
		if (Mahi==null)
		{
			Mahi = new Thread(this.Name);
			Mahi.run();
		}
	}
}
