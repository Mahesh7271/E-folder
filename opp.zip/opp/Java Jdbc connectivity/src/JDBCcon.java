import java.sql.*;

import java.util.Scanner;
public class JDBCcon 
{
	public static void main(String[] args)
	{
		Scanner scanner = new Scanner(System.in);
		try {
			Class.forName("oracle.jdbc.OracleDriver");
			Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","system");
			System.out.println("-------------------------------------------------------------------");
			
			PreparedStatement PStatement = connection.prepareStatement("insert into Custmer values(?,?,?,?)");
			do 
			{
				System.out.println("Enter Custmer ID ");
				PStatement.setString(1, scanner.next());
				System.out.println("Enter Custmer Name ");
				PStatement.setString(2, scanner.next());
				System.out.println("Enter Custmer PANCARD Number or ADHARCARD Number");
				PStatement.setString(3, scanner.next());
				System.out.println("Enter Custmer Moblie Number");
				PStatement.setInt(4, scanner.nextInt());
				int i =PStatement.executeUpdate();
				if (i>0) 
					System.out.println("Record Inserted...");
				else 
					System.out.println("Record not inserted Inserted...");
	System.out.println("Create One More Account in Bank Press |1| ");
			} while (scanner.nextInt()==1);
					} 
		catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
}
