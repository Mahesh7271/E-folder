public class Ford implements Automobile{

	@Override
	public String getModel()
	{
		return "EcosSport";
	}

	@Override
	public String getColor() {
		// TODO Auto-generated method stub
		return "Red";
	}

	@Override
	public double grtprice() 
	{
		// TODO Auto-generated method stub
		return 1048900;
	}

}
