public class Yamaha implements Bike{

	@Override
	public String getModel() {
		// TODO Auto-generated method stub
		return "RS-100";
	}

	@Override
	public String getColor() {
		// TODO Auto-generated method stub
		return "black";
	}

	@Override
	public double grtprice() {
		// TODO Auto-generated method stub
		return 87000;
	}

	@Override
	public double getcc() {
		// TODO Auto-generated method stub
		return 120;
	}

}
