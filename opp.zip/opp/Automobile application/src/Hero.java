public class Hero  implements Bike 
{
	@Override
	public String getModel()
	{
		// TODO Auto-generated method stub
		return "Hero honda ss 100";
	}
	@Override
	public String getColor()
	{
		// TODO Auto-generated method stub
		return "black";
	}

	@Override
	public double grtprice() {
		// TODO Auto-generated method stub
		return 50000;
	}

	@Override
	public double getcc() {
		// TODO Auto-generated method stub
		return 120;
	}

}
