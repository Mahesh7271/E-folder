public class Toyota  implements Automobile
{

	@Override
	public String getModel() 
	{
		// TODO Auto-generated method stub
		return "Toyota-etios";
	}

	@Override
	public String getColor() {
		// TODO Auto-generated method stub
		return "write";
	}

	@Override
	public double grtprice() {
		// TODO Auto-generated method stub
		return 1252e00;
	}
	
}
