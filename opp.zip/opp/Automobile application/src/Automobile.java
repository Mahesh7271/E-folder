
public interface Automobile 
{
	String getModel();
	String getColor();
	double grtprice();
}
