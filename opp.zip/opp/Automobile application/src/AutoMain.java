import java.util.Scanner;
public class AutoMain 
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		Automobile a =null;
		System.out.println("=================================================================================");
		System.out.println("                     Choose Any One 2 Weeler Or 4 Weeler");
		System.out.println("        1 :-->   4 Weeler      |Or|        2 :-->   2 Weeler      ");
		System.out.println("=================================================================================");
		int ch = sc.nextInt();
		if (ch==1)
		{
			do 
			{
				System.out.println("===================================================");
				System.out.println(" 1  :-  Maruti Suzuki  "
					           + "\n 2  :-  Toyota         "
					           + "\n 3  :-  ford           ");
				System.out.println("===================================================");
				System.out.println("Enter your choice");
				ch = sc.nextInt();
				if (ch==1)
				{
				a=new Maruti();
				Display(a, "Maruti");
				}
				else if (ch==2)
				{
				a=new Toyota();	
				Display(a, "Toyota");
				} 
				else if (ch==3)
				{
				a=new Ford();
				Display(a,"Ford");
				}
				
			} while (1==1);
		}
		else if (ch==2)
		{
			do 
			{
				System.out.println("===================================================");
				System.out.println(" 1  :-  Honda            "
					           + "\n 2  :-  Hero             "
					           + "\n 3  :-  Yamaha           ");
				System.out.println("===================================================");
				System.out.println("Enter your choice");
				ch = sc.nextInt();
				if (ch==1)
				{
					a=new Hero();
					Display(a,"hero");
				}
				else if (ch==2)
				{
				a=new Honda();	
				Display(a, "Honda");
				} 
				else if (ch==3)
				{
				a=new Yamaha();
				Display(a,"hero");
				}
				
			} while (1==1);
			
		}
		else 
		{
			System.out.println("----------------------------------invalied choice----------------------------");
		}
	}
	public static void Display( Automobile a ,String str) 
	{
		System.out.println(str+"  : Model Name  :  "+a.getModel());
		System.out.println(str+"  : Mobel Colar :  "+a.getColor());
		System.out.println(str+"  : Model Price :  "+a.grtprice());
		if (a instanceof Hero)
		{
			Hero  h=(Hero) a;
			System.out.println(str+"  : Model CC    :  "+h.getcc());
				
		}
		}

}
