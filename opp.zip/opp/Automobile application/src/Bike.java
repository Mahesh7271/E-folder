
public interface Bike extends Automobile 
{
	double getcc();
}
