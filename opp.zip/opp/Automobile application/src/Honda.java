public class Honda implements Bike
{

	@Override
	public String getModel() {
		// TODO Auto-generated method stub
		return "CB shine 120";
	}

	@Override
	public String getColor() {
		// TODO Auto-generated method stub
		return "black";
	}

	@Override
	public double grtprice() {
		// TODO Auto-generated method stub
		return 98700;
	}

	@Override
	public double getcc() {
		// TODO Auto-generated method stub
		return 120;
	}

}
