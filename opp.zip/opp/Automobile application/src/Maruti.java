public class Maruti implements Automobile
{
                       
	@Override
	public String getModel() {
		// TODO Auto-generated method stub
		return "m800";
	}

	@Override
	public String getColor() {
		// TODO Auto-generated method stub
		return "Write";
	}

	@Override
	public double grtprice() {
		// TODO Auto-generated method stub
		return 80000;
	}

}
