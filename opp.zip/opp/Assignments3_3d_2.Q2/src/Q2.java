

public class Q2 extends Thread
{
	/**  2.	Write a Java program that demonstrates a high-priority thread using sleep 
	 *      to give lowerpriority threads a chance to run. 
	*/
	int i =0;
	@Override
	public void run() 
	{
		for ( i = 0; i < 100; i++)
		{
	
			display();
			try 
			{
				Thread.sleep(1500);
			}
			catch (InterruptedException e) 
			{
				e.printStackTrace();
			}
		}
	}
	public void display() 
	{
	System.out.println("Test  : "+i);	
	}
	public static void main(String[] args) 
	{
		Q2 q2 = new Q2();
		q2.start();
	}
}
