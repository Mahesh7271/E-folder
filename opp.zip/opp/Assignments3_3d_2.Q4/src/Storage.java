
public class Storage 
{
	int i;
	public synchronized void setvalue(int i)
	{
		this.i=i;
	}
	public synchronized int getvalue()
	{
		return i;
	}
}
