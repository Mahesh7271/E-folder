
 

public class Q4 
{
	public static void main(String[] args) 
	{
		/**
		 * Write a program that creates an instance of the Storage class and set up
		 *  a Counter and Printer object to operate on it.
		 *  Identify that, whether synchronization is required or not in this assignment.
		 *   If yes, implement it.
		 *   Modify the above program in assignment no. 3 to ensure that each number is printed 
		 *   exactly once, by adding suitable synchronization.   
		 */
		Storage storage =new Storage();
		Counter  counter= new Counter(storage);
		Printer printer= new Printer(storage);
		System.out.println(counter.isAlive());
		System.out.println(printer.isAlive());
		counter.start();
		printer.start();
		System.out.println(counter.isAlive());
		System.out.println(printer.isAlive());
		}
}
