
public class Printer extends Thread
{
	Storage storage;
	int v;
	public Printer(Storage storage) 
	{
		this.storage = storage;
	}

	@Override
	public void run() 
	{
		for (int i = 0; i < 5; i++) 
		{
		v=storage.getvalue();
		System.out.println(v);
	
		}
	}
}
