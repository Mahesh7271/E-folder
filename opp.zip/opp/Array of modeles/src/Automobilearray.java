
public interface Automobilearray 
{
	String[] getModel();
	String[] getColor();
	double[] grtprice();
}
