public class AutoMain 
{
	public static void main(String[] args) 
	{
	
	}

}
