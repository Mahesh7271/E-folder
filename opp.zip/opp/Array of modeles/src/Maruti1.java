public class Maruti1 implements Automobilearray
{
	@Override
	public String[] getModel() 
	{
		String [] m = new String[5];
		m[0] = "Alto 100";
		m[1] = "Ertica HB";
		m[2] = "Swift ";
		m[3] = "Baleno";
		m[4] = "nexa";
		return m;
	}
	@Override
	public String[] getColor() {
		String [] m = new String[5];
		m[0] = "gray  ";
		m[1] = "black ";
		m[2] = "red   ";
		m[3] = "Blue  ";
		m[4] = "white ";
	return m;
	}
	@Override
	public double[] grtprice() {
		double[] m = new double[5];
		m[0] = 120000;
		m[1] = 130000;
		m[2] = 101220;
		m[3] = 111111;
		m[4] = 481100;
		return m;
	}

}
