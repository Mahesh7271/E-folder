import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
public class oprations
{
	public static void main(String[] args)
	{
		Scanner scanner = new Scanner(System.in);
		try
		{
			Class.forName("oracle.jdbc.OracleDriver");
			Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","system");
			System.out.println("----------------Connected Succesfully To Database----------------");
			do 
			{
				System.out.println("1-Create"
						+ "\n2-Delete"
						+ "\n3-Update"
						+ "\n4-Search"
						+ "\n5-DisplayAll");
				System.out.println("Enter Your choice.....");
				int ch =scanner.nextInt();
				switch (ch)
				{
				case 5:
					PreparedStatement PStatement2 = connection.prepareStatement("select * from bank where 	ID = ?");
					System.out.println("Enter your Accno to Search account");
					PStatement2.setInt(1, scanner.nextInt());
					ResultSet rs1 =PStatement2.executeQuery();
					rs1.next();
					System.out.println(rs1.getString(1)+" "+rs1.getString(2)+" "+rs1.getString(3));  
					break;
				case 4:
					PreparedStatement PStatement1 = connection.prepareStatement("select * from bank where 	ID = ?");
					System.out.println("Enter your Accno to Search account");
					PStatement1.setInt(1, scanner.nextInt());
					ResultSet rs =PStatement1.executeQuery();
					rs.next();
					System.out.println(rs.getString(1)+" "+rs.getString(2)+" "+rs.getString(3));  
					break;
				case 2:
					PreparedStatement PStatement = connection.prepareStatement("delete from bank where 	ID = ?");
					System.out.println("Enter your Accno to delete account");
					PStatement.setInt(1, scanner.nextInt());
					int i =PStatement.executeUpdate();
					if (i>0) 
						System.out.println("Record Deleted...");
					 else
						 System.out.println("Record Not Deleted...");
					break;
				case 3:
					PreparedStatement PState1 = connection.prepareStatement("update bank set FNAME=?,LNAME=? where ID =?");
					System.out.println("Enter your Account Number To Upadte FName & LName ");
					PState1.setInt(3, scanner.nextInt());
					PState1.setString(1, scanner.next());
					PState1.setString(2, scanner.next());
					int i3 =PState1.executeUpdate();
					if (i3>0) 
						System.out.println("Record Updated...");
					 else
						 System.out.println("Record Not Updated...");
					break;
				case 1:
					PreparedStatement PState = connection.prepareStatement("insert into bank values(?,?,?)");
					System.out.println("Enter your Accno ,FName, LName");
					PState.setInt(1, scanner.nextInt());
					PState.setString(2, scanner.next());
					PState.setString(3, scanner.next());
					int i1=PState.executeUpdate();
					if (i1>0) 
						System.out.println("Record Inserted...");
					 else
						 System.out.println("not Record Inserted...");
					break;
				default:
					break;
				}
			}
			while (scanner.nextInt()==1);
		} 
		catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
