import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.util.Scanner;

public class toGetImformationaboutSQL 
{
	public static void main(String args[])
	{  
		Scanner sc = new  Scanner(System.in);
		try
		{  
			//load driver
		Class.forName("oracle.jdbc.driver.OracleDriver");  
		  //connection
		Connection con=DriverManager.getConnection(  
		"jdbc:oracle:thin:@localhost:1521:xe","system","system");  
		int ch=0;
		do {
			System.out.println("1-create\n2-Delete\n3-Search\n4-Display all");
			System.out.println("Enter your choice.....");
		} while (sc.nextInt()==1);
		
		
		con.close();  
	}
		catch(Exception e)
		{
			System.out.println(e);
		}  
	}  
}
