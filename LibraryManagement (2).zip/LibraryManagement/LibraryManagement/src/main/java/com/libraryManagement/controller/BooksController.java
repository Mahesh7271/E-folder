package com.libraryManagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.libraryManagement.model.Books;
import com.libraryManagement.service.BooksService;

@RestController
@RequestMapping("/book")
public class BooksController {
	@Autowired
	public BooksService booksService;
	
	

	@GetMapping
	public List<Books> getAllBooks() {
		return booksService.findAll();
	}
	
	@GetMapping(value = "/one")
	public ResponseEntity<Books> getBookById(@PathVariable int id) {
		 Books bobj = booksService.findBook(id);
	        return ResponseEntity.ok(bobj);
	}
	
	@PostMapping(value = "/create")
	public Books createbooks(@RequestBody Books entity) {
		return booksService.createBook(entity);
	}
	
	@PutMapping(value = "/two")
	public ResponseEntity<Books> updateBook(@PathVariable int id, @RequestBody Books entity) {
		Books books = booksService.updateBook(entity, id);	
		return ResponseEntity.ok(books);
	}

	@DeleteMapping("/three")
    public ResponseEntity<Void> deleteBook(@PathVariable int id) {
        booksService.deleteById(id);
        return ResponseEntity.noContent().build();
	}
}
