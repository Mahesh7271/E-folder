package com.libraryManagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.libraryManagement.model.Books;
import com.libraryManagement.repository.BooksRepository;
@Service
public class BooksService {
	@Autowired
	public BooksRepository booksRepository;

	public Books createBook(Books bk) {
		return booksRepository.save(bk);
	}

	public Books findBook(int id) {
		Books bobj = booksRepository.findById(id).orElse(null);
		return bobj;
	}
	
	public List<Books> findAll() {
		return booksRepository.findAll();
	}

	public String deleteById(int id) {
		Books bobj = findBook(id);
		if (bobj.equals(null)) {
			return "book is not found";
		} else {
			booksRepository.delete(bobj);
			return "book is deleted successfully";
		}
	}
	
	public Books updateBook(Books bobj1, int id) {
		Books bobj = findBook(id);
		if (bobj.equals(null)) {
			return bobj;
		} 
		else {
			bobj.setaName(bobj1.getaName());
			bobj.setPrice(bobj1.getPrice());
			
			return booksRepository.save(bobj);
		}
	}
	
	

}
