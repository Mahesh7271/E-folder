package com.libraryManagement.model;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
@Entity
@Table(name="books")
public class Books {
	@Id
	private int id;
	private String bName;
	private String aName;
	private double price;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getbName() {
		return bName;
	}
	public void setbName(String bName) {
		this.bName = bName;
	}
	public String getaName() {
		return aName;
	}
	public void setaName(String aName) {
		this.aName = aName;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public Books(int id, String bName, String aName, double price) {
		super();
		this.id = id;
		this.bName = bName;
		this.aName = aName;
		this.price = price;
	}
	public Books() {
		super();
	}
	@Override
	public String toString() {
		return "Books [id=" + id + ", bName=" + bName + ", aName=" + aName + ", price=" + price + "]";
	}
	
	

}
