package com.Service;

import com.model.User;

public interface UserService {

	public String addUser();
}
