package com.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Dao.UserRepository;
import com.model.User;

@Service
public class UserServiceImpliment implements UserService {

	
	@Autowired
	UserRepository userRepo;
	
	@Override
	public String addUser() {
		User u= new User();
		u.setName("Ajay");
		userRepo.save(u);
		return "Working";
	}


	
	
}
