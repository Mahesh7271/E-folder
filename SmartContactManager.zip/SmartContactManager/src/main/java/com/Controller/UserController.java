package com.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Service.UserServiceImpliment;

@RestController
public class UserController {
    
	@Autowired
	UserServiceImpliment userService;
	
	@GetMapping("/add")
	public String saveUser() {
		userService.addUser();
		return "working. . .";
	}
	
}
