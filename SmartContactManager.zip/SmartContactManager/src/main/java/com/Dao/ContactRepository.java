package com.Dao;

public interface ContactRepository {

	
}
